// [추가/10-26] AI 감정 분석 (Hume EVI). 신버전으로 바꿀 때 이 파일만 수정

import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';

import 'dart:io';

import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/foundation.dart';
import 'package:path_provider/path_provider.dart';
import 'package:record/record.dart';
import 'package:web_socket_channel/web_socket_channel.dart';

// [변경/10-30] 테스트 앱(layout_example)과 똑같은 감정 분류
// (1003 분류표와 다른 점: Determination·Confusion·Doubt 제외)
const Set<String> positiveEmotionGroup = {
  'joy', 'admiration', 'amusement', 'excitement', 'interest', 'love',
  'adoration', 'awe', 'aesthetic appreciation', 'contentment',
  'satisfaction', 'relief', 'calmness', 'pride', 'triumph', 'ecstasy',
  'entrancement', 'romance', 'gratitude', 'hope',
  'surprise (positive)', 'surprise_positive',
};

const Set<String> negativeEmotionGroup = {
  'sadness', 'fear', 'distress', 'anger', 'disgust', 'contempt',
  'disappointment', 'shame', 'guilt', 'envy', 'pain', 'horror',
  'empathic pain', 'anxiety', 'embarrassment',
  'tiredness', 'boredom', 'awkwardness',
  'surprise (negative)', 'surprise_negative',
};

const Set<String> vitalityGroup = {
  'joy', 'amusement', 'excitement', 'ecstasy', 'pride', 'triumph',
  'determination', 'interest', 'surprise (positive)', 'admiration',
};
const Set<String> calmGroup = {
  'calmness', 'contentment', 'relief', 'satisfaction', 'love', 'adoration',
  'romance', 'awe', 'aesthetic appreciation', 'entrancement',
};
const Set<String> anxietyGroup = {
  'anxiety', 'fear', 'horror', 'distress', 'doubt', 'confusion',
  'awkwardness', 'embarrassment', 'shame', 'guilt', 'surprise (negative)',
  'anger', 'contempt', 'disgust', 'envy',
};
const Set<String> fatigueGroup = {
  'tiredness', 'boredom', 'sadness', 'disappointment', 'pain', 'empathic pain',
};

const Set<String> crisisEmotions = {'sadness', 'fear', 'distress', 'horror'};
const double crisisScoreMax = 30;
const double crisisEmotionMin = 0.3;

double groupScore(Map<String, double> scores, Set<String> group,
    {double normalizeMax = 0.4, int topN = 3}) {
  final values = scores.entries
      .where((e) => group.contains(e.key.toLowerCase()))
      .map((e) => e.value)
      .toList()
    ..sort((a, b) => b.compareTo(a));
  final top = values.take(topN).toList();
  if (top.isEmpty) return 0;
  final avg = top.reduce((a, b) => a + b) / top.length;
  return avg.clamp(0.0, normalizeMax) / normalizeMax * 100;
}

Map<String, double> averageScores(List<Map<String, double>> list) {
  if (list.isEmpty) return {};
  final sums = <String, double>{};
  for (final m in list) {
    m.forEach((k, v) => sums[k] = (sums[k] ?? 0) + v);
  }
  return sums.map((k, v) => MapEntry(k, v / list.length));
}

bool checkCrisis(double wellness, Map<String, double> scores) {
  if (wellness > crisisScoreMax) return false;
  return scores.entries.any((e) =>
  crisisEmotions.contains(e.key.toLowerCase()) && e.value >= crisisEmotionMin);
}

class AnalysisResult {
  const AnalysisResult({
    required this.wellnessScore,
    required this.positivity,
    required this.negativity,
    required this.stability,
    required this.vitality,
    required this.calm,
    required this.anxiety,
    required this.fatigue,
    required this.crisis,
    required this.topEmotion,
    required this.avgScores,
    this.area,
    this.text,
  });

  final double wellnessScore;
  final double positivity;
  final double negativity;
  final double stability;
  final double vitality;
  final double calm;
  final double anxiety;
  final double fatigue;
  final bool crisis;
  final String topEmotion;
  final Map<String, double> avgScores;
  final String? area;
  final String? text;

  String get statusText {
    final s = wellnessScore.round();
    if (s >= 70) return '편안하고 안정된 상태예요';
    if (s >= 40) return '조금 지쳐 있지만 괜찮은 상태예요';
    return '마음이 많이 지쳐 있어요';
  }
}

enum AnalysisStatus {
  idle,
  connecting,
  recording,
  tooShort,
  analyzing,
  done,
  failed,
  giveUp,
  savedOffline,
  error,
}

class AnalysisSession extends ChangeNotifier {
  AnalysisSession._();
  static final AnalysisSession instance = AnalysisSession._();

  static const String serverUrl = 'wss://hume-evi-proxy-server.onrender.com';

  // [테스트용] '' = 정상, 'hume' = Hume 실패, 'clova' = CLOVA 실패, 'crisis' = 위기 배너 강제 표시
  // 테스트가 끝나면 반드시 '' 로 되돌리기
  static const String testFail = '';

  // [비교용/10-30] true = 최종 조각만 평균(희석 줄이기), false = 기존처럼 중간+최종 조각 전부
  static const bool finalOnly = false;

  static const int sampleRate = 44100;
  static const int bytesPerSecond = sampleRate * 2;
  static const int minRecordSeconds = 3;
  static const int maxRecordSeconds = 180;
  static const int warnBeforeSeconds = 30;

  final AudioRecorder _recorder = AudioRecorder();
  WebSocketChannel? _channel;
  StreamSubscription<Uint8List>? _audioSub;

  AnalysisStatus status = AnalysisStatus.idle;
  String message = '';
  AnalysisResult? result;
  bool maxWarned = false;
  bool autoStopped = false;

  int _recordedBytes = 0;
  int get seconds => _recordedBytes ~/ bytesPerSecond;

  // [변경/10-30] 3분 안내는 2:30~2:35, 5초 동안만 표시
  static const int warnShowSeconds = 5;
  bool get showMaxWarning {
    final start = maxRecordSeconds - warnBeforeSeconds;
    return seconds >= start && seconds < start + warnShowSeconds;
  }

  final List<Uint8List> _lastRecording = [];
  final List<_Pending> _pendingQueue = [];
  Timer? _queueTimer;
  final Connectivity _connectivity = Connectivity();
  StreamSubscription<List<ConnectivityResult>>? _connSub;
  bool _isOffline = false;
  bool _initialized = false;
  bool _fromQueue = false;
  int _runId = 0;
  int waitPhase = 0;
  bool replaying = false;
  bool _autoRetried = false;

  bool screenWatching = false;
  VoidCallback? onQueuedResult;

  static const String savedMessage = '녹음은 저장했어요.\n네트워크 연결 후 자동으로 분석돼요.';
  bool _sendingQueued = false;

  bool _offlineRecording = false;
  bool _connectionLost = false;
  bool _closingByApp = false;
  bool _connectionReady = false;
  DateTime _lastMessageAt = DateTime.now();
  int _failCount = 0;
  bool _busy = false;

  final List<Map<String, double>> _allScores = [];
  Map<String, double> _bestScores = {};
  double _bestTop1 = -1;
  final List<Map<String, double>> _finalScores = [];
  Map<String, double> _bestFinalScores = {};
  double _bestFinalTop1 = -1;
  String _bestFinalEmotion = '';
  String _bestTop1Emotion = '';
  String? _area;
  String? _text;
  bool _naverDone = false;
  DateTime _naverAt = DateTime.now();
  bool _naverFailed = false;

  bool get hasRecording => _lastRecording.isNotEmpty;
  bool get isOfflineRecording => _offlineRecording && status == AnalysisStatus.recording;

  void _set(AnalysisStatus s, [String? msg]) {
    status = s;
    if (msg != null) message = msg;
    notifyListeners();
  }

  void _resetResult() {
    result = null;
    _allScores.clear();
    _bestScores = {};
    _bestTop1 = -1;
    _finalScores.clear();
    _bestFinalScores = {};
    _bestFinalTop1 = -1;
    _bestFinalEmotion = '';
    _bestTop1Emotion = '';
    _area = null;
    _text = null;
    _naverDone = false;
    _naverFailed = false;
    _connectionReady = false;
    _connectionLost = false;
    _closingByApp = false;
  }

  Future<void> init() async {
    if (_initialized) return;
    _initialized = true;
    try {
      _isOffline = _offlineOf(await _connectivity.checkConnectivity());
    } catch (_) {}
    _connSub = _connectivity.onConnectivityChanged.listen((r) {
      final wasOffline = _isOffline;
      _isOffline = _offlineOf(r);
      debugPrint('[분석] 네트워크: ${_isOffline ? '오프라인' : '온라인'}');
      if (wasOffline && !_isOffline) _sendPendingQueue();
    });
    await _loadSavedRecordings();
    if (_pendingQueue.isNotEmpty) {
      _startQueueTimer();
      if (!_isOffline) unawaited(_sendPendingQueue());
    }
  }

  bool _offlineOf(List<ConnectivityResult> r) =>
      r.isEmpty || r.every((e) => e == ConnectivityResult.none);

  Future<bool> start() async {
    await init();
    if (_busy) {
      _set(AnalysisStatus.error, '저장된 녹음을 분석하고 있어요.\n잠시 후 다시 시도해주세요.');
      return false;
    }
    if (!await _recorder.hasPermission()) {
      _set(AnalysisStatus.error, '마이크 권한이 필요해요. 설정에서 허용해주세요.');
      return false;
    }
    _busy = true;
    _resetResult();
    _lastRecording.clear();
    _recordedBytes = 0;
    maxWarned = false;
    autoStopped = false;
    _offlineRecording = false;
    _set(AnalysisStatus.connecting, '연결 중이에요...');

    try {
      _isOffline = _offlineOf(await _connectivity.checkConnectivity());
    } catch (_) {}
    if (_isOffline || !await _connect()) _offlineRecording = true;

    try {
      final stream = await _recorder.startStream(const RecordConfig(
        encoder: AudioEncoder.pcm16bits,
        sampleRate: sampleRate,
        numChannels: 1,
        autoGain: false,
        echoCancel: false,
        noiseSuppress: false,
      ));
      _audioSub = stream.listen(_onAudio);
    } catch (e) {
      debugPrint('[분석] 녹음 시작 실패: $e');
      await _closeChannel();
      _busy = false;
      _set(AnalysisStatus.error, '녹음을 시작하지 못했어요. 다시 시도해주세요.');
      return false;
    }

    _set(
      AnalysisStatus.recording,
      _offlineRecording
          ? '오프라인 상태예요. 녹음은 저장되고, 네트워크 연결 후 자동으로 분석돼요.'
          : '듣고 있어요',
    );
    return true;
  }

  void _onAudio(Uint8List data) {
    if (status != AnalysisStatus.recording) return;
    _lastRecording.add(Uint8List.fromList(data));
    final before = seconds;
    _recordedBytes += data.length;

    if (!_offlineRecording && !_connectionLost && _channel != null) {
      _channel!.sink.add(jsonEncode({'type': 'audio_input', 'data': base64Encode(data)}));
    }

    if (!maxWarned && seconds >= maxRecordSeconds - warnBeforeSeconds) {
      maxWarned = true;
      message = '30초 후 녹음이 끝나요 (최대 3분)';
    }
    if (!autoStopped && seconds >= maxRecordSeconds) {
      autoStopped = true;
      stop();
      return;
    }
    if (seconds != before) notifyListeners();
  }

  Future<bool> stop() async {
    if (status != AnalysisStatus.recording) return status != AnalysisStatus.tooShort;
    status = AnalysisStatus.analyzing;
    await _recorder.stop();
    await _audioSub?.cancel();
    _audioSub = null;
    debugPrint('[분석] 녹음 종료: ${(_recordedBytes / bytesPerSecond).toStringAsFixed(1)}초 / '
        '서버 전송 ${_offlineRecording || _connectionLost ? '안 됨' : '됨'}');

    if (_recordedBytes / bytesPerSecond <= minRecordSeconds) {
      await _closeChannel();
      _busy = false;
      _set(AnalysisStatus.tooShort, '녹음이 원활하게 진행되지 않았어요.\n3초 이상 말씀해주세요.');
      return false;
    }

    if (_offlineRecording) {
      _saveForLater();
      return true;
    }

    _autoRetried = false;
    _failCount = 0;
    _set(AnalysisStatus.analyzing, '감정을 살펴보고 있어요');
    unawaited(_finish(++_runId));
    return true;
  }

  Future<void> cancel() async {
    if (status != AnalysisStatus.recording && status != AnalysisStatus.connecting) return;
    await _recorder.stop();
    await _audioSub?.cancel();
    _audioSub = null;
    await _closeChannel();
    _busy = false;
    _set(AnalysisStatus.idle, '');
  }

  Future<void> _finish(int id) async {
    waitPhase++;
    notifyListeners();
    await Future.delayed(const Duration(milliseconds: 1500));
    if (id != _runId) return;
    try {
      if (_channel != null && !_connectionLost) {
        final silence = base64Encode(Uint8List(3200));
        for (int i = 0; i < 35; i++) {
          _channel!.sink.add(jsonEncode({'type': 'audio_input', 'data': silence}));
          await Future.delayed(const Duration(milliseconds: 100));
        }
        _channel!.sink.add(jsonEncode({'type': 'recording_finished', 'no_auto_retry': _autoRetried}));
      }
    } catch (e) {
      debugPrint('[분석] 종료 신호 실패: $e');
      _connectionLost = true;
    }

    _lastMessageAt = DateTime.now();
    int waited = 0;
    while (waited < 45000) {
      await Future.delayed(const Duration(milliseconds: 200));
      waited += 200;
      if (_naverFailed) break;
      if (_naverDone) {
        final now = DateTime.now();
        final quiet = now.difference(_lastMessageAt).inMilliseconds;
        final sinceNaver = now.difference(_naverAt).inMilliseconds;
        if (_allScores.isNotEmpty && quiet >= 3000) break;
        if (_allScores.isEmpty && sinceNaver >= 8000) break;
      }
      if (_connectionLost || id != _runId) break;
    }
    if (id != _runId) return;
    await _closeChannel();

    final avgAll = averageScores(_allScores);
    final avgFinal = averageScores(_finalScores);
    final useFinal = finalOnly && avgFinal.isNotEmpty;
    final avg = useFinal ? avgFinal : avgAll;
    final best = useFinal ? _bestFinalScores : _bestScores;
    final bestEmotion = useFinal ? _bestFinalEmotion : _bestTop1Emotion;
    _busy = false;

    final apiFailed = avg.isEmpty || _naverFailed || !_naverDone;
    if (apiFailed) {
      if (_connectionLost) {
        _saveForLater();
        return;
      }
      debugPrint('[분석] 실패 → Hume 결과 ${avg.isEmpty ? '없음' : '있음'} / '
          'CLOVA ${_naverFailed ? '실패' : (_naverDone ? '성공' : '응답 없음')}');
      if (!_autoRetried && _naverFailed) {
        _autoRetried = true;
        _failCount += 2;
        debugPrint('[분석] 1차 실패 → 서버가 자동 재시도 1회 → 2차 실패');
      } else if (!_autoRetried && _lastRecording.isNotEmpty) {
        _autoRetried = true;
        _failCount = 1;
        debugPrint('[분석] 1차 실패 → 자동 재시도 1회 (사용자에게 알리지 않음)');
        await _replay(List<Uint8List>.from(_lastRecording), message);
        return;
      } else {
        _failCount++;
      }
      debugPrint('[분석] 실패 $_failCount회째');
      if (_failCount >= 3) {
        _set(AnalysisStatus.giveUp, '지금은 분석이 어려운 상태예요.\n잠시 후 다시 시도해주세요.');
      } else {
        _set(AnalysisStatus.failed, '분석에 실패했어요.\n다시 시도해주세요.');
      }
      return;
    }

    final positivity = groupScore(avg, positiveEmotionGroup);
    final negativity = groupScore(avg, negativeEmotionGroup);
    final stability = 100 - negativity;
    final wellness = positivity * 0.5 + stability * 0.5;

    result = AnalysisResult(
      wellnessScore: wellness,
      positivity: positivity,
      negativity: negativity,
      stability: stability,
      vitality: groupScore(avg, vitalityGroup),
      calm: groupScore(avg, calmGroup),
      anxiety: groupScore(avg, anxietyGroup),
      fatigue: groupScore(avg, fatigueGroup),
      crisis: testFail == 'crisis' || checkCrisis(wellness, best),
      topEmotion: bestEmotion,
      avgScores: avg,
      area: _area ?? '기타',
      text: _text,
    );
    _failCount = 0;
    final top5 = (avg.entries.toList()..sort((a, b) => b.value.compareTo(a.value))).take(5)
        .map((e) => '${e.key} ${e.value.toStringAsFixed(2)}').join(', ');
    final crisisVals = crisisEmotions.map((c) {
      final v = best.entries.where((e) => e.key.toLowerCase() == c).map((e) => e.value);
      return '$c ${v.isEmpty ? '-' : v.first.toStringAsFixed(2)}';
    }).join(', ');
    double wOf(Map<String, double> a) =>
        a.isEmpty ? -1 : groupScore(a, positiveEmotionGroup) * 0.5 + (100 - groupScore(a, negativeEmotionGroup)) * 0.5;
    double dOf(Map<String, double> a) =>
        a.entries.where((e) => e.key.toLowerCase() == 'distress').map((e) => e.value).fold(0.0, (x, y) => y);
    debugPrint('[분석] 조각 개수: 전체 ${_allScores.length}개 (최종 ${_finalScores.length}개)');
    debugPrint('[비교] 전체 조각 평균 → 웰니스 ${wOf(avgAll).toStringAsFixed(1)} / distress ${dOf(avgAll).toStringAsFixed(3)}');
    debugPrint('[비교] 최종 조각만 → 웰니스 ${wOf(avgFinal).toStringAsFixed(1)} / distress ${dOf(avgFinal).toStringAsFixed(3)}');
    debugPrint('[비교] 화면에 쓴 방식: ${useFinal ? '최종 조각만' : '전체 조각'}');
    debugPrint('[분석] 평균 상위5: $top5');
    debugPrint('[분석] 위기 감정(대표 메시지): $crisisVals');
    if (_area == null) debugPrint('[분석] 영역 없음 → 기타로 처리');
    debugPrint('[분석] 웰니스=${wellness.toStringAsFixed(1)} 긍정=${positivity.toStringAsFixed(1)} '
        '부정=${negativity.toStringAsFixed(1)} 영역=$_area 위기=${result!.crisis}');
    _set(AnalysisStatus.done, '');
    if (_fromQueue && !screenWatching) onQueuedResult?.call();

    if (_pendingQueue.isNotEmpty) unawaited(_sendPendingQueue());
  }

  Future<void> retry() async {
    if (_busy || _lastRecording.isEmpty) return;
    _autoRetried = true;
    await _replay(List<Uint8List>.from(_lastRecording), '같은 녹음으로 다시 분석하고 있어요');
  }

  Future<void> timeout() async {
    if (status != AnalysisStatus.analyzing) return;
    _runId++;
    await _closeChannel();
    _busy = false;
    _autoRetried = true;
    _failCount++;
    debugPrint('[분석] 시간 초과 → 분석 중단 (실패 $_failCount회째)');
    if (_failCount >= 3) {
      _set(AnalysisStatus.giveUp, '지금은 분석이 어려운 상태예요.\n잠시 후 다시 시도해주세요.');
    } else {
      _set(AnalysisStatus.failed, '분석 시간이 너무 오래 걸렸어요.\n다시 시도해주세요.');
    }
  }

  void reset() {
    _failCount = 0;
    if (!_busy) _set(AnalysisStatus.idle, '');
  }

  Future<bool> _replay(List<Uint8List> chunks, String msg) async {
    final id = ++_runId;
    _busy = true;
    _resetResult();
    _set(AnalysisStatus.analyzing, msg);
    if (!await _connect()) {
      _busy = false;
      _set(AnalysisStatus.failed, '서버에 연결하지 못했어요.\n인터넷 연결을 확인해주세요.');
      return false;
    }
    replaying = true;
    notifyListeners();
    for (final c in chunks) {
      if (_connectionLost || id != _runId) break;
      _channel!.sink.add(jsonEncode({'type': 'audio_input', 'data': base64Encode(c)}));
      final ms = (c.length / bytesPerSecond * 1000).round().clamp(10, 1000).toInt();
      await Future.delayed(Duration(milliseconds: ms));
    }
    replaying = false;
    if (id != _runId) return false;
    await _finish(id);
    return status == AnalysisStatus.done;
  }

  void _saveForLater() {
    if (!_sendingQueued) {
      final item = _Pending(_merge(_lastRecording));
      _pendingQueue.add(item);
      unawaited(_writeToDisk(item));
    }
    _busy = false;
    _set(AnalysisStatus.savedOffline, savedMessage);
    _startQueueTimer();
  }

  void _startQueueTimer() {
    _queueTimer?.cancel();
    _queueTimer = Timer.periodic(const Duration(seconds: 15), (_) {
      if (_pendingQueue.isEmpty) {
        _queueTimer?.cancel();
        return;
      }
      if (!_isOffline) _sendPendingQueue();
    });
  }

  Future<void> _sendPendingQueue() async {
    if (_sendingQueued || _busy || _pendingQueue.isEmpty) return;
    _sendingQueued = true;
    while (_pendingQueue.isNotEmpty) {
      final item = _pendingQueue.removeAt(0);
      final chunks = _split(item.bytes);
      _lastRecording
        ..clear()
        ..addAll(chunks);
      _fromQueue = true;
      _autoRetried = false;
      _failCount = 0;
      final ok = await _replay(chunks, '저장된 녹음을 분석하고 있어요');
      _fromQueue = false;
      if (!ok) {
        _pendingQueue.insert(0, item);
        if (status == AnalysisStatus.failed) _set(AnalysisStatus.savedOffline, savedMessage);
        break;
      }
      await _deleteFromDisk(item);
    }
    _sendingQueued = false;
  }

  Uint8List _merge(List<Uint8List> chunks) {
    final b = BytesBuilder(copy: false);
    for (final c in chunks) {
      b.add(c);
    }
    return b.toBytes();
  }

  List<Uint8List> _split(Uint8List bytes) {
    const size = bytesPerSecond ~/ 10;
    return [
      for (int i = 0; i < bytes.length; i += size)
        Uint8List.sublistView(bytes, i, i + size > bytes.length ? bytes.length : i + size),
    ];
  }

  Future<Directory?> _queueDir() async {
    if (kIsWeb) return null;
    final base = await getApplicationDocumentsDirectory();
    final dir = Directory('${base.path}/pending_recordings');
    if (!await dir.exists()) await dir.create(recursive: true);
    return dir;
  }

  Future<void> _writeToDisk(_Pending item) async {
    try {
      final dir = await _queueDir();
      if (dir == null) return;
      final f = File('${dir.path}/rec_${DateTime.now().millisecondsSinceEpoch}.pcm');
      await f.writeAsBytes(item.bytes);
      item.path = f.path;
      debugPrint('[분석] 녹음 임시 저장: ${f.path}');
    } catch (e) {
      debugPrint('[분석] 임시 저장 실패: $e');
    }
  }

  Future<void> _deleteFromDisk(_Pending item) async {
    try {
      if (item.path != null) await File(item.path!).delete();
    } catch (_) {}
  }

  Future<void> _loadSavedRecordings() async {
    try {
      final dir = await _queueDir();
      if (dir == null) return;
      final files = dir.listSync().whereType<File>().where((f) => f.path.endsWith('.pcm')).toList()
        ..sort((a, b) => a.path.compareTo(b.path));
      for (final f in files) {
        _pendingQueue.add(_Pending(await f.readAsBytes())..path = f.path);
      }
      if (files.isNotEmpty) debugPrint('[분석] 저장된 녹음 ${files.length}개 불러옴');
    } catch (e) {
      debugPrint('[분석] 저장된 녹음 불러오기 실패: $e');
    }
  }

  Future<bool> _connect() async {
    try {
      _channel = WebSocketChannel.connect(Uri.parse(serverUrl));
      await _channel!.ready.timeout(const Duration(seconds: 10));
    } catch (e) {
      debugPrint('[분석] 서버 연결 실패: $e');
      _channel = null;
      return false;
    }
    final ch = _channel!;
    ch.stream.listen(
          (m) {
        if (!identical(ch, _channel)) return;
        try {
          _handleMessage(jsonDecode(m as String) as Map<String, dynamic>);
        } catch (e) {
          debugPrint('[분석] 메시지 처리 오류: $e');
        }
      },
      onError: (e) {
        if (!identical(ch, _channel)) return;
        debugPrint('[분석] 연결 오류: $e');
        _connectionLost = true;
      },
      onDone: () {
        if (identical(ch, _channel) && !_closingByApp) _connectionLost = true;
      },
    );
    int waited = 0;
    while (!_connectionReady && waited < 8000 && !_connectionLost) {
      await Future.delayed(const Duration(milliseconds: 100));
      waited += 100;
    }
    if (!_connectionReady) debugPrint('[분석] ⚠️ 8초 동안 Hume 연결 준비 신호(chat_metadata)를 못 받음');
    return !_connectionLost;
  }

  Future<void> _closeChannel() async {
    _closingByApp = true;
    try {
      await _channel?.sink.close();
    } catch (_) {}
    _channel = null;
  }

  void _handleMessage(Map<String, dynamic> data) {
    _lastMessageAt = DateTime.now();
    final type = data['type'];

    if (type == 'chat_metadata') {
      debugPrint('[분석] Hume 연결 준비 완료 (chat_metadata)');
      _connectionReady = true;
      _channel?.sink.add(jsonEncode({
        'type': 'session_settings',
        'audio': {'sample_rate': sampleRate, 'channels': 1, 'encoding': 'linear16'},
      }));
      _channel?.sink.add(jsonEncode({'type': 'pause_assistant_message'}));
    } else if (type == 'user_message') {
      if (testFail == 'hume') return;
      final prosody = data['models']?['prosody']?['scores'] as Map<String, dynamic>?;
      if (prosody == null || prosody.isEmpty) return;
      final scores = prosody.map((k, v) => MapEntry(k, (v as num).toDouble()));
      _allScores.add(scores);
      final top = scores.entries.reduce((a, b) => a.value >= b.value ? a : b);
      final dist = scores.entries.where((e) => e.key.toLowerCase() == 'distress').map((e) => e.value);
      debugPrint('[분석] 조각 ${_allScores.length} (${data['interim'] == true ? '중간' : '최종'}): '
          '${top.key} ${top.value.toStringAsFixed(3)} / Distress ${dist.isEmpty ? '-' : dist.first.toStringAsFixed(3)}');
      if (top.value > _bestTop1) {
        _bestTop1 = top.value;
        _bestTop1Emotion = top.key;
        _bestScores = scores;
      }
      if (data['interim'] != true) {
        _finalScores.add(scores);
        if (top.value > _bestFinalTop1) {
          _bestFinalTop1 = top.value;
          _bestFinalEmotion = top.key;
          _bestFinalScores = scores;
        }
      }
    } else if (type == 'naver_transcript' && testFail == 'clova') {
      debugPrint('[분석] [테스트] CLOVA 실패로 처리');
      _naverDone = true;
      _naverAt = DateTime.now();
      _naverFailed = true;
    } else if (type == 'naver_transcript') {
      final text = (data['text'] ?? '').toString();
      final area = data['area'];
      _text = text.isEmpty ? null : text;
      _area = area is String && area.isNotEmpty ? area : null;
      _naverDone = true;
      _naverAt = DateTime.now();
      debugPrint('[분석] 받아쓰기: [$text] / 영역: [$area]');
    } else if (type == 'naver_transcript_failed') {
      debugPrint('[분석] CLOVA/HCX 실패 ${_autoRetried ? '(자동 재시도 없음)' : '(서버 자동 재시도 후)'}');
      _naverDone = true;
      _naverAt = DateTime.now();
      _naverFailed = true;
    } else if (type == 'error') {
      debugPrint('[분석] 서버 에러: $data');
    } else {
      debugPrint('[분석] 기타 메시지: $type');
    }
  }
}

class _Pending {
  _Pending(this.bytes);
  final Uint8List bytes;
  String? path;
}