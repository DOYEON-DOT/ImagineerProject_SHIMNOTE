// [변경/10-26] 실제 녹음 + AI 분석 연결 (디자인 그대로)

import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../navigation/app_routes.dart';
import '../navigation/nav.dart';
import '../services/analysis_service.dart';
import '../theme/app_colors.dart';
import '../theme/app_text.dart';
import '../widgets/app_icons.dart';
import '../widgets/common.dart';

enum _Stage { idle, recording, error }

/// 4. 감정 담기
/// - 마이크 탭 → 녹음 중 상태
/// - 녹음 완료 → 5. 분석
/// - '미리보기: 녹음 오류 상태' → 오류 상태, '다시 녹음' → 녹음 중
/// - 뒤로가기 → 3. 메인(홈)
class RecordingScreen extends StatefulWidget {
  const RecordingScreen({super.key});

  @override
  State<RecordingScreen> createState() => _RecordingScreenState();
}

class _RecordingScreenState extends State<RecordingScreen> with TickerProviderStateMixin {
  final AnalysisSession _session = AnalysisSession.instance;
  _Stage _stage = _Stage.idle;
  bool _moving = false;

  // '귀 기울여 듣고 있어요' ↔ '편안히 얘기해주세요' 문구 교차 (20초 주기)
  late final AnimationController _phrase;

  // 녹음 중 파형이 살짝 움직이도록
  late final AnimationController _wave;

  Future<void> _startRecording() async {
    setState(() => _stage = _Stage.recording);
    final ok = await _session.start();
    if (!ok && mounted) setState(() => _stage = _Stage.error);
  }

  Future<void> _finish() async {
    if (_moving) return;
    _moving = true;
    final ok = await _session.stop();
    if (!mounted) return;
    if (!ok) {
      _moving = false;
      setState(() => _stage = _Stage.error);
      return;
    }
    await _goAnalyzing();
  }

  Future<void> _goAnalyzing() async {
    _moving = true;
    await Nav.push(context, AppRoutes.analyzing);
    _moving = false;
    if (mounted) setState(() => _stage = _Stage.idle);
  }

  void _onSession() {
    if (!mounted) return;
    if (_stage == _Stage.recording && _session.autoStopped && !_moving &&
        _session.status != AnalysisStatus.recording) {
      _goAnalyzing();
      return;
    }
    setState(() {});
  }

  void _back() {
    _session.cancel();
    Nav.backTo(context, AppRoutes.home);
  }

  @override
  void initState() {
    super.initState();
    _session.addListener(_onSession);
    _phrase = AnimationController(vsync: this, duration: const Duration(seconds: 20))..repeat();
    _wave = AnimationController(vsync: this, duration: const Duration(milliseconds: 900))..repeat(reverse: true);
  }

  @override
  void dispose() {
    _session.removeListener(_onSession);
    _session.cancel();
    _phrase.dispose();
    _wave.dispose();
    super.dispose();
  }

  String get _time {
    final sec = _session.seconds;
    final m = (sec ~/ 60).toString().padLeft(2, '0');
    final s = (sec % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment(-0.6, -1),
            end: Alignment(0.6, 1),
            colors: [AppColors.mint100, AppColors.mint300],
          ),
        ),
        padding: EdgeInsets.fromLTRB(24, topPad(context, 60), 24, bottomPad(context, 40)),
        child: Column(
          children: [
            Align(
              alignment: Alignment.centerLeft,
              child: BackArrow(onTap: _back),
            ),
            Expanded(
              child: switch (_stage) {
                _Stage.idle => _idle(),
                _Stage.error => _error(),
                _Stage.recording => _recording(),
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _micCircle({required Color inner, double innerSize = 108, double iconSize = 36}) {
    return Container(
      width: 176,
      height: 176,
      alignment: Alignment.center,
      decoration: BoxDecoration(color: AppColors.alpha(AppColors.white, 0.45), shape: BoxShape.circle),
      child: Container(
        width: innerSize,
        height: innerSize,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: inner,
          shape: BoxShape.circle,
          boxShadow: inner == AppColors.primary
              ? [BoxShadow(color: AppColors.alpha(AppColors.textDark, 0.2), blurRadius: 26, offset: const Offset(0, 10))]
              : null,
        ),
        child: Svg(AppIcons.mic(AppColors.white), size: iconSize),
      ),
    );
  }

  Widget _idle() {
    return ShrinkToFit(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Tap(onTap: _startRecording, child: _micCircle(inner: AppColors.primary)),
          const SizedBox(height: 28),
          Text('탭하여 녹음을 시작해요', style: ts(16, weight: bold)),
          const SizedBox(height: 6),
          Text('10초 이상 이야기해야 마음을 정확하게 살펴볼 수 있어요', style: ts(12, color: AppColors.textBody)),
        ],
      ),
    );
  }

  Widget _error() {
    return ShrinkToFit(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          _micCircle(inner: AppColors.textMuted),
          const SizedBox(height: 24),
          Text(
            _session.message.isEmpty ? '녹음이 원활하게 진행되지 않았어요' : _session.message,
            textAlign: TextAlign.center,
            style: ts(15, weight: bold, height: 1.5),
          ),
          const SizedBox(height: 24),
          Tap(
            onTap: _startRecording,
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Svg(AppIcons.retry(AppColors.textDark), size: 16),
                const SizedBox(width: 6),
                Text('다시 녹음', style: ts(13, weight: bold)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _recording() {
    const bars = [12.0, 22.0, 8.0, 18.0, 24.0, 10.0, 16.0];
    return Column(
      children: [
        Expanded(
          child: ShrinkToFit(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // 문구 교차 애니메이션
                SizedBox(
                  height: 24,
                  width: 280,
                  child: AnimatedBuilder(
                    animation: _phrase,
                    builder: (context, _) {
                      if (_session.status == AnalysisStatus.connecting) {
                        return Center(child: Text('연결 중이에요...', style: ts(16, weight: FontWeight.w500)));
                      }
                      final a = _phraseOpacity(_phrase.value);
                      return Stack(
                        alignment: Alignment.center,
                        children: [
                          Opacity(opacity: a, child: Text('귀 기울여 듣고 있어요', style: ts(16, weight: FontWeight.w500))),
                          Opacity(opacity: 1 - a, child: Text('편안히 얘기해주세요', style: ts(16, weight: FontWeight.w500))),
                        ],
                      );
                    },
                  ),
                ),
                const SizedBox(height: 36),
                SizedBox(
                  width: 176,
                  height: 176,
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      Container(
                        decoration: BoxDecoration(color: AppColors.alpha(AppColors.white, 0.35), shape: BoxShape.circle),
                      ),
                      Container(
                        width: 136,
                        height: 136,
                        decoration: BoxDecoration(color: AppColors.alpha(AppColors.white, 0.55), shape: BoxShape.circle),
                      ),
                      Container(
                        width: 96,
                        height: 96,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          color: AppColors.primary,
                          shape: BoxShape.circle,
                          boxShadow: [
                            BoxShadow(color: AppColors.alpha(AppColors.textDark, 0.2), blurRadius: 26, offset: const Offset(0, 10)),
                          ],
                        ),
                        child: Svg(AppIcons.mic(AppColors.white), size: 34),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 36),
                // 파형
                SizedBox(
                  height: 24,
                  child: AnimatedBuilder(
                    animation: _wave,
                    builder: (context, _) => Row(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        for (var i = 0; i < bars.length; i++) ...[
                          if (i > 0) const SizedBox(width: 5),
                          Container(
                            width: 4,
                            height: (bars[i] * (0.7 + 0.3 * math.sin(_wave.value * math.pi + i))).clamp(6.0, 24.0),
                            decoration: BoxDecoration(color: AppColors.textDark, borderRadius: BorderRadius.circular(2)),
                          ),
                        ],
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 36),
                Text(_time, style: ts(13, color: AppColors.textBody)),
                if (_session.showMaxWarning) ...[
                  const SizedBox(height: 6),
                  Text('30초 후 녹음이 끝나요 (최대 3분)', style: ts(12, weight: bold, color: AppColors.textDark)),
                ],
              ],
            ),
          ),
        ),
        InfoBanner(
          text: _session.isOfflineRecording
              ? _session.message
              : '소음이 있는 곳에서 녹음하면 분석이 정확하지 않을 수 있어요',
          background: AppColors.alpha(AppColors.white, 0.55),
          color: AppColors.textBody,
          alignTop: true,
        ),
        const SizedBox(height: 16),
        PrimaryButton(
          label: '녹음 완료',
          onTap: _session.status == AnalysisStatus.recording ? _finish : null,
          background: AppColors.textDark,
        ),
      ],
    );
  }

  /// CSS keyframes phraseA: 0~45% 보임, 45~55% 사라짐, 95~100% 다시 나타남
  double _phraseOpacity(double t) {
    if (t < 0.45) return 1;
    if (t < 0.55) return 1 - (t - 0.45) / 0.10;
    if (t < 0.95) return 0;
    return (t - 0.95) / 0.05;
  }
}