import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart' show SvgPicture;

import '../navigation/app_routes.dart';
import '../navigation/nav.dart';
import '../theme/app_colors.dart';
import '../theme/app_text.dart';
import 'app_icons.dart';
import 'common.dart';
import 'record_widgets.dart';

/// 물고기 4종 (감정 유형별 색)
/// 그림 파일: assets/fish/fish_<유형>_lv<1~5>.svg
enum FishType {
  vitality('활력', Color(0xFFFFE08A), Color(0xFFF5C451), Color(0xFFFFF7DA)),
  calm('안정', Color(0xFFA8E0B8), Color(0xFF7CC896), Color(0xFFEAF8EE)),
  anxiety('불안', Color(0xFFFFABAB), Color(0xFFF28B8B), Color(0xFFFFEAEA)),
  fatigue('피로', Color(0xFFA7CBF5), Color(0xFF7DAAE6), Color(0xFFEAF3FD));

  const FishType(this.label, this.color, this.dark, this.light);

  final String label; // 한글 이름
  final Color color; //  몸통 색
  final Color dark; //   지느러미·테두리 색
  final Color light; //  배경용 연한 색

  static const int maxLevel = 5;

  String asset(int level) => 'assets/fish/fish_${name}_lv${level.clamp(1, maxLevel)}.svg';
}

/// 레벨별 이름
const fishLevelNames = {1: '치어', 2: '꼬마', 3: '성장', 4: '성숙', 5: '완성'};

/// 물고기 그림
/// - 그림은 200×200 캔버스 안에서 레벨이 오를수록 커지도록 그려져 있어,
///   같은 [size]로 그리면 레벨 차이가 그대로 보여요.
/// - [zoom]을 켜면 레벨과 상관없이 물고기가 꽉 차 보이게 확대합니다. (보유 물고기 동그라미용)
class FishSprite extends StatelessWidget {
  const FishSprite({super.key, required this.type, required this.level, required this.size, this.zoom = false});

  final FishType type;
  final int level;
  final double size;
  final bool zoom;

  static const _zoomByLevel = [2.3, 1.9, 1.6, 1.35, 1.15];

  @override
  Widget build(BuildContext context) {
    final picture = SvgPicture.asset(type.asset(level), width: size, height: size);
    if (!zoom) return picture;
    return SizedBox(
      width: size,
      height: size,
      child: ClipRect(
        child: OverflowBox(
          maxWidth: double.infinity,
          maxHeight: double.infinity,
          child: Transform.scale(scale: _zoomByLevel[level.clamp(1, FishType.maxLevel) - 1], child: picture),
        ),
      ),
    );
  }
}

/// 어항 화면 공통 헤더: 구름 뒤 '나의 어항' + 전환 링크 + 설정(마이페이지)
class TankHeader extends StatelessWidget {
  const TankHeader({super.key, required this.linkLabel, required this.onLink});

  final String linkLabel;
  final VoidCallback onLink;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Stack(
          clipBehavior: Clip.none,
          children: [
            Positioned(left: -14, top: -12, child: Svg(AppIcons.cloud(), size: 168, height: 56)),
            Text('나의 어항', style: ts(17, weight: bold)),
          ],
        ),
        Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            UnderlineLink(label: linkLabel, onTap: onLink),
            const SizedBox(width: 14),
            Tap(
              onTap: () => Nav.push(context, AppRoutes.myPage),
              child: Svg(AppIcons.settings(AppColors.textDark), size: 22),
            ),
          ],
        ),
      ],
    );
  }
}

/// 어항 배경 (물 그라데이션 + 모래 + 수초)
class TankBackground extends StatelessWidget {
  const TankBackground({super.key, required this.sandRatio, required this.plants});

  final double sandRatio; // 모래가 차지하는 높이 비율
  final List<PlantSpec> plants;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, c) {
      return Stack(
        children: [
          Positioned.fill(
            child: Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Color(0xFFCDEEF0), Color(0xFF7FC9D6)],
                ),
              ),
            ),
          ),
          Positioned(
            left: 0,
            right: 0,
            bottom: 0,
            height: c.maxHeight * sandRatio,
            child: const DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Color(0x99F0E6BE), Color(0xFFE7DCB0)],
                ),
              ),
            ),
          ),
          // 안쪽 그림자 느낌 (inset 0 0 40px rgba(0,60,70,0.12))
          Positioned.fill(
            child: IgnorePointer(
              child: DecoratedBox(
                decoration: BoxDecoration(
                  gradient: RadialGradient(
                    radius: 1.1,
                    colors: [Colors.transparent, AppColors.alpha(const Color(0xFF003C46), 0.12)],
                    stops: const [0.75, 1.0],
                  ),
                ),
              ),
            ),
          ),
          for (final p in plants)
            Positioned(
              left: p.left,
              right: p.right,
              bottom: p.bottom,
              child: Container(
                width: p.width,
                height: p.height,
                decoration: BoxDecoration(
                  color: p.color,
                  borderRadius: BorderRadius.vertical(
                    top: Radius.elliptical(p.width * 0.4, p.height * 0.4),
                  ),
                ),
              ),
            ),
        ],
      );
    });
  }
}

class PlantSpec {
  const PlantSpec({this.left, this.right, required this.bottom, required this.width, required this.height, required this.color});

  final double? left;
  final double? right;
  final double bottom;
  final double width;
  final double height;
  final Color color;
}

const plantLight = Color(0xFF7BAB6F);
const plantDark = Color(0xFF6A9C60);

/// 물고기 레벨 카드
class FishLevelCard extends StatelessWidget {
  const FishLevelCard({super.key, required this.type, required this.level, required this.exp, required this.maxExp});

  final FishType type;
  final int level;
  final int exp;
  final int maxExp;

  @override
  Widget build(BuildContext context) {
    return AppCard(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(color: type.light, shape: BoxShape.circle),
                child: ClipOval(child: FishSprite(type: type, level: level, size: 44, zoom: true)),
              ),
              const SizedBox(width: 12),
              Expanded(child: Text('${type.label} 물고기', style: ts(14, weight: bold))),
              Text('Lv. $level · ${fishLevelNames[level]}', style: ts(12, color: AppColors.textSub)),
            ],
          ),
          const SizedBox(height: 12),
          ProgressBar(value: exp / maxExp, color: type.dark, height: 8),
          const SizedBox(height: 10),
          Text('$exp / $maxExp EXP', textAlign: TextAlign.right, style: ts(11, color: AppColors.textMuted)),
        ],
      ),
    );
  }
}

/// 점선 원 테두리 (잠긴 물고기 슬롯)
class DashedCircle extends StatelessWidget {
  const DashedCircle({super.key, required this.size, required this.color, required this.fill, required this.child});

  final double size;
  final Color color;
  final Color fill;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      painter: _DashedCirclePainter(color: color, fill: fill),
      child: SizedBox(width: size, height: size, child: Center(child: child)),
    );
  }
}

class _DashedCirclePainter extends CustomPainter {
  _DashedCirclePainter({required this.color, required this.fill});

  final Color color;
  final Color fill;

  @override
  void paint(Canvas canvas, Size size) {
    final center = size.center(Offset.zero);
    final r = size.width / 2 - 1;
    canvas.drawCircle(center, r + 1, Paint()..color = fill);
    final paint = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2;
    const dash = 5.0;
    const gap = 4.0;
    final circumference = 2 * math.pi * r;
    final count = (circumference / (dash + gap)).floor();
    final step = 2 * math.pi / count;
    final sweep = step * dash / (dash + gap);
    for (var i = 0; i < count; i++) {
      canvas.drawArc(Rect.fromCircle(center: center, radius: r), i * step, sweep, false, paint);
    }
  }

  @override
  bool shouldRepaint(covariant _DashedCirclePainter old) => old.color != color || old.fill != fill;
}
