import 'dart:async';

import 'package:flutter/material.dart';

import '../navigation/app_routes.dart';
import '../navigation/nav.dart';
import '../theme/app_colors.dart';
import '../theme/app_text.dart';
import '../widgets/app_icons.dart';
import '../widgets/bottom_nav.dart';
import '../widgets/common.dart';
import '../widgets/fish_widgets.dart';

/// 10. 어항
/// - 물고기를 탭하면 커졌다 작아지고 하트가 떠오르며 이름표가 보입니다
/// - 잠긴 물고기(불안/피로)를 탭하면 해금 조건 안내
/// - '첫 사용자 화면 보기' → 10-1. 어항(첫 사용자)
/// - 설정 아이콘 → 11. 마이페이지
class FishTankScreen extends StatefulWidget {
  const FishTankScreen({super.key});

  @override
  State<FishTankScreen> createState() => _FishTankScreenState();
}

/// 보유 물고기 예시 데이터 (나중에 실제 기록 데이터로 바꾸면 돼요)
class _OwnedFish {
  const _OwnedFish(this.type, this.level, this.exp, this.maxExp);
  final FishType type;
  final int level;
  final int exp;
  final int maxExp;
}

class _FishTankScreenState extends State<FishTankScreen> with TickerProviderStateMixin {
  static const _owned = [
    _OwnedFish(FishType.vitality, 3, 25, 45),
    _OwnedFish(FishType.calm, 1, 4, 10),
  ];
  static const _lockedTips = {
    FishType.anxiety: '불안한 감정을 기록하면 해금돼요',
    FishType.fatigue: '피로한 감정을 기록하면 해금돼요',
  };

  FishType _selected = FishType.vitality; // 아래 레벨 카드에 보여 줄 물고기
  bool _showLabel = false;
  FishType? _pulse;
  FishType? _tip;

  late final AnimationController _vitalitySwim;
  late final AnimationController _calmSwim;
  late final AnimationController _vitalityHeart;
  late final AnimationController _calmHeart;

  _OwnedFish get _selectedFish => _owned.firstWhere((f) => f.type == _selected);

  void _pick(FishType type) {
    setState(() {
      _selected = type;
      _showLabel = true;
      _pulse = type;
      _tip = null;
    });
    (type == FishType.vitality ? _vitalityHeart : _calmHeart).forward(from: 0);
    Timer(const Duration(milliseconds: 220), () {
      if (mounted && _pulse == type) setState(() => _pulse = null);
    });
  }

  @override
  void initState() {
    super.initState();
    _vitalitySwim = AnimationController(vsync: this, duration: const Duration(seconds: 9))..repeat();
    _calmSwim = AnimationController(vsync: this, duration: const Duration(seconds: 7))..repeat();
    _vitalityHeart = AnimationController(vsync: this, duration: const Duration(milliseconds: 900));
    _calmHeart = AnimationController(vsync: this, duration: const Duration(milliseconds: 900));
  }

  @override
  void dispose() {
    _vitalitySwim.dispose();
    _calmSwim.dispose();
    _vitalityHeart.dispose();
    _calmHeart.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final fish = _selectedFish;
    return Scaffold(
      body: Column(
        children: [
          Expanded(
            child: SingleChildScrollView(
              padding: EdgeInsets.fromLTRB(24, topPad(context, 56), 24, 16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  TankHeader(
                    linkLabel: '첫 사용자 화면 보기',
                    onLink: () => Nav.replace(context, AppRoutes.fishTankEmpty),
                  ),
                  const SizedBox(height: 24),
                  _tank(),
                  const SizedBox(height: 14),
                  Text('물고기를 탭해보세요', style: ts(11, color: AppColors.textSub)),
                  const SizedBox(height: 18),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('보유한 물고기', style: ts(14, weight: bold)),
                      Text('${FishType.values.length}마리 중 ${_owned.length}마리 해금',
                          style: ts(12, color: AppColors.textMuted)),
                    ],
                  ),
                  const SizedBox(height: 12),
                  _ownedFish(),
                  const SizedBox(height: 22),
                  if (_tip != null) ...[
                    InfoBanner(text: _lockedTips[_tip]!, padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12)),
                    const SizedBox(height: 22),
                  ],
                  FishLevelCard(type: fish.type, level: fish.level, exp: fish.exp, maxExp: fish.maxExp),
                ],
              ),
            ),
          ),
          const AppBottomNav(current: NavTab.fishTank),
        ],
      ),
    );
  }

  Widget _tank() {
    return ClipRRect(
      borderRadius: BorderRadius.circular(24),
      child: SizedBox(
        height: 280,
        child: LayoutBuilder(builder: (context, c) {
          final w = c.maxWidth;
          final h = c.maxHeight;
          return Stack(
            children: [
              const Positioned.fill(
                child: TankBackground(
                  sandRatio: 0.4,
                  plants: [
                    PlantSpec(left: 16, bottom: 16, width: 20, height: 34, color: plantLight),
                    PlantSpec(left: 44, bottom: 16, width: 16, height: 24, color: plantDark),
                    PlantSpec(right: 30, bottom: 16, width: 18, height: 30, color: plantLight),
                  ],
                ),
              ),
              // 활력 물고기 Lv.3
              Positioned(
                left: w * 0.12,
                top: h * 0.16,
                child: _SwimmingFish(
                  swim: _vitalitySwim,
                  heart: _vitalityHeart,
                  distance: 92,
                  startFlip: -1,
                  size: 120,
                  pulsing: _pulse == FishType.vitality,
                  onTap: () => _pick(FishType.vitality),
                  child: const FishSprite(type: FishType.vitality, level: 3, size: 120),
                ),
              ),
              // 안정 물고기 Lv.1
              Positioned(
                left: w * 0.52,
                top: h * 0.42,
                child: _SwimmingFish(
                  swim: _calmSwim,
                  heart: _calmHeart,
                  distance: -68,
                  startFlip: 1,
                  size: 110,
                  pulsing: _pulse == FishType.calm,
                  onTap: () => _pick(FishType.calm),
                  child: const FishSprite(type: FishType.calm, level: 1, size: 110),
                ),
              ),
              if (_showLabel)
                Positioned(
                  top: 12,
                  left: 0,
                  right: 0,
                  child: Center(
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                      decoration: BoxDecoration(
                        color: AppColors.alpha(AppColors.white, 0.92),
                        borderRadius: BorderRadius.circular(999),
                        boxShadow: [
                          BoxShadow(color: AppColors.alpha(Colors.black, 0.08), blurRadius: 10, offset: const Offset(0, 4)),
                        ],
                      ),
                      child: Text('${_selected.label} 물고기 · Lv.${_selectedFish.level}', style: ts(12, weight: bold)),
                    ),
                  ),
                ),
            ],
          );
        }),
      ),
    );
  }

  Widget _ownedFish() {
    Widget slot({required Widget circle, required String name, required String sub, required bool unlocked, required VoidCallback onTap}) {
      return Tap(
        onTap: onTap,
        child: Column(
          children: [
            circle,
            const SizedBox(height: 6),
            Text(name, style: ts(11, weight: unlocked ? bold : FontWeight.w400, color: unlocked ? AppColors.textDark : AppColors.locked)),
            const SizedBox(height: 6),
            Text(sub, style: ts(10, color: unlocked ? AppColors.textMuted : AppColors.lockedBorder)),
          ],
        ),
      );
    }

    Widget owned(_OwnedFish f) {
      final selected = f.type == _selected;
      return AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        width: 60,
        height: 60,
        decoration: BoxDecoration(
          color: f.type.light,
          shape: BoxShape.circle,
          border: Border.all(color: selected ? f.type.dark : f.type.color, width: selected ? 2.5 : 2),
        ),
        child: ClipOval(child: FishSprite(type: f.type, level: f.level, size: 56, zoom: true)),
      );
    }

    final locked = DashedCircle(
      size: 60,
      color: AppColors.lockedBorder,
      fill: const Color(0xFFEEF3F2),
      child: Svg(AppIcons.lock(AppColors.locked), size: 20),
    );

    final children = <Widget>[
      for (final f in _owned)
        slot(
          circle: owned(f),
          name: f.type.label,
          sub: 'Lv.${f.level}',
          unlocked: true,
          onTap: () => _pick(f.type),
        ),
      for (final t in _lockedTips.keys)
        slot(circle: locked, name: t.label, sub: '미해금', unlocked: false, onTap: () => setState(() => _tip = t)),
    ];

    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      padding: const EdgeInsets.only(bottom: 4),
      child: Row(
        children: [
          for (var i = 0; i < children.length; i++) ...[
            if (i > 0) const SizedBox(width: 14),
            children[i],
          ],
        ],
      ),
    );
  }
}

/// 좌우로 헤엄치는 물고기 (목업 keyframes swimJoy / swimCalm 재현)
class _SwimmingFish extends StatelessWidget {
  const _SwimmingFish({
    required this.swim,
    required this.heart,
    required this.distance,
    required this.startFlip,
    required this.size,
    required this.pulsing,
    required this.child,
    required this.onTap,
  });

  final Animation<double> swim;
  final AnimationController heart;
  final double distance;
  final double startFlip;
  final double size; // 물고기 그림(정사각형) 크기
  final bool pulsing;
  final Widget child;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: Listenable.merge([swim, heart]),
      builder: (context, _) {
        final (x, flip) = _swimAt(swim.value);
        return Transform(
          alignment: Alignment.center,
          transform: Matrix4.translationValues(x, 0, 0)..multiply(Matrix4.diagonal3Values(flip, 1, 1)),
          child: Tap(
            onTap: onTap,
            child: SizedBox(
              width: size,
              height: size,
              child: Stack(
                clipBehavior: Clip.none,
                children: [
                  AnimatedScale(
                    scale: pulsing ? 1.35 : 1,
                    duration: const Duration(milliseconds: 200),
                    curve: Curves.ease,
                    child: child,
                  ),
                  if (heart.isAnimating) _heart(heart.value),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _heart(double t) {
    // keyframes heartFloat: 0% / 50% / 80% / 100%
    double lerp3(double a, double b, double c, double d) {
      if (t < 0.5) return a + (b - a) * (t / 0.5);
      if (t < 0.8) return b + (c - b) * ((t - 0.5) / 0.3);
      return c + (d - c) * ((t - 0.8) / 0.2);
    }

    final opacity = lerp3(0.9, 1, 0.9, 0);
    final dy = lerp3(0, -16, -24, -28);
    final scale = lerp3(0.4, 1, 1.05, 1.6);
    // 물고기 몸통이 그림 가운데쯤에 있어서, 하트도 그 위에서 떠오르게 합니다.
    return Positioned(
      top: size * 0.3 - 18,
      left: size * 0.45 - 9,
      child: Opacity(
        opacity: opacity.clamp(0.0, 1.0),
        child: Transform.translate(
          offset: Offset(0, dy),
          child: Transform.scale(scale: scale, child: Svg(AppIcons.heart(), size: 18)),
        ),
      ),
    );
  }

  /// t(0~1) 시점의 x 이동량과 좌우 방향(scaleX)
  (double, double) _swimAt(double t) {
    final ease = Curves.easeInOut;
    if (t < 0.45) return (distance * ease.transform(t / 0.45), startFlip);
    if (t < 0.50) {
      final k = ease.transform((t - 0.45) / 0.05);
      return (distance, startFlip + (-2 * startFlip) * k);
    }
    if (t < 0.95) return (distance * (1 - ease.transform((t - 0.5) / 0.45)), -startFlip);
    final k = ease.transform((t - 0.95) / 0.05);
    return (0, -startFlip + (2 * startFlip) * k);
  }
}
