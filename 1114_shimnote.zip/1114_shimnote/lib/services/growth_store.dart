// [추가/11-01] 1031 회의 반영: 필사 탭 분리 · 필사로 물고기 성장 · 어항 배경음
// [추가/11-06] 날짜별 기록 · 연속 기록 · 어항 수질 변화
// [변경/11-12] 6개월 자동 삭제 → 망각 곡선 가중치 · 어항 원근감 · 물고기 잠듦 · Lv5 이후 빛나는 물고기
//
// 앱 전체에서 함께 쓰는 "성장 상태"를 한곳에 모았어요.
// - 오늘의 물고기: 웰니스 스코어(활력·안정·불안·피로) 중 가장 높은 유형
// - 필사 문구: 4가지 카테고리, 오늘의 유형에 맞는 문구를 추천
// - 경험치: 추천 문구를 필사하면 해당 물고기만 경험치를 얻어요 (가장 높은 감정 하나만 반영)
// - 어항 배경음: 그날의 음원(오늘 들은 음원, 없으면 오늘 추천 음원)을 어항에서 다시 듣기
//
// ⚠️ 물고기 성장·필사·날짜별 기록은 현재 메모리에 저장해요.
//    사운드 추천 이력과 최근 추천곡 ID는 기기 내부에 저장해요.
//    사용자 기록의 Firestore 영구 저장은 아직 적용하지 않았어요.
import 'dart:math' as math;
import 'dart:async'; //추가
import 'dart:convert'; //추가
import 'dart:io'; //추가

import 'package:cloud_firestore/cloud_firestore.dart'; //추가
import 'package:firebase_auth/firebase_auth.dart'; //추가
import 'package:firebase_storage/firebase_storage.dart'; //추가
import 'package:flutter/foundation.dart';
import 'package:just_audio/just_audio.dart'; //추가
import 'package:path_provider/path_provider.dart'; //추가
import '../widgets/fish_widgets.dart' show FishType;
import 'analysis_service.dart';
import 'sound_recommendation_service.dart'; //추가

// ───────────────────────── 경험치 규칙 (회의에서 숫자만 바꾸면 돼요) ─────────────────────────

/// 추천 문구 하나를 필사하면 얻는 경험치
const int expPerTranscript = 10;

/// 다음 레벨까지 필요한 경험치 (Lv.1→2, 2→3, 3→4, 4→5)
/// 기본값 기준: 한 물고기를 만렙(Lv.5)까지 키우려면 필사 14번
const List<int> expToNextLevel = [20, 30, 40, 50];

/// [테스트용] 녹음 없이 필사·어항 기능을 확인하고 싶을 때 오늘의 유형을 정해 둬요.
/// 예) FishType.calm 으로 바꾸면 '안정'이 오늘의 물고기가 됩니다. 확인이 끝나면 null 로 되돌리기
const FishType? demoTodayType = null;

/// [회의 확인용] true = 어항에 오늘의 물고기만 표시 / false = 4마리 모두 표시하고 오늘의 물고기만 강조
const bool showOnlyTodayFish = false;

// ───────────────────────── [추가/11-06] 기록 · 연속 기록 · 수질 변화 ─────────────────────────
// ※ 녹음 파일은 저장하지 않아요. 날짜별로 분석 결과(점수·유형·영역)와 들은 음원, 메모만 남겨요.

/// [변경/11-14] 망각 곡선(포겟) 가중치: 하루 지날 때마다 0.99배
/// 기록은 캘린더에 그대로 남고, 시간이 지날수록 어항에 덜 반영돼요.
/// (7일 전 ≈ 93%, 30일 전 ≈ 74%, 60일 전 ≈ 55%, 90일 전 ≈ 40%)
const double forgetDailyRate = 0.99;

/// [추가/11-14] 어항에는 최근 90일(약 3개월) 기록만 반영해요. 그보다 오래된 기록은 캘린더에만 남아요.
const int tankWindowDays = 90;

/// [변경/11-14] Lv5(최대) 이후: 빛 3단계 → 치어(아기 물고기)
/// Lv5 이후 따라 쓰기 경험치가 이만큼 쌓일 때마다 치어가 한 마리 태어나요 (물고기마다 최대 3마리)
const int babyExpPerFish = 30;
const int maxBabies = 3;

/// 수질 변화 단계: 마지막 기록 후 경과일 [1단계, 2단계, 3단계]
/// 5일: 살짝 탁해짐 / 10일: 더 탁해지고 천천히 헤엄 / 20일: 수초가 처지고 물고기가 바닥 근처에서 쉼
/// 레벨과 경험치는 절대 줄지 않아요. 다시 기록하면 바로 맑아져요.
const List<int> waterStageDays = [5, 10, 20];

/// [테스트용] 지난 기록을 미리 만들어 둬요. 둘 다 0/null 이면 사용 안 함
/// - demoStreakDays: 연속으로 기록한 날 수 (예: 7 → 7일 연속 기록)
/// - demoLastRecordDaysAgo: 그 연속 기록의 마지막 날이 며칠 전인지 (예: 12 → 12일 전, 수질 2단계 확인용)
/// 확인이 끝나면 0 / null 로 되돌리기
const int demoStreakDays = 0;
const int? demoLastRecordDaysAgo = null;

// ───────────────────────── 필사 문구 (4가지 카테고리) ─────────────────────────

/// 카테고리별 필사 문구. 팀에서 정한 문구로 자유롭게 바꾸거나 늘려도 돼요.
const Map<FishType, List<String>> transcriptPhrases = {
  FishType.vitality: [
    '오늘의 반짝임은 내일의 나에게도 이어질 거예요.',
    '작은 기쁨을 알아보는 마음이 하루를 밝혀요.',
    '지금의 설렘을 천천히 오래 간직해요.',
    '내가 웃을 수 있었던 순간을 잊지 말아요.',
    '좋은 에너지는 나를 지나 누군가에게도 닿아요.',
  ],
  FishType.calm: [
    '천천히 걸어도 괜찮아요. 방향이 맞다면 충분해요.',
    '고요한 마음은 가장 단단한 쉼터예요.',
    '오늘은 이대로도 충분히 괜찮은 하루예요.',
    '숨을 고르고, 지금 이 순간에 머물러요.',
    '잔잔한 물결처럼 내 마음도 제자리를 찾아가요.',
  ],
  FishType.anxiety: [
    '걱정은 잠시 내려놓아도 괜찮아요.',
    '모든 것을 지금 해결하지 않아도 돼요.',
    '흔들리는 마음도 결국 제자리를 찾아요.',
    '불안은 내가 소중한 것을 지키고 있다는 신호예요.',
    '한 걸음씩, 할 수 있는 것부터 해 봐요.',
  ],
  FishType.fatigue: [
    '쉬어가는 것도 나아가는 방법이에요.',
    '오늘 하루 버텨 낸 나에게 고마워요.',
    '지친 날에는 조금 느려도 괜찮아요.',
    '충분히 쉬어야 다시 걸을 힘이 생겨요.',
    '오늘의 나에게 조금 더 다정하게.',
  ],
};

// ───────────────────────── 음원 목록 ─────────────────────────
/// 앱 안의 음원 정보. Firebase 문서에서 실제 음원 정보를 가져와요.
class SoundItem {
  const SoundItem({
    required this.id,
    required this.title,
    required this.desc,
    this.url,
    this.audioPath,
    this.imagePath,
    this.durationSeconds = 0,
  });

  // Firestore 음원 문서를 SoundItem으로 변환
  factory SoundItem.fromDocument(
      DocumentSnapshot<Map<String, dynamic>> document,
      ) {
    final data = document.data();

    if (data == null) {
      throw FormatException('음원 데이터가 없어요: ${document.id}');
    }

    final name = data['name'];
    final description = data['description'];
    final audioPath = data['audio_path'];
    final imagePath = data['image_path'];
    final duration = data['duration_seconds'];

    if (name is! String ||
        name.trim().isEmpty ||
        description is! String ||
        audioPath is! String ||
        audioPath.trim().isEmpty ||
        duration is! num ||
        duration <= 0) {
      throw FormatException('음원 정보가 올바르지 않아요: ${document.id}');
    }

    return SoundItem(
      id: document.id,
      title: name,
      desc: description,
      audioPath: audioPath,
      imagePath: imagePath is String && imagePath.trim().isNotEmpty
          ? imagePath
          : null,
      durationSeconds: duration.toInt(),
    );
  }

  final String id;
  final String title;
  final String desc;
  final String? url; // 기존 URL 필드 유지
  final String? audioPath; // Firebase Storage MP3 경로
  final String? imagePath; // Firebase Storage 이미지 경로
  final int durationSeconds; // 음원 전체 길이(초)
}

const List<SoundItem> soundCatalog = [
  SoundItem(id: 'water_echo', title: '물빛의 잔향', desc: '물속에 번지는 맑은 건반 사운드'),
  SoundItem(id: 'game_world', title: '게임 속 작은 세상', desc: '통통 튀는 게임 속 분위기의 사운드'),
  SoundItem(id: 'spring', title: '맑은 샘물 소리', desc: '바위 사이로 흐르는 맑은 샘물 소리'),
  SoundItem(id: 'rain', title: '잔잔한 빗소리', desc: '숨을 천천히 내쉬어 보세요'),
];

/// 오늘의 추천 음원 3곡 (사운드 추천 화면에 나오는 순서: 추천 카드 1개 + 아래 2개)
/// TODO(사운드): 사운드 추천 로직이 연결되면 분석 결과에 맞는 3곡 id를 돌려주도록 바꿔요.
const List<String> todayRecommendedSoundIds = ['water_echo', 'game_world', 'spring'];

SoundItem? soundById(String? id) {
  if (id == null) return null;

  for (final sound in GrowthStore.instance.recommendedSounds) {
    if (sound.id == id) return sound;
  }

  for (final sound in soundCatalog) {
    if (sound.id == id) return sound;
  }

  return null;
}

// ───────────────────────── 데이터 모델 ─────────────────────────

/// 물고기 한 마리의 성장 상태
class FishProgress {
  FishProgress({this.level = 1, this.exp = 0});

  int level; // 1(치어) ~ 5(완성)
  int exp; //   현재 레벨 안에서 모은 경험치
  int shine = 0; // [추가/11-12] Lv5 이후 모은 경험치 (빛나는 물고기)

  /// [변경/11-14] 치어 수 0 ~ 3 (Lv5 이후에만)
  int get babies => isMax ? (shine ~/ babyExpPerFish).clamp(0, maxBabies) : 0;

  bool get isMax => level >= FishType.maxLevel;

  /// 다음 레벨까지 필요한 경험치 (만렙이면 마지막 단계 값으로 표시)
  int get maxExp => expToNextLevel[(level - 1).clamp(0, expToNextLevel.length - 1)];
}

/// 필사 기록 한 건
class TranscriptRecord {
  const TranscriptRecord({required this.date, required this.phrase, this.type, this.soundTitle});

  final DateTime date;
  final String phrase;
  final FishType? type; //      null 이면 '작은 행운' 필사
  final String? soundTitle; //  필사할 때 재생 중이던 어항 배경음
}

/// 필사를 마쳤을 때의 결과 (화면에서 레벨업 안내에 사용)
class TranscriptReward {
  const TranscriptReward({required this.type, required this.gainedExp, required this.leveledUp, required this.level});

  final FishType type;
  final int gainedExp;
  final bool leveledUp;
  final int level;
}

/// 하루 한 건의 기록 (그날 마지막 분석 결과로 덮어써요)
class DayRecord {
  DayRecord({required this.date, required this.wellness, required this.type, this.area, this.soundTitle, this.memo});

  final DateTime date; // 날짜만 (시간 없음)
  double wellness; //     웰니스 스코어 0~100
  FishType type; //       가장 높았던 유형
  String? area; //        영역 (일/학업 등)
  String? soundTitle; //  그날 들은 음원
  String? memo; //        오늘의 메모
}

DateTime dayOf(DateTime d) => DateTime(d.year, d.month, d.day);

// ───────────────────────── [추가/11-06] 이번 주 영역별 리포트 ─────────────────────────

/// 리포트에서 쓰는 영역 목록 (임시). TODO(서버): 서버 담당 팀원과 목록이 정해지면 여기만 바꿔요.
const List<String> reportAreas = ['일/학업', '대인관계', '가족', '건강', '나 자신', '기타'];

/// 이번 주에 며칠 기록하면 리포트가 열리는지
const int weeklyReportMinDays = 3;

/// 서버에서 오는 영역 글자를 위 목록 중 하나로 맞춰요. (표현이 조금 달라도 같은 영역으로 모이게)
String normalizeArea(String? raw) {
  final a = (raw ?? '').trim();
  if (a.isEmpty) return '기타';
  if (reportAreas.contains(a)) return a;
  bool has(List<String> keys) => keys.any(a.contains);
  if (has(['가족', '부모', '엄마', '아빠', '형제', '자매'])) return '가족';
  if (has(['일', '학업', '공부', '학교', '시험', '과제', '직장', '회사', '업무', '진로', '취업'])) return '일/학업';
  if (has(['대인', '관계', '친구', '연애', '동료', '사람'])) return '대인관계';
  if (has(['건강', '몸', '수면', '잠', '운동', '아픔', '피로'])) return '건강';
  if (has(['자신', '자아', '자존', '감정', '마음'])) return '나 자신';
  return '기타';
}

/// 영역 하나의 이번 주 통계
class AreaStat {
  AreaStat(this.area, this.count, this.avgScore);
  final String area;
  final int count; //       이야기한 날 수
  final double avgScore; // 그 영역 평균 점수
}

/// 이번 주(월~일) 리포트
class WeeklyReport {
  WeeklyReport({
    required this.weekStart,
    required this.days,
    required this.avgScore,
    required this.diffFromLastWeek,
    required this.areas,
  });

  final DateTime weekStart; //       이번 주 월요일
  final int days; //                 이번 주 기록한 날 수
  final double? avgScore; //         이번 주 평균 점수 (기록 없으면 null)
  final double? diffFromLastWeek; // 지난주 평균과의 차이 (지난주 기록 없으면 null)
  final List<AreaStat> areas; //     많이 이야기한 순

  DateTime get weekEnd => weekStart.add(const Duration(days: 6));
  bool get unlocked => days >= weeklyReportMinDays;

  /// 한 줄 코멘트 (낮은 점수를 경고처럼 말하지 않아요)
  String get comment {
    if (areas.isEmpty) return '';
    final top = areas.first;
    var best = areas.first;
    for (final a in areas) {
      if (a.avgScore > best.avgScore) best = a;
    }
    final first = "이번 주엔 '${top.area}' 이야기를 가장 많이 했어요.";
    if (areas.length == 1 || best.area == top.area) return first;
    return "$first '${best.area}' 이야기를 한 날 마음이 가장 편했어요.";
  }
}

// ───────────────────────── 상태 저장소 ─────────────────────────

class GrowthStore extends ChangeNotifier {
  GrowthStore._();
  static final GrowthStore instance = GrowthStore._();

  /// 처음에는 4마리 모두 치어(Lv.1)
  final Map<FishType, FishProgress> fish = {for (final t in FishType.values) t: FishProgress()};

  final List<TranscriptRecord> transcripts = [];

  // ── [추가/11-06] 날짜별 기록 ──

  final List<DayRecord> _records = [];
  AnalysisResult? _recordedResult;
  bool _demoSeeded = false;

  /// 오랜만에 돌아와 기록했을 때 어항에서 인사할지 (어항 화면이 보여 주고 끕니다)
  bool welcomeBack = false;

  /// 메모 화면에서 편집할 날짜
  DateTime? memoTargetDate;

  /// 날짜별 기록 (오래된 순). [변경/11-12] 지우지 않고 모두 보관
  List<DayRecord> get records {
    _sync();
    return List.unmodifiable(_records);
  }

  DayRecord? recordOn(DateTime day) {
    _sync();
    final d = dayOf(day);
    for (final r in _records) {
      if (r.date == d) return r;
    }
    return null;
  }

  /// 연속 기록 일수 (오늘 또는 어제까지 하루도 빠짐없이 기록한 날 수)
  int get streak {
    _sync();
    if (_records.isEmpty) return 0;
    final days = {for (final r in _records) r.date};
    var d = dayOf(DateTime.now());
    if (!days.contains(d)) d = d.subtract(const Duration(days: 1));
    var count = 0;
    while (days.contains(d)) {
      count++;
      d = d.subtract(const Duration(days: 1));
    }
    return count;
  }

  bool get recordedToday => recordOn(DateTime.now()) != null;

  /// 마지막 기록 후 지난 날 수 (기록이 하나도 없으면 null)
  int? get daysSinceLastRecord {
    _sync();
    if (_records.isEmpty) return null;
    return dayOf(DateTime.now()).difference(_records.last.date).inDays;
  }

  /// 수질 단계 0(맑음) ~ 3. 처음 쓰는 사람(기록 없음)은 항상 맑음
  int get waterStage {
    final d = daysSinceLastRecord;
    if (d == null) return 0;
    var stage = 0;
    for (final limit in waterStageDays) {
      if (d >= limit) stage++;
    }
    return stage;
  }

  /// [추가/11-12] 오래 기록하지 않아 물고기가 잠든 상태 (수질 1단계 = 5일 이상)
  bool get fishSleeping => waterStage >= 1;

  /// [변경/11-14] 망각 곡선 가중치: 오늘 = 1.0, 하루마다 0.99배
  double recordWeight(DateTime date) {
    final days = dayOf(DateTime.now()).difference(dayOf(date)).inDays;
    if (days <= 0) return 1.0;
    return math.pow(forgetDailyRate, days).toDouble();
  }

  /// [추가/11-12] 물고기별 '존재감' 0 ~ 1 (원근감에 사용)
  /// 감정 유형별 기록 가중치를 더한 뒤 가장 큰 값으로 나눠요.
  /// 기록이 없으면 모두 1.0 (원근감 없음). 레벨과는 상관없어요.
  /// [변경/11-14] 최근 90일 기록만 반영 (그 이전 기록은 캘린더에만 남아요)
  Map<FishType, double> get fishPresence {
    _sync();
    final today = dayOf(DateTime.now());
    final sum = {for (final t in FishType.values) t: 0.0};
    for (final r in _records) {
      if (today.difference(dayOf(r.date)).inDays > tankWindowDays) continue;
      sum[r.type] = sum[r.type]! + recordWeight(r.date);
    }
    final top = sum.values.fold<double>(0, math.max);
    if (top <= 0) return {for (final t in FishType.values) t: 1.0};
    return {for (final t in FishType.values) t: (sum[t]! / top).clamp(0.0, 1.0)};
  }

  /// 새 분석 결과를 기록에 반영해요. [변경/11-12] 오래된 기록도 지우지 않아요 (망각 곡선 가중치로 대신)
  void _sync() {
    if (!_demoSeeded) {
      _demoSeeded = true;
      _seedDemo();
    }
    final r = AnalysisSession.instance.result;
    if (r != null && !identical(r, _recordedResult)) {
      _recordedResult = r;
      final today = dayOf(DateTime.now());
      final before = _records.isEmpty ? null : today.difference(_records.last.date).inDays;
      if (before != null && before >= waterStageDays.first) welcomeBack = true;
      final existing = _records.where((e) => e.date == today).toList();
      final type = todayType ?? FishType.vitality;
      if (existing.isEmpty) {
        _records.add(DayRecord(date: today, wellness: r.wellnessScore, type: type, area: r.area));
      } else {
        existing.first
          ..wellness = r.wellnessScore
          ..type = type
          ..area = r.area;
      }
    }
    _records.sort((a, b) => a.date.compareTo(b.date));
  }

  void _seedDemo() {
    final last = demoLastRecordDaysAgo;
    if (demoStreakDays <= 0 && last == null) return;
    final end = dayOf(DateTime.now()).subtract(Duration(days: last ?? 0));
    final n = demoStreakDays <= 0 ? 1 : demoStreakDays;
    const sounds = ['물빛의 잔향', '맑은 샘물 소리', '잔잔한 빗소리'];
    for (var i = n - 1; i >= 0; i--) {
      _records.add(DayRecord(
        date: end.subtract(Duration(days: i)),
        wellness: 55.0 + (i * 7) % 35,
        type: FishType.values[i % FishType.values.length],
        area: const ['일/학업', '대인관계', '일/학업', '나 자신', '가족'][i % 5],
        soundTitle: sounds[i % sounds.length],
      ));
    }
  }

  void _attachSoundToToday(String id) {
    final rec = recordOn(DateTime.now());
    final s = soundById(id);
    if (rec != null && s != null) rec.soundTitle = s.title;
  }

  /// [추가/11-06] 이번 주(월~일) 영역별 리포트
  WeeklyReport weeklyReport() {
    _sync();
    final today = dayOf(DateTime.now());
    final start = today.subtract(Duration(days: today.weekday - 1));
    final lastStart = start.subtract(const Duration(days: 7));
    final end = start.add(const Duration(days: 7));

    final thisWeek = _records.where((r) => !r.date.isBefore(start) && r.date.isBefore(end)).toList();
    final lastWeek = _records.where((r) => !r.date.isBefore(lastStart) && r.date.isBefore(start)).toList();

    double? avg(List<DayRecord> list) =>
        list.isEmpty ? null : list.map((r) => r.wellness).reduce((a, b) => a + b) / list.length;

    final grouped = <String, List<DayRecord>>{};
    for (final r in thisWeek) {
      grouped.putIfAbsent(normalizeArea(r.area), () => []).add(r);
    }
    final areas = [for (final e in grouped.entries) AreaStat(e.key, e.value.length, avg(e.value)!)]
      ..sort((a, b) {
        final c = b.count.compareTo(a.count);
        return c != 0 ? c : reportAreas.indexOf(a.area).compareTo(reportAreas.indexOf(b.area));
      });

    final now = avg(thisWeek);
    final before = avg(lastWeek);
    return WeeklyReport(
      weekStart: start,
      days: thisWeek.length,
      avgScore: now,
      diffFromLastWeek: (now != null && before != null) ? now - before : null,
      areas: areas,
    );
  }

  void saveMemo(DateTime day, String memo) {
    final rec = recordOn(day);
    if (rec == null) return;
    rec.memo = memo.trim().isEmpty ? null : memo.trim();
    notifyListeners();
  }

  /// 마이페이지 '데이터 초기화': 기록, 물고기, 문장 노트, 사운드 상태 초기화
  void resetAll() {
    // [추가/11-06] 진행 중인 이전 추천 작업 무효화
    ++_soundResetVersion;

    // [추가/11-06] 초기화 전에 진행 중이던 작업 보관
    final pendingRecommendation = _recommendationTask;
    final previousClear = _soundHistoryClearTask;

    // 기존 날짜별 기록 초기화
    _records.clear();
    _recordedResult = AnalysisSession.instance.result;
    welcomeBack = false;

    // 기존 물고기 성장 초기화
    for (final f in fish.values) {
      f
        ..level = 1
        ..exp = 0;
    }

    // 기존 문장 노트 초기화
    transcripts.clear();
    _rewardedKey = null;
    _phraseKey = null;

    // [추가/11-06] 사운드 추천 상태 초기화
    _recentRecommendedIds.clear();
    _lastRecommendedIds.clear();
    _lastRecommendationDateKst = null;
    _recommendedSounds.clear();

    _recommendedForResult = AnalysisSession.instance.result;

    // [추가/11-06] 선택된 음원과 재생 상태 초기화
    _soundKey = null;
    _todaySoundId = null;
    nowPlayingId = null;
    soundPlaybackError = null;
    _recordedPlaybackRequestId = null;
    bgmPlaying = false;

    // 실제 MP3 재생 중지 및 진행 중인 로딩 요청 취소
    unawaited(stopFirebaseSound());

    // [추가/11-06] 기기에 저장된 추천 이력 삭제
    final clearTask = _clearSavedSoundHistory(
      pendingRecommendation,
      previousClear,
    );

    _soundHistoryClearTask = clearTask;

    unawaited(
      clearTask.catchError((Object error) {
        debugPrint('사운드 추천 이력 삭제 실패: $error');
      }),
    );
    notifyListeners();
  }

  // ── 오늘의 물고기 ──

  static final Object _demoKey = Object();

  /// 오늘의 분석 결과를 가리키는 값. 새로 녹음하면 바뀌어서 새 추천 문구가 나와요.
  Object? get _todayKey => AnalysisSession.instance.result ?? (demoTodayType != null ? _demoKey : null);

  /// 웰니스 스코어에서 가장 높은 유형. 아직 녹음하지 않았으면 null
  FishType? get todayType {
    final r = AnalysisSession.instance.result;
    if (r == null) return demoTodayType;
    final scores = {
      FishType.vitality: r.vitality,
      FishType.calm: r.calm,
      FishType.anxiety: r.anxiety,
      FishType.fatigue: r.fatigue,
    };
    var best = FishType.vitality;
    for (final e in scores.entries) {
      if (e.value > scores[best]!) best = e.key;
    }
    return best;
  }

  // ── 오늘의 추천 문구 ──

  Object? _phraseKey;
  String? _phrase;
  final Map<FishType, int> _nextPhraseIndex = {for (final t in FishType.values) t: 0};

  /// 오늘의 유형에 맞는 추천 문구 (분석 결과 하나당 한 문구, 녹음할 때마다 다음 문구로)
  String? get todayPhrase {
    final type = todayType;
    final key = _todayKey;
    if (type == null || key == null) return null;
    if (!identical(key, _phraseKey)) {
      final list = transcriptPhrases[type]!;
      final i = _nextPhraseIndex[type]!;
      _phrase = list[i % list.length];
      _nextPhraseIndex[type] = i + 1;
      _phraseKey = key;
    }
    return _phrase;
  }

  Object? _rewardedKey;

  /// 오늘의 추천 문구를 이미 필사했는지 (분석 결과 하나당 경험치는 한 번만)
  bool get todayDone {
    final key = _todayKey;
    return key != null && identical(key, _rewardedKey);
  }

  /// 추천 문구 필사 완료 → 오늘의 물고기에 경험치
  TranscriptReward? completeTodayTranscript() {
    final type = todayType;
    final phrase = todayPhrase;
    if (type == null || phrase == null || todayDone) return null;

    _rewardedKey = _todayKey;
    transcripts.insert(0, TranscriptRecord(date: DateTime.now(), phrase: phrase, type: type, soundTitle: _bgmTitleIfPlaying));

    final f = fish[type]!;
    var leveledUp = false;
    if (!f.isMax) {
      f.exp += expPerTranscript;
      while (!f.isMax && f.exp >= f.maxExp) {
        f.exp -= f.maxExp;
        f.level++;
        leveledUp = true;
      }
      if (f.isMax) f.exp = f.maxExp; // 만렙이면 게이지를 꽉 채워 보여 줘요
    } else {
      f.shine += expPerTranscript; // [추가/11-12] Lv5 이후 경험치는 빛으로
    }
    notifyListeners();
    return TranscriptReward(type: type, gainedExp: expPerTranscript, leveledUp: leveledUp, level: f.level);
  }

  /// 작은 행운(홈) 필사 저장 — 감정 카테고리가 없어서 경험치는 없어요
  void addLuckyTranscript(String phrase) {
    transcripts.insert(0, TranscriptRecord(date: DateTime.now(), phrase: phrase, soundTitle: _bgmTitleIfPlaying));
    notifyListeners();
  }

  // ── 그날의 음원 (어항 배경음) ──
  // [변경/11-01] 수집 음원 중 고르기 → '그날의 음원'을 어항에서 다시 듣기로 변경

  /// 지금 재생 화면에서 듣는 음원 (사운드 추천 → 재생으로 넘길 때 사용)
  String? nowPlayingId;

  /// 오늘 분석 뒤에 직접 들은 음원
  Object? _soundKey;
  String? _todaySoundId;

  bool bgmPlaying = false;
  // ── [추가/11-06] 실제 음원 재생 상태 ──
  final AudioPlayer _soundPlayer = AudioPlayer();

  /// 실제 음원 재생 상태
  Stream<PlayerState> get soundPlayerStateStream =>
      _soundPlayer.playerStateStream;

  /// 실제 음원 재생 위치
  Stream<Duration> get soundPositionStream =>
      _soundPlayer.positionStream;

  Duration get soundPosition =>
      _loadedSoundId == nowPlayingId
          ? _soundPlayer.position
          : Duration.zero;

  /// 실제 음원 길이 (확인할 수 없으면 Firestore 길이 사용)
  Duration get soundDuration =>
      _soundPlayer.duration ??
          Duration(
            seconds: soundById(nowPlayingId)?.durationSeconds ?? 0,
          );

  /// 음원 재생 완료 여부
  bool get soundCompleted =>
      _soundPlayer.processingState == ProcessingState.completed;

  /// ── [추가/11-06] Firebase MP3 재생 ──

  int _soundRequestId = 0;
  String? _loadedSoundId;
  int? _recordedPlaybackRequestId;

  bool _soundLoading = false;
  String? soundPlaybackError;

  Future<void> _soundQueue = Future<void>.value();

  StreamSubscription<PlayerState>? _soundStateSub;
  StreamSubscription<PlayerException>? _soundErrorSub;

  bool get soundLoading => _soundLoading;

  void _watchSoundState() {
    _soundStateSub ??=
        _soundPlayer.playerStateStream.listen((state) {
          if (state.processingState == ProcessingState.completed) {
            bgmPlaying = false;

            if (state.playing) {
              unawaited(_soundPlayer.pause());
            }
          } else {
            bgmPlaying = state.playing &&
                state.processingState == ProcessingState.ready;
            // 실제 재생이 시작되었을 때만 날짜별 기록 반영
            if (bgmPlaying &&
                _loadedSoundId != null &&
                _recordedPlaybackRequestId != _soundRequestId &&
                _lastRecommendationDateKst == _koreanDateKey() &&
                _recommendedSounds.any(
                      (sound) => sound.id == _loadedSoundId,
                )) {
              _attachSoundToToday(_loadedSoundId!);
              _recordedPlaybackRequestId = _soundRequestId;
            }
          }
          notifyListeners();
        });

    _soundErrorSub ??=
        _soundPlayer.errorStream.listen((error) {
          soundPlaybackError = '음원을 재생하는 중 오류가 발생했어요.';
          bgmPlaying = false;
          notifyListeners();
        });
  }

  /// Firebase Storage에서 MP3를 불러와 처음부터 재생
  Future<void> playFirebaseSound(String id) async {
    final sound = soundById(id);

    if (sound == null ||
        sound.audioPath == null ||
        sound.audioPath!.trim().isEmpty) {
      throw StateError('재생할 음원 정보가 없어요.');
    }

    final request = ++_soundRequestId;

    final task = _soundQueue.then(
          (_) => _loadAndPlaySound(sound, request),
    );

    _soundQueue = task.catchError((Object _) {});

    await task;
  }

  Future<void> _loadAndPlaySound(
      SoundItem sound,
      int request,
      ) async {
    if (request != _soundRequestId) return;

    _watchSoundState();

    _loadedSoundId = null; //추가

    _soundLoading = true;
    soundPlaybackError = null;
    notifyListeners();

    try {
      await _soundPlayer.stop();

      final url = await FirebaseStorage.instance
          .ref()
          .child(sound.audioPath!)
          .getDownloadURL();

      if (request != _soundRequestId) return;

      await _soundPlayer.setLoopMode(LoopMode.off);
      await _soundPlayer.setUrl(url);

      if (request != _soundRequestId) return;

      _loadedSoundId = sound.id; //추가
      nowPlayingId = sound.id;

      unawaited(
        _soundPlayer.play().catchError((Object error) {
          if (request != _soundRequestId) return;

          soundPlaybackError = '음원을 재생하지 못했어요.';
          bgmPlaying = false;
          notifyListeners();
        }),
      );
    } catch (error) {
      if (request != _soundRequestId) return;

      _loadedSoundId = null;

      soundPlaybackError =
      '음원을 불러오지 못했어요. 인터넷 연결을 확인해 주세요.';

      bgmPlaying = false;
      notifyListeners();

      rethrow;
    } finally {
      if (request == _soundRequestId) {
        _soundLoading = false;
        notifyListeners();
      }
    }
  }

  // ── [추가/11-06] 사운드 추천 이력 저장 ──
  final List<String> _recentRecommendedIds = [];
  final List<String> _lastRecommendedIds = [];
  String? _lastRecommendationDateKst;

  /// 최근 추천된 음원 ID 최대 6개 (오래된 순)
  List<String> get recentRecommendedIds =>
      List.unmodifiable(_recentRecommendedIds);

  /// 마지막으로 추천된 음원 ID 3개
  List<String> get lastRecommendedIds =>
      List.unmodifiable(_lastRecommendedIds);

  /// 마지막 추천 날짜 (한국 시간)
  String? get lastRecommendationDateKst =>
      _lastRecommendationDateKst;

  String _koreanDateKey() {
    final kst = DateTime.now().toUtc().add(const Duration(hours: 9));

    final year = kst.year.toString().padLeft(4, '0');
    final month = kst.month.toString().padLeft(2, '0');
    final day = kst.day.toString().padLeft(2, '0');

    return '$year-$month-$day';
  }

  Future<File?> _soundRecommendationFile() async {
    // Chrome에서는 기기 파일 저장 기능을 사용하지 않음
    if (kIsWeb) return null;

    final uid = FirebaseAuth.instance.currentUser?.uid;

    if (uid == null) return null;

    final directory = await getApplicationSupportDirectory();

    return File(
      '${directory.path}${Platform.pathSeparator}sound_recommendations_$uid.json',
    );
  }
  /// [추가/11-06] 데이터 초기화 시 저장된 사운드 추천 이력 삭제
  Future<void> _clearSavedSoundHistory(
      Future<void>? pendingRecommendation,
      Future<void>? previousClear,
      ) async {
    // 이전 삭제 작업이 있다면 완료될 때까지 대기
    if (previousClear != null) {
      try {
        await previousClear;
      } catch (_) {}
    }

    // 진행 중이던 추천 저장 작업이 끝날 때까지 대기
    if (pendingRecommendation != null) {
      try {
        await pendingRecommendation;
      } catch (_) {}
    }

    try {
      // 현재 익명 로그인 사용자의 추천 이력 파일만 삭제
      final file = await _soundRecommendationFile();

      if (file != null && await file.exists()) {
        await file.delete();
      }
    } finally {
      // 이전 작업이 남긴 메모리 상태까지 정리
      _recentRecommendedIds.clear();
      _lastRecommendedIds.clear();
      _lastRecommendationDateKst = null;
      _recommendedSounds.clear();

      notifyListeners();
    }
  }

  /// 기기에 저장된 추천 이력과 마지막 추천곡 ID 복원
  Future<void> restoreRecommendedSoundIds() async {
    // [추가/11-06] 초기화 중인 경우 이전 이력 복원 방지
    final versionAtStart = _soundResetVersion;

    final pendingClear = _soundHistoryClearTask;

    if (pendingClear != null) {
      await pendingClear;
    }

    if (versionAtStart != _soundResetVersion) return;

    final file = await _soundRecommendationFile();

    if (file == null || !await file.exists()) return;

    final decoded = jsonDecode(await file.readAsString());

    if (decoded is! Map<String, dynamic>) {
      throw const FormatException('저장된 사운드 추천 정보가 올바르지 않아요.');
    }

    final rawRecent = decoded['recentIds'];
    final rawLast = decoded['lastIds'];

    final restoredRecent = rawRecent is List
        ? rawRecent.whereType<String>().toList()
        : <String>[];

    final restoredLast = rawLast is List
        ? rawLast.whereType<String>().toList()
        : <String>[];

    final uniqueRecent = <String>[];

    for (final id in restoredRecent) {
      if (id.isEmpty) continue;

      uniqueRecent.remove(id);
      uniqueRecent.add(id);
    }

    if (uniqueRecent.length > 6) {
      uniqueRecent.removeRange(0, uniqueRecent.length - 6);
    }

    if (restoredLast.length != 3 ||
        restoredLast.toSet().length != 3 ||
        restoredLast.any((id) => id.isEmpty)) {
      restoredLast.clear();
    }

    // [추가/11-06] 파일을 읽는 도중 초기화됐다면 복원 취소
    if (versionAtStart != _soundResetVersion) return;

    _recentRecommendedIds
      ..clear()
      ..addAll(uniqueRecent);

    _lastRecommendedIds
      ..clear()
      ..addAll(restoredLast);

    final savedDate = decoded['dateKst'];

    _lastRecommendationDateKst =
    restoredLast.isNotEmpty && savedDate is String
        ? savedDate
        : null;

    notifyListeners();
  }

  /// 새로운 추천 3곡의 ID를 기기에 저장
  Future<void> saveRecommendedSoundIds(List<String> ids) async {
    if (ids.length != 3 ||
        ids.toSet().length != 3 ||
        ids.any((id) => id.isEmpty)) {
      throw ArgumentError('서로 다른 추천 음원 ID 3개가 필요해요.');
    }

    final file = await _soundRecommendationFile();

    if (file == null && !kIsWeb) {
      throw StateError('사운드 추천 이력을 저장하려면 익명 로그인이 필요해요.');
    }

    final recent = List<String>.from(_recentRecommendedIds);

    for (final id in ids) {
      recent.remove(id);
      recent.add(id);
    }

    if (recent.length > 6) {
      recent.removeRange(0, recent.length - 6);
    }

    final dateKst = _koreanDateKey();

    if (file != null) {
      await file.writeAsString(
        jsonEncode({
          'recentIds': recent,
          'lastIds': ids,
          'dateKst': dateKst,
        }),
        flush: true,
      );
    }

    _recentRecommendedIds
      ..clear()
      ..addAll(recent);

    _lastRecommendedIds
      ..clear()
      ..addAll(ids);

    _lastRecommendationDateKst = dateKst;

    notifyListeners();
  }

  // ── [추가/11-06] Firebase 추천 음원 복원 ──
  final List<SoundItem> _recommendedSounds = [];

  /// 가장 최근에 추천된 실제 음원 3개
  List<SoundItem> get recommendedSounds =>
      List.unmodifiable(_recommendedSounds);

  /// 저장된 추천곡 ID로 Firestore 음원 정보 복원
  Future<void> restoreLastRecommendedSounds() async {
    // [추가/11-06] 복원 시작 시점의 초기화 상태 확인
    final versionAtStart = _soundResetVersion;

    await restoreRecommendedSoundIds();

    // 복원 도중 데이터가 초기화됐다면 중단
    if (versionAtStart != _soundResetVersion) return;

    final ids = lastRecommendedIds;

    if (ids.isEmpty) {
      _recommendedSounds.clear();
      notifyListeners();
      return;
    }

    final documents =
    await SoundRecommendationService().loadSoundsByIds(ids);

    // [추가/11-06] 음원 정보를 불러오는 도중 초기화됐다면 복원 취소
    if (versionAtStart != _soundResetVersion) return;

    final soundsById = <String, SoundItem>{};

    for (final document in documents) {
      if (document.exists) {
        soundsById[document.id] = SoundItem.fromDocument(document);
      }
    }

    if (ids.any((id) => !soundsById.containsKey(id))) {
      throw StateError('저장된 추천 음원 정보를 불러오지 못했어요.');
    }

    _recommendedSounds
      ..clear()
      ..addAll([
        for (final id in ids) soundsById[id]!,
      ]);

    notifyListeners();
  }

  // ── [추가/11-06] 감정 분석 결과에 따른 사운드 추천 ──
  AnalysisResult? _recommendedForResult;
  AnalysisResult? _requestingForResult;
  Future<void>? _recommendationTask;

  // [추가/11-06] 데이터 초기화 이후 이전 추천 작업 결과 무시
  int _soundResetVersion = 0;

  // [추가/11-06] 저장된 추천 이력 삭제 작업 관리
  Future<void>? _soundHistoryClearTask;

  bool get soundRecommendationLoading =>
      _recommendationTask != null;

  /// 현재 감정 분석 결과에 맞는 음원 3개 추천
  Future<void> recommendSoundsForCurrentResult() async {
    // [추가/11-06] 이전 추천 이력 삭제가 끝난 후 새 추천 시작
    final pendingClear = _soundHistoryClearTask;

    if (pendingClear != null) {
      await pendingClear;
    }

    final result = AnalysisSession.instance.result;

    if (result == null) return;

    if (identical(result, _recommendedForResult)) return;

    final pending = _recommendationTask;

    if (pending != null) {
      if (identical(result, _requestingForResult)) {
        await pending;
        return;
      }

      try {
        await pending;
      } catch (_) {}

      await recommendSoundsForCurrentResult();
      return;
    }

    _requestingForResult = result;
    _recommendedSounds.clear();

    final task = _generateRecommendedSounds(result);
    _recommendationTask = task;

    notifyListeners();

    try {
      await task;
    } finally {
      _recommendationTask = null;
      _requestingForResult = null;
      notifyListeners();
    }
  }

  Future<void> _generateRecommendedSounds(
      AnalysisResult result,
      ) async {
    final versionAtStart = _soundResetVersion;
    final documents =
    await SoundRecommendationService().recommendSounds(
      result: result,
      recentSoundIds: recentRecommendedIds,
    );

    final sounds = [
      for (final document in documents)
        SoundItem.fromDocument(document),
    ];

    if (sounds.length != 3 ||
        sounds.map((sound) => sound.id).toSet().length != 3) {
      throw StateError('서로 다른 추천 음원 3개를 가져오지 못했어요.');
    }

    if (versionAtStart != _soundResetVersion ||
        !identical(result, AnalysisSession.instance.result)) {
      return;
    }

    await saveRecommendedSoundIds(
      sounds.map((sound) => sound.id).toList(),
    );

    if (versionAtStart != _soundResetVersion ||
        !identical(result, AnalysisSession.instance.result)) {
      return;
    }

    _recommendedSounds
      ..clear()
      ..addAll(sounds);

    _recommendedForResult = result;

    notifyListeners();
  }

  /// 가장 최근 추천된 음원 (어항에서 선택한 곡이 있으면 해당 곡)
  /// - 새 감정 분석 결과에서는 메인 추천곡을 기본으로 보여줘요.
  /// - 앱 재실행 후에도 저장된 추천곡이 있으면 보여줘요.
  /// - 추천 이력이 없으면 null
  SoundItem? get todaySound {
    if (_recommendedSounds.isEmpty) return null;

    if (_soundKey == null || identical(_soundKey, _todayKey)) {
      for (final sound in _recommendedSounds) {
        if (sound.id == _todaySoundId) return sound;
      }
    }

    return _recommendedSounds.first;
  }

  /// 어항에서 고를 수 있는 가장 최근 추천 음원 3곡
  List<SoundItem> get todaySounds {
    if (_recommendedSounds.isEmpty) return const [];

    return List.unmodifiable(_recommendedSounds);
  }

  // ── [변경/11-06] 실제 사운드 재생 연결 ──

  /// 어항에서 최근 추천곡 중 하나를 선택하고 재생
  void selectTodaySound(String id) {
    if (!_recommendedSounds.any((sound) => sound.id == id)) return;

    _soundKey = _todayKey;
    _todaySoundId = id;

    startSound(id);
  }

  /// 필사 저장 시 실제 재생 중인 음원 제목 연결
  String? get _bgmTitleIfPlaying =>
      bgmPlaying ? soundById(_loadedSoundId)?.title : null;

  /// 사운드 추천 화면에서 선택한 음원 재생
  void startSound(String id, {bool notify = true}) {
    // 동일한 음원을 불러오는 중이면 중복 요청 방지
    if (_soundLoading && nowPlayingId == id) return;
    // 동일한 음원이 재생 중이면 기존 위치 유지
    if (_loadedSoundId == id &&
        _soundPlayer.processingState != ProcessingState.idle &&
        !soundCompleted &&
        _soundPlayer.playing) {
      return;
    }
    // 일시정지된 음원을 다시 선택하거나 다른 음원을 선택하면 처음부터 재생
    _loadedSoundId = null;
    bgmPlaying = false;

    nowPlayingId = id;

    if (_recommendedSounds.any((sound) => sound.id == id)) {
      _soundKey = _todayKey;
      _todaySoundId = id;
    }

    if (notify) notifyListeners();

    unawaited(
      playFirebaseSound(id).catchError((Object error) {
        if (nowPlayingId != id) return;

        soundPlaybackError ??= '음원을 재생하지 못했어요.';
        bgmPlaying = false;
        notifyListeners();
      }),
    );
  }

  /// 어항·문장 노트 미니플레이어 재생/일시정지
  void toggleBgm() {
    final sound = todaySound;

    if (sound == null || _soundLoading) return;

    // 다른 곡이 선택됐거나 플레이어가 정지된 경우 새로 불러오기
    if (_loadedSoundId != sound.id ||
        _soundPlayer.processingState == ProcessingState.idle) {
      startSound(sound.id);
      return;
    }

    // 재생 중이면 실제 플레이어 일시정지
    if (_soundPlayer.playing && !soundCompleted) {
      unawaited(
        _soundPlayer.pause().catchError((Object error) {
          soundPlaybackError = '음원을 일시정지하지 못했어요.';
          notifyListeners();
        }),
      );
    } else {
      // 일시정지 또는 재생 완료 상태라면 다시 재생
      unawaited(_resumeFirebaseSound());
    }
  }

  /// 일시정지된 음원 이어 듣기 / 완료된 음원 처음부터 다시 듣기
  Future<void> _resumeFirebaseSound() async {
    final request = _soundRequestId;

    try {
      if (soundCompleted) {
        await _soundPlayer.seek(Duration.zero);

        if (request != _soundRequestId) return;
      }

      unawaited(
        _soundPlayer.play().catchError((Object error) {
          if (request != _soundRequestId) return;

          soundPlaybackError = '음원을 다시 재생하지 못했어요.';
          bgmPlaying = false;
          notifyListeners();
        }),
      );
    } catch (error) {
      if (request != _soundRequestId) return;

      soundPlaybackError = '음원을 다시 재생하지 못했어요.';
      bgmPlaying = false;
      notifyListeners();
    }
  }

  /// 음원 재생 중지
  Future<void> stopFirebaseSound() async {
    ++_soundRequestId;

    _loadedSoundId = null;
    _soundLoading = false;
    bgmPlaying = false;

    notifyListeners();

    try {
      await _soundPlayer.stop();
    } catch (error) {
      soundPlaybackError = '음원을 중지하지 못했어요.';
      notifyListeners();
    }
  }
}
