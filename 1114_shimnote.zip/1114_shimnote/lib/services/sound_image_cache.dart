import 'package:firebase_storage/firebase_storage.dart';

class SoundImageCache {
  SoundImageCache._();

  static final Map<String, Future<String>> _urlCache = {};

  static Future<String> getUrl(String path) {
    return _urlCache.putIfAbsent(path, () async {
      try {
        return await FirebaseStorage.instance
            .ref()
            .child(path)
            .getDownloadURL();
      } catch (_) {
        _urlCache.remove(path);
        rethrow;
      }
    });
  }
}