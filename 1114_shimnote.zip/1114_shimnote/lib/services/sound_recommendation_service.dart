import 'dart:math';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'analysis_service.dart';

// ───────────────────────── 사운드 추천 조건 ─────────────────────────
class SoundCondition {
  const SoundCondition(this.direction, this.moodTag);

  final String direction;
  final String moodTag;
}

class SoundRecommendationException implements Exception {
  const SoundRecommendationException(this.message);

  final String message;

  @override
  String toString() => message;
}

// ───────────────────────── 사운드 추천 로직 ─────────────────────────
class SoundRecommendationService {
  SoundRecommendationService({
    FirebaseFirestore? firestore,
    Random? random,
  })  : _firestore = firestore ?? FirebaseFirestore.instance,
        _random = random ?? Random();

  final FirebaseFirestore _firestore;
  final Random _random;

  static const double _scoreDifferenceThreshold = 0.05;

  // [추가/11-06] 기존 Hume 48개 감정 매핑표 기준
  static const Map<String, SoundCondition> _emotionConditions = {
    'admiration': SoundCondition('몰입', '깊이감'),
    'adoration': SoundCondition('몰입', '깊이감'),
    'aesthetic appreciation': SoundCondition('몰입', '신비로움'),
    'amusement': SoundCondition('활력', '생동감'),
    'anger': SoundCondition('진정', '나른함'),
    'anxiety': SoundCondition('안정', '차분함'),
    'awe': SoundCondition('몰입', '신비로움'),
    'awkwardness': SoundCondition('안정', '잔잔함'),
    'boredom': SoundCondition('회복', '산뜻함'),
    'calmness': SoundCondition('평온', '여유로움'),
    'concentration': SoundCondition('집중', '담백함'),
    'contemplation': SoundCondition('사색', '몽환적'),
    'confusion': SoundCondition('안정', '잔잔함'),
    'contempt': SoundCondition('진정', '차분함'),
    'contentment': SoundCondition('평온', '여유로움'),
    'craving': SoundCondition('몰입', '깊이감'),
    'desire': SoundCondition('몰입', '깊이감'),
    'determination': SoundCondition('집중', '명료함'),
    'disappointment': SoundCondition('위로', '부드러움'),
    'disgust': SoundCondition('진정', '고요함'),
    'distress': SoundCondition('안정', '차분함'),
    'doubt': SoundCondition('안정', '잔잔함'),
    'ecstasy': SoundCondition('몰입', '몽환적'),
    'embarrassment': SoundCondition('안정', '편안함'),
    'empathic pain': SoundCondition('위로', '따뜻함'),
    'entrancement': SoundCondition('몰입', '몽환적'),
    'envy': SoundCondition('진정', '차분함'),
    'excitement': SoundCondition('활력', '생동감'),
    'fear': SoundCondition('안정', '차분함'),
    'guilt': SoundCondition('위로', '포근함'),
    'horror': SoundCondition('안정', '차분함'),
    'interest': SoundCondition('몰입', '깊이감'),
    'joy': SoundCondition('활력', '밝음'),
    'love': SoundCondition('몰입', '깊이감'),
    'nostalgia': SoundCondition('사색', '쓸쓸함'),
    'pain': SoundCondition('위로', '부드러움'),
    'pride': SoundCondition('활력', '밝음'),
    'realization': SoundCondition('사색', '아련함'),
    'relief': SoundCondition('평온', '편안함'),
    'romance': SoundCondition('몰입', '몽환적'),
    'sadness': SoundCondition('위로', '부드러움'),
    'satisfaction': SoundCondition('평온', '부드러움'),
    'shame': SoundCondition('위로', '포근함'),
    'surprise (negative)': SoundCondition('안정', '편안함'),
    'surprise (positive)': SoundCondition('활력', '청량함'),
    'sympathy': SoundCondition('위로', '따뜻함'),
    'tiredness': SoundCondition('회복', '청량함'),
    'triumph': SoundCondition('활력', '밝음'),

    // 기존 API에서 사용할 수 있는 감정 이름 표기도 함께 처리
    'surprise_negative': SoundCondition('안정', '편안함'),
    'surprise_positive': SoundCondition('활력', '청량함'),
  };

  SoundCondition _conditionForEmotion(String emotion) {
    final key = emotion.trim().toLowerCase();
    final condition = _emotionConditions[key];

    if (condition == null) {
      throw SoundRecommendationException(
        '추천 기준에 없는 감정이에요: $emotion',
      );
    }

    return condition;
  }

  // 대표 구간의 1·2위 감정으로 추천 조건 선정
  List<SoundCondition> conditionsFor(AnalysisResult result) {
    final scores = result.representativeScores.entries.toList();

    if (scores.length < 2 || scores.any((e) => !e.value.isFinite)) {
      throw const SoundRecommendationException(
        '대표 구간의 감정 점수를 확인할 수 없어요.',
      );
    }

    scores.sort((a, b) => b.value.compareTo(a.value));

    final first = scores[0];
    final second = scores[1];

    final firstCondition = _conditionForEmotion(first.key);
    final secondCondition = _conditionForEmotion(second.key);

    final difference = first.value - second.value;

    if (difference > _scoreDifferenceThreshold) {
      return [firstCondition];
    }

    // 두 감정의 추천 방향이 같으면 1위 감정의 태그만 사용
    if (firstCondition.direction == secondCondition.direction) {
      return [firstCondition];
    }

    return [firstCondition, secondCondition];
  }

  // Firestore에서 조건에 맞는 메인 1곡 + 서브 2곡 선정
  Future<List<DocumentSnapshot<Map<String, dynamic>>>> recommendSounds({
    required AnalysisResult result,
    required List<String> recentSoundIds,
  }) async {
    final conditions = conditionsFor(result);

    // 최근 추천 이력은 오래된 순서로 전달받음
    final recent = recentSoundIds.length > 6
        ? recentSoundIds.sublist(recentSoundIds.length - 6)
        : recentSoundIds;

    final recentSet = recent.toSet();

    final selected = <DocumentSnapshot<Map<String, dynamic>>>[];
    final selectedIds = <String>{};

    for (var i = 0; i < conditions.length; i++) {
      final condition = conditions[i];

      // 추천 방향 1개면 3곡, 2개면 1위에서 2곡 + 2위에서 1곡
      final requiredCount =
      conditions.length == 1 ? 3 : (i == 0 ? 2 : 1);

      QuerySnapshot<Map<String, dynamic>> snapshot;

      try {
        snapshot = await _firestore
            .collection('sounds')
            .where('direction', isEqualTo: condition.direction)
            .where('mood_tag', isEqualTo: condition.moodTag)
            .get();
      } on FirebaseException catch (e) {
        throw SoundRecommendationException(
          '추천 음원을 불러오지 못했어요. (${e.code})',
        );
      }

      // 하나의 추천 결과 안에서 음원 ID 중복 방지
      final candidates = snapshot.docs
          .where((doc) => !selectedIds.contains(doc.id))
          .toList();

      if (candidates.isEmpty) {
        throw SoundRecommendationException(
          '${condition.direction}·${condition.moodTag} 조건에 맞는 음원이 없어요.',
        );
      }

      // 최근 추천 6곡을 제외한 후보 중 무작위 선정
      final fresh = <DocumentSnapshot<Map<String, dynamic>>>[
        for (final doc in candidates)
          if (!recentSet.contains(doc.id)) doc,
      ]..shuffle(_random);

      final chosen = fresh.take(requiredCount).toList();

      // 부족하면 가장 오래된 추천 음원부터 다시 포함
      if (chosen.length < requiredCount) {
        final candidatesById = {
          for (final doc in candidates) doc.id: doc,
        };

        for (final id in recent) {
          if (chosen.length >= requiredCount) break;

          final doc = candidatesById[id];

          if (doc != null && !chosen.any((s) => s.id == id)) {
            chosen.add(doc);
          }
        }
      }

      if (chosen.length < requiredCount) {
        throw SoundRecommendationException(
          '${condition.direction}·${condition.moodTag} 음원이 부족해요.',
        );
      }

      selected.addAll(chosen);
      selectedIds.addAll(chosen.map((doc) => doc.id));
    }

    if (selected.length != 3 || selectedIds.length != 3) {
      throw const SoundRecommendationException(
        '추천 음원 3곡을 선정하지 못했어요.',
      );
    }

    // 첫 번째 음원이 메인 추천곡
    return List.unmodifiable(selected);
  }

  // 저장된 최근 추천 3곡의 ID로 음원 정보 다시 불러오기
  Future<List<DocumentSnapshot<Map<String, dynamic>>>> loadSoundsByIds(
      List<String> soundIds,
      ) async {
    if (soundIds.isEmpty) return [];

    try {
      final sounds = await Future.wait(
        soundIds.map(
              (id) => _firestore.collection('sounds').doc(id).get(),
        ),
      );

      for (final sound in sounds) {
        if (!sound.exists) {
          throw SoundRecommendationException(
            '저장된 음원 ${sound.id}을 찾지 못했어요.',
          );
        }
      }

      return sounds;
    } on FirebaseException catch (e) {
      throw SoundRecommendationException(
        '저장된 추천 음원을 불러오지 못했어요. (${e.code})',
      );
    }
  }
}
