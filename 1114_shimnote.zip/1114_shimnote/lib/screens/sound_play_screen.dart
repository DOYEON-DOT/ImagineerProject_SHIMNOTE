import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../navigation/app_routes.dart';
import '../navigation/nav.dart';
import '../services/growth_store.dart';
import '../theme/app_colors.dart';
import '../theme/app_text.dart';
import '../widgets/animations.dart';
import '../widgets/app_icons.dart';
import '../widgets/common.dart';

/// 8. 사운드 재생
/// - 뒤로가기 → 7. 사운드 추천
/// - 재생/일시정지 토글, 힐링 타이머 카운트다운
/// - 힐링 종료 → 3. 메인(홈)
class SoundPlayScreen extends StatefulWidget {
  const SoundPlayScreen({super.key});

  @override
  State<SoundPlayScreen> createState() => _SoundPlayScreenState();
}

class _SoundPlayScreenState extends State<SoundPlayScreen> {
  bool _playing = false;
  int _remain = 0; // 선택한 음원의 길이로 초기화
  Timer? _timer;

  /// [변경/11-01] 사운드 추천에서 고른 음원 (없으면 기본 음원)
  late final SoundItem? _sound;

  @override
  void initState() {
    super.initState();
    final store = GrowthStore.instance;
    // [변경/11-06] 추천 화면에서 선택한 실제 음원 정보 사용
    _sound = soundById(store.nowPlayingId);

    // 선택한 음원의 전체 길이에서 실제 재생된 시간 차감
    final totalSeconds = _sound?.durationSeconds ?? 0;
    final elapsedSeconds = store.soundPosition.inSeconds;

    _remain = totalSeconds > elapsedSeconds
        ? totalSeconds - elapsedSeconds
        : 0;

    // [추가/11-06] 실제 음원 재생 상태와 화면 연결
    _playing = store.bgmPlaying;
    store.addListener(_onSoundChanged);

    // [변경/11-06] 힐링 타이머 종료 시 실제 음원 중지
    _startTimer();
  }
    // 힐링 타이머 시작 및 재시작
    void _startTimer() {
      _timer?.cancel();

      _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
        if (!mounted || !_playing || _remain <= 0) return;

        if (_remain <= 1) {
          setState(() {
            _remain = 0;
          });

          timer.cancel();

          unawaited(GrowthStore.instance.stopFirebaseSound());
        } else {
          setState(() {
            _remain--;
          });
        }
      });
    }

  // [변경/11-06] 실제 음원 재생 상태와 타이머 동기화
  void _onSoundChanged() {
    if (!mounted) return;

    final store = GrowthStore.instance;
    final playing = store.bgmPlaying;
    final completed = store.soundCompleted;

    if (_playing != playing || (completed && _remain > 0)) {
      // 실제 음원 재생이 완료되었다면 타이머 종료
      if (completed) {
        _timer?.cancel();
      }

      setState(() {
        _playing = playing;

        if (completed) {
          _remain = 0;
        }
      });
    }
  }

  @override
  void dispose() {
    GrowthStore.instance.removeListener(_onSoundChanged);
    _timer?.cancel();
    super.dispose();
  }

  String get _remainText => '${_remain ~/ 60}분 ${_remain % 60}초 남음';

  @override
  Widget build(BuildContext context) {
    const light = Color(0xFFCFE6E2);
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle.light,
      child: Scaffold(
        body: Container(
          width: double.infinity,
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment(-0.6, -1),
              end: Alignment(0.6, 1),
              colors: [Color(0xFF1D3F3C), Color(0xFF0F2624)],
            ),
          ),
          padding: EdgeInsets.fromLTRB(24, topPad(context, 28), 24, bottomPad(context, 44)),
          child: Column(
            children: [
              CenterTitleHeader(
                title: '힐링 중',
                color: AppColors.white,
                fontSize: 15,
                backSize: 22,
                onBack: () => Nav.backTo(context, AppRoutes.soundRecommend),
              ),
              const SizedBox(height: 28),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                decoration: BoxDecoration(
                  color: AppColors.alpha(AppColors.white, 0.08),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Row(
                  children: [
                    Svg(AppIcons.clock(light), size: 14),
                    const SizedBox(width: 6),
                    Text('힐링 타이머', style: ts(12, color: light)),
                    const Spacer(),
                    Text(_remainText, style: ts(13, weight: bold, color: AppColors.white)),
                  ],
                ),
              ),
              const SizedBox(height: 40),
              Expanded(
                child: ShrinkToFit(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      SizedBox(
                        width: 270,
                        height: 270,
                        child: Stack(
                          alignment: Alignment.center,
                          clipBehavior: Clip.none,
                          children: [
                            if (_playing)
                              RippleRings(
                                ringSize: 210,
                                color: AppColors.alpha(AppColors.white, 0.35),
                                duration: const Duration(milliseconds: 3200),
                                scaleFrom: 0.75,
                                scaleTo: 1.9,
                                opacityFrom: 0.5,
                              ),
                            Container(
                              width: 160,
                              height: 160,
                              alignment: Alignment.center,
                              decoration: BoxDecoration(
                                color: AppColors.alpha(AppColors.white, 0.12),
                                shape: BoxShape.circle,
                              ),
                              child: Container(
                                width: 110,
                                height: 110,
                                alignment: Alignment.center,
                                decoration: BoxDecoration(
                                  color: AppColors.alpha(AppColors.white, 0.16),
                                  shape: BoxShape.circle,
                                ),
                                child: Svg(AppIcons.drop(AppColors.white), size: 60),
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 26),
                      Text(
                        _sound?.title ?? '재생할 사운드를 선택해 주세요.',
                        style: ts(18, weight: bold, color: AppColors.white),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        _sound?.desc ?? '사운드 추천 화면에서 음원을 선택해 주세요.',
                        style: ts(13, color: const Color(0xFFB9D4CF)),
                      ),
                      const SizedBox(height: 26),
                      Svg(AppIcons.waveLine(AppColors.alpha(AppColors.white, 0.35)), size: 140, height: 24),
                      const SizedBox(height: 26),
                      Tap(
                        onTap: () async {
                          final store = GrowthStore.instance;

                          // 음원 재생이 완료되었다면 처음부터 다시 재생
                          if (_remain <= 0 || store.soundCompleted) {
                            final sound = _sound;
                            if (sound == null) return;
                            await store.stopFirebaseSound();
                            if (!mounted) return;
                            setState(() {
                              _remain = sound.durationSeconds;
                              _playing = false;
                            });
                            _startTimer();
                            store.startSound(sound.id);
                            return;
                          }

                          store.toggleBgm();
                        },
                        child: Container(
                          width: 48,
                          height: 48,
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                            color: AppColors.alpha(AppColors.white, 0.14),
                            shape: BoxShape.circle,
                          ),
                          child: Svg(
                            _playing ? AppIcons.pause(AppColors.white) : AppIcons.play(AppColors.white),
                            size: 18,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Tap(
                onTap: () async {
                  // [변경/11-06] 힐링 종료 시 실제 음원 재생 중지
                  await GrowthStore.instance.stopFirebaseSound();
                  if (!context.mounted) return;
                  Nav.resetTo(context, AppRoutes.home);
                },
                child: Text('힐링 종료',
                    style: ts(13, weight: bold, color: light, decoration: TextDecoration.underline)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
