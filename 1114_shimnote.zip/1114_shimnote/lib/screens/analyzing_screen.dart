// [변경/10-26] 실제 분석 결과를 기다렸다가 이동

import 'dart:async';

import 'package:flutter/material.dart';

import '../navigation/app_routes.dart';
import '../navigation/nav.dart';
import '../services/analysis_service.dart';
import '../theme/app_colors.dart';
import '../theme/app_text.dart';
import '../widgets/animations.dart';
import '../widgets/app_icons.dart';
import '../widgets/common.dart';

class AnalyzingScreen extends StatefulWidget {
  const AnalyzingScreen({super.key});

  @override
  State<AnalyzingScreen> createState() => _AnalyzingScreenState();
}

class _AnalyzingScreenState extends State<AnalyzingScreen> {
  final AnalysisSession _session = AnalysisSession.instance;
  Timer? _slowTimer;
  Timer? _timeoutTimer;
  bool _moved = false;
  AnalysisStatus? _lastStatus;
  int _lastPhase = 0;
  String _subText = '약간의 시간이 소요될 수 있어요.\n잠시만 기다려주세요';

  @override
  void initState() {
    super.initState();
    _session.screenWatching = true;
    _lastStatus = _session.status;
    _lastPhase = _session.waitPhase;
    _session.addListener(_onChanged);
    _startTimers();
    WidgetsBinding.instance.addPostFrameCallback((_) => _onChanged());
  }

  void _startTimers() {
    _slowTimer?.cancel();
    _timeoutTimer?.cancel();
    _subText = '약간의 시간이 소요될 수 있어요.\n잠시만 기다려주세요';
    _slowTimer = Timer(const Duration(seconds: 3), () {
      if (mounted && _session.status == AnalysisStatus.analyzing) {
        setState(() => _subText = '생각보다 시간이 걸리고 있어요...');
      }
    });
    _timeoutTimer = Timer(const Duration(seconds: 25), () {
      if (mounted && _session.status == AnalysisStatus.analyzing) {
        _session.timeout();
      }
    });
  }

  void _onChanged() {
    if (!mounted) return;
    if (_session.replaying) {
      _slowTimer?.cancel();
      _timeoutTimer?.cancel();
    } else if (_session.waitPhase != _lastPhase) {
      _lastPhase = _session.waitPhase;
      _startTimers();
    }
    _lastStatus = _session.status;
    if (_session.status == AnalysisStatus.done && !_moved) {
      _moved = true;
      Nav.replace(context, AppRoutes.wellness);
      return;
    }
    setState(() {});
  }

  void _retry() {
    setState(_startTimers);
    _session.retry();
  }

  void _goHome() {
    _session.reset();
    Nav.resetTo(context, AppRoutes.home);
  }

  @override
  void dispose() {
    _session.removeListener(_onChanged);
    _session.screenWatching = false;
    _slowTimer?.cancel();
    _timeoutTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final status = _session.status;
    final failed = status == AnalysisStatus.failed ||
        status == AnalysisStatus.giveUp ||
        status == AnalysisStatus.savedOffline;

    final title = failed ? _session.message : '감정을 살펴보고 있어요';

    return Scaffold(
      body: Container(
        width: double.infinity,
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment(-0.6, -1),
            end: Alignment(0.6, 1),
            colors: [Color(0xFFE9F8F2), Color(0xFFCDEEE5)],
          ),
        ),
        child: Stack(
          children: [
            Padding(
              padding: EdgeInsets.only(top: topPad(context, 24), bottom: bottomPad(context, 64)),
              child: ShrinkToFit(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    SizedBox(
                      width: 260,
                      height: 260,
                      child: Stack(
                        alignment: Alignment.center,
                        clipBehavior: Clip.none,
                        children: [
                          if (!failed)
                            const RippleRings(
                              ringSize: 210,
                              color: AppColors.primary,
                              duration: Duration(seconds: 3),
                              scaleFrom: 0.7,
                              scaleTo: 2.1,
                              opacityFrom: 0.55,
                            ),
                          Container(
                            width: 140,
                            height: 140,
                            alignment: Alignment.center,
                            decoration: BoxDecoration(
                              color: AppColors.white,
                              shape: BoxShape.circle,
                              boxShadow: AppColors.cardShadow(0.18, 24, 8),
                            ),
                            child: failed
                                ? Svg(AppIcons.drop(AppColors.textMuted), size: 64)
                                : Bounce(child: Svg(AppIcons.drop(AppColors.primary), size: 64)),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 44),
                    if (!failed) ...[
                      Svg(AppIcons.pulseLine(), size: 180, height: 26),
                      const SizedBox(height: 44),
                    ],
                    Text(title, textAlign: TextAlign.center, style: ts(17, weight: bold, height: 1.5)),
                    if (!failed) ...[
                      const SizedBox(height: 10),
                      Text(
                        _subText,
                        textAlign: TextAlign.center,
                        style: ts(13, color: AppColors.textSub2, height: 1.5),
                      ),
                    ],
                  ],
                ),
              ),
            ),
            Positioned(
              left: 24,
              right: 24,
              bottom: bottomPad(context, 40),
              child: _bottom(status),
            ),
          ],
        ),
      ),
    );
  }

  Widget _bottom(AnalysisStatus status) {
    switch (status) {
      case AnalysisStatus.failed:
        return Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            PrimaryButton(label: '다시 시도', onTap: _session.hasRecording ? _retry : null),
            const SizedBox(height: 12),
            Tap(
              onTap: () => Nav.backTo(context, AppRoutes.recording),
              child: Text('다시 녹음하기', style: ts(13, color: AppColors.textSub2)),
            ),
          ],
        );
      case AnalysisStatus.giveUp:
      case AnalysisStatus.savedOffline:
        return PrimaryButton(label: '홈으로', onTap: _goHome);
      default:
        return Opacity(
          opacity: 0.7,
          child: Text(
            '분석이 끝나면 자동으로 다음 화면으로 이동해요',
            textAlign: TextAlign.center,
            style: ts(11, color: AppColors.textSub2),
          ),
        );
    }
  }
}