import 'dart:async';

import 'package:flutter/material.dart';

import '../navigation/app_routes.dart';
import '../navigation/nav.dart';
import '../services/growth_store.dart';
import '../services/sound_image_cache.dart';
import '../theme/app_colors.dart';
import '../theme/app_text.dart';
import '../widgets/app_icons.dart';
import '../widgets/bottom_nav.dart';
import '../widgets/common.dart';

/// 7. 사운드 추천
/// - 뒤로가기 → 6. 웰니스 스코어
/// - 추천 사운드 / 다른 사운드 카드 → 8. 사운드 재생
/// - 하단 탭: 홈 / 기록 / 어항
class SoundRecommendScreen extends StatefulWidget {
  const SoundRecommendScreen({super.key});

  @override
  State<SoundRecommendScreen> createState() =>
      _SoundRecommendScreenState();
}

class _SoundRecommendScreenState extends State<SoundRecommendScreen> {
  // [추가/11-06] 화면 진입 시 실제 Firebase 추천곡 불러오기
  @override
  void initState() {
    super.initState();

    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;

      unawaited(
        GrowthStore.instance.recommendSoundsForCurrentResult().catchError(
              (Object error) {
            debugPrint('사운드 추천 불러오기 실패: $error');
          },
        ),
      );
    });
  }

  @override
  Widget build(BuildContext context) {

    // [변경/11-01] 들은 음원은 '수집 음원'이 되어 어항 배경음으로 고를 수 있어요.
    void play(String id) {
      GrowthStore.instance.startSound(id);
      Nav.push(context, AppRoutes.soundPlay);
    }

    return Scaffold(
      body: Column(
        children: [
          Expanded(
            child: SingleChildScrollView(
              padding: EdgeInsets.fromLTRB(24, topPad(context, 56), 24, 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  BackArrow(onTap: () => Nav.backTo(context, AppRoutes.wellness)),
                  const SizedBox(height: 24),
                  Text('FOR YOUR MOOD',
                      style: ts(12, weight: bold, color: AppColors.primary, letterSpacing: 1)),
                  const SizedBox(height: 6),
                  Text('오늘의 감정에 맞는\n사운드예요', style: ts(19, weight: bold, height: 1.4)),
                  const SizedBox(height: 28),
                  AnimatedBuilder(
                    animation: GrowthStore.instance,
                    builder: (context, _) {
                      final store = GrowthStore.instance;
                      final sounds = store.recommendedSounds;

                      // 추천곡을 불러오는 중이거나 아직 없는 경우
                      if (sounds.isEmpty) {
                        return AppCard(
                          color: AppColors.primaryDark,
                          radius: 22,
                          padding: const EdgeInsets.all(20),
                          child: SizedBox(
                            height: 116,
                            child: Center(
                              child: Text(
                                store.soundRecommendationLoading
                                    ? '추천 사운드를 불러오는 중이에요.'
                                    : '추천 사운드가 아직 없어요.',
                                style: ts(13, color: AppColors.white),
                              ),
                            ),
                          ),
                        );
                      }

                      // Firebase에서 가져온 첫 번째 음원을 메인 추천곡으로 표시
                      final mainSound = sounds.first;

                      return _FeaturedSound(
                        sound: mainSound,
                        isPlaying: store.bgmPlaying && store.nowPlayingId == mainSound.id,
                        onTap: () => play(mainSound.id),
                      );
                    },
                  ),

                  // [변경/11-06] Firebase 서브 추천곡 2개 표시
                  AnimatedBuilder(
                    animation: GrowthStore.instance,
                    builder: (context, _) {
                      final store = GrowthStore.instance;
                      final sounds = store.recommendedSounds;

                      // 추천곡 3개가 준비되지 않았다면 표시하지 않음
                      if (sounds.length < 3) {
                        return const SizedBox.shrink();
                      }

                      final subSound1 = sounds[1];
                      final subSound2 = sounds[2];

                      return Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const SizedBox(height: 26),
                          Padding(
                            padding: const EdgeInsets.only(left: 2),
                            child: Text(
                              '이런 소리도 있어요',
                              style: ts(12, color: AppColors.textSub),
                            ),
                          ),
                          const SizedBox(height: 10),
                          _SoundTile(
                            title: subSound1.title,
                            desc: subSound1.desc,
                            isPlaying: store.bgmPlaying && store.nowPlayingId == subSound1.id,
                            iconBg: const Color(0xFFDFE8EE),
                            icon: _SoundArtwork(
                              sound: subSound1,
                              size: 48,
                              radius: 14,
                              fallback: Svg(AppIcons.music(AppColors.primaryDark), size: 24),
                            ),
                            onTap: () => play(subSound1.id),
                          ),
                          const SizedBox(height: 12),
                          _SoundTile(
                            title: subSound2.title,
                            desc: subSound2.desc,
                            isPlaying: store.bgmPlaying && store.nowPlayingId == subSound2.id,
                            iconBg: const Color(0xFFDCEBFB),
                            icon: _SoundArtwork(
                              sound: subSound2,
                              size: 48,
                              radius: 14,
                              fallback: Svg(AppIcons.music(AppColors.primaryDark), size: 24),
                            ),
                            onTap: () => play(subSound2.id),
                          ),
                        ],
                      );
                    },
                  ),
                ],
              ),
            ),
          ),
          const AppBottomNav(current: NavTab.none),
        ],
      ),
    );
  }
}

class _FeaturedSound extends StatelessWidget {
  const _FeaturedSound({
    required this.sound,
    required this.isPlaying,
    required this.onTap,
  });

  final SoundItem sound;
  final bool isPlaying;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Tap(
      onTap: onTap,
      child: AppCard(
        color: AppColors.primaryDark,
        radius: 22,
        padding: const EdgeInsets.all(20),
        shadow: [
          BoxShadow(color: AppColors.alpha(AppColors.primaryDark, 0.25), blurRadius: 20, offset: const Offset(0, 8)),
        ],
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 56,
                  height: 56,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: AppColors.alpha(AppColors.white, 0.16),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: _SoundArtwork(
                    sound: sound,
                    size: 56,
                    radius: 16,
                    fallback: Svg(AppIcons.music(AppColors.white), size: 26),
                  ),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                        decoration: BoxDecoration(
                          color: AppColors.alpha(AppColors.white, 0.22),
                          borderRadius: BorderRadius.circular(999),
                        ),
                        child: Text('추천 사운드', style: ts(10, color: AppColors.white)),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        sound.title,
                        style: ts(17, weight: bold, color: AppColors.white),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 14),
                Container(
                  width: 46,
                  height: 46,
                  alignment: Alignment.center,
                  decoration: const BoxDecoration(color: AppColors.white, shape: BoxShape.circle),
                  child: Svg(
                    isPlaying
                        ? AppIcons.pause(AppColors.primaryDark)
                        : AppIcons.play(AppColors.primaryDark),
                    size: 18,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            Text(sound.desc,
                style: ts(12, color: AppColors.alpha(AppColors.white, 0.9))),
          ],
        ),
      ),
    );
  }
}

class _SoundTile extends StatelessWidget {
  const _SoundTile({
    required this.title,
    required this.desc,
    required this.isPlaying,
    required this.iconBg,
    required this.icon,
    required this.onTap,
  });

  final String title;
  final String desc;
  final bool isPlaying;
  final Color iconBg;
  final Widget icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Tap(
      onTap: onTap,
      child: AppCard(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        child: Row(
          children: [
            Container(
              width: 48,
              height: 48,
              alignment: Alignment.center,
              decoration: BoxDecoration(color: iconBg, borderRadius: BorderRadius.circular(14)),
              child: icon,
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: ts(14, weight: bold)),
                  const SizedBox(height: 2),
                  Text(desc, style: ts(12, color: AppColors.textSub)),
                ],
              ),
            ),
            const SizedBox(width: 14),
            Container(
              width: 38,
              height: 38,
              alignment: Alignment.center,
              decoration: const BoxDecoration(color: AppColors.primary, shape: BoxShape.circle),
              child: Svg(
                isPlaying
                    ? AppIcons.pause(AppColors.white)
                    : AppIcons.play(AppColors.white),
                size: 15,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// [추가/11-06] Firebase Storage 음원 이미지 표시
class _SoundArtwork extends StatefulWidget {
  const _SoundArtwork({
    required this.sound,
    required this.size,
    required this.radius,
    required this.fallback,
  });

  final SoundItem sound;
  final double size;
  final double radius;
  final Widget fallback;

  @override
  State<_SoundArtwork> createState() => _SoundArtworkState();
}

class _SoundArtworkState extends State<_SoundArtwork> {
  Future<String>? _imageUrlFuture;

  @override
  void initState() {
    super.initState();
    _loadImage();
  }

  void _loadImage() {
    final path = widget.sound.imagePath;

    if (path == null || path.isEmpty) {
      _imageUrlFuture = null;
      return;
    }

    _imageUrlFuture = SoundImageCache.getUrl(path);
  }

  @override
  void didUpdateWidget(covariant _SoundArtwork oldWidget) {
    super.didUpdateWidget(oldWidget);

    if (oldWidget.sound.imagePath != widget.sound.imagePath) {
      _loadImage();
    }
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: widget.size,
      height: widget.size,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(widget.radius),
        child: FutureBuilder<String>(
          future: _imageUrlFuture,
          builder: (context, snapshot) {
            if (snapshot.hasData) {
              return Image.network(
                snapshot.data!,
                width: widget.size,
                height: widget.size,
                fit: BoxFit.cover,
                webHtmlElementStrategy: WebHtmlElementStrategy.fallback,
                frameBuilder: (context, child, frame, wasSynchronouslyLoaded) {
                  if (wasSynchronouslyLoaded || frame != null) {
                    return child;
                  }

                  return Stack(
                    alignment: Alignment.center,
                    children: [
                      widget.fallback,
                      const Positioned(
                        right: 4,
                        bottom: 4,
                        child: SizedBox(
                          width: 12,
                          height: 12,
                          child: CircularProgressIndicator(
                            strokeWidth: 1.5,
                          ),
                        ),
                      ),
                    ],
                  );
                },
                errorBuilder: (context, error, stackTrace) {
                  debugPrint('음원 이미지 표시 실패: $error');
                  return Center(child: widget.fallback);
                },
              );
            }

            if (snapshot.hasError) {
              debugPrint('음원 이미지 불러오기 실패: ${snapshot.error}');
              return Center(child: widget.fallback);
            }

            return Stack(
              alignment: Alignment.center,
              children: [
                widget.fallback,
                const Positioned(
                  right: 4,
                  bottom: 4,
                  child: SizedBox(
                    width: 12,
                    height: 12,
                    child: CircularProgressIndicator(
                      strokeWidth: 1.5,
                    ),
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}



