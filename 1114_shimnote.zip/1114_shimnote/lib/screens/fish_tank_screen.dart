// [변경/11-01] 1031 회의 반영
// - 처음부터 4마리(활력·안정·불안·피로) 모두 치어(Lv.1)로 시작, 잠긴 물고기 없음
// - ② 웰니스 스코어에서 가장 높은 유형 = 오늘의 물고기 → 어항에 표시하고 강조
// - 오늘의 물고기가 오늘의 필사 문구를 말풍선으로 보여 주고, 말풍선을 누르면 필사 탭으로 이동
// - 3) 어항 배경음: 그날의 음원을 어항에서 다시 듣기
// - [변경/11-01] 다른 물고기도 선명하게 두고, 오늘의 물고기만 빛·크기로 더 집중되게
//   재생 중에는 오늘의 물고기 주변에 물결 원이 퍼져요
// - 어항 꾸미기: 흔들리는 수초, 조약돌, 불가사리, 올라오는 거품 (TankDecor)
// - [추가/11-06] 수질 변화: 마지막 기록 후 5·10·20일이 지나면 물이 탁해지고 물고기가 느려져요.
//   레벨과 경험치는 줄지 않고, 다시 기록하면 바로 맑아지며 인사해요.
// - 레벨·경험치는 GrowthStore(필사 완료 시 증가)에서 가져와요
// - [변경/11-14] 교수님 피드백 반영
//   · 물고기가 정해진 칸이 아니라 어항을 가로지르며 위아래로도 자유롭게 헤엄쳐요
//   · 오늘의 물고기: 가운데 앞쪽에 가장 크고 선명하게 + '오늘' 표시 + 어항 위 '오늘의 마음' 한 줄
//   · 원근감 강화: 크기 0.6~1.15배, 투명도 0.35~1.0, 멀수록 위쪽 + 흐릿하게 (FishDepth)
//   · 감정별 표현: 불안 = 출렁이다 가끔 움찔 + 식은땀 / 피로 = 느리게 처져서 아래쪽, 색 바램
//   · Lv5 이후 빛 → 치어: 따라 쓰기 30 EXP마다 치어 1마리 (최대 3마리)

import 'dart:async';
import 'dart:math' as math;
import 'dart:ui' show ImageFilter;

import 'package:flutter/material.dart';

import '../navigation/app_routes.dart';
import '../navigation/nav.dart';
import '../services/growth_store.dart';
import '../theme/app_colors.dart';
import '../theme/app_text.dart';
import '../widgets/animations.dart';
import '../widgets/app_icons.dart';
import '../widgets/bgm_bar.dart';
import '../widgets/bottom_nav.dart';
import '../widgets/common.dart';
import '../widgets/fish_widgets.dart';

/// 10. 어항
/// - 물고기를 탭하면 커졌다 작아지고 하트가 떠오르며, 아래 레벨 카드가 그 물고기로 바뀌어요
/// - 설정 아이콘 → 11. 마이페이지
class FishTankScreen extends StatefulWidget {
  const FishTankScreen({super.key});

  @override
  State<FishTankScreen> createState() => _FishTankScreenState();
}

/// 어항 안 물고기 위치와 헤엄 모양
class _FishSpot {
  const _FishSpot(this.left, this.top, this.distance, this.startFlip, this.seconds,
      [this.wanderY = 0, this.wanderFreq = 1, this.phase = 0]);
  final double left; //      어항 너비 대비 위치
  final double top; //       어항 높이 대비 위치
  final double distance; //  좌우로 헤엄치는 거리 ([변경/11-14] 어항 너비 대비 비율)
  final double startFlip; // 처음 바라보는 방향
  final int seconds; //      한 번 왕복하는 시간
  final double wanderY; //   [추가/11-14] 위아래로 오르내리는 폭 (어항 높이 대비)
  final int wanderFreq; //   [추가/11-14] 한 번 왕복하는 동안 오르내리는 횟수 (정수여야 끊기지 않아요)
  final double phase; //     [추가/11-14] 물고기마다 오르내리는 타이밍을 다르게
}

class _FishTankScreenState extends State<FishTankScreen> with TickerProviderStateMixin {
  static const double _tankHeight = 300;
  static const double _fishSize = 100;

  static const Map<FishType, _FishSpot> _spots = {
    // [변경/11-14] 정해진 칸 안에서만 왔다 갔다 하던 것 → 어항 너비의 절반 넘게 가로지르며 위아래로도 오르내려요
    // 거리가 늘어난 만큼 한 번 왕복 시간도 약 2배로 (너무 빠르다는 피드백)
    FishType.vitality: _FishSpot(0.02, 0.14, 0.55, -1, 20, 0.10, 2, 0.0),
    FishType.calm: _FishSpot(0.56, 0.18, -0.50, 1, 22, 0.08, 2, 1.6),
    FishType.anxiety: _FishSpot(0.04, 0.46, 0.55, -1, 18, 0.10, 3, 3.1),
    FishType.fatigue: _FishSpot(0.56, 0.50, -0.50, 1, 24, 0.06, 2, 4.4),
  };

  /// [추가/11-14] 오늘의 물고기는 어항 가운데 앞쪽에서 헤엄쳐요
  static const _FishSpot _todaySpot = _FishSpot(0.20, 0.32, 0.35, -1, 20, 0.08, 2, 0.8);

  /// 물고기 위치: 오늘의 물고기면 가운데, 아니면 원래 자리
  _FishSpot _spotOf(FishType t) =>
      (t == _store.todayType && _visibleFish.length > 1) ? _todaySpot : _spots[t]!;

  late FishType _selected;
  FishType? _pulse;

  late final Map<FishType, AnimationController> _swim;
  late final Map<FishType, AnimationController> _heart;

  GrowthStore get _store => GrowthStore.instance;

  /// 이 화면을 연 순간의 수질 단계와 '다시 와 줘서 고마워요' 인사 여부
  /// [변경/11-12] 수질 단계를 매번 새로 읽어요 (테스트 메뉴로 바꿔도 바로 반영)
  int get _murk => _store.waterStage;
  late final bool _welcome;

  @override
  void initState() {
    super.initState();
    _welcome = _store.welcomeBack;
    _store.welcomeBack = false; // 인사는 한 번만
    _selected = _store.todayType ?? FishType.vitality;
    // [변경/11-12] 5일 이상 기록이 없으면 물고기가 잠들어 천천히 헤엄 (10일 이상이면 더 천천히)
    final slow = _murk >= 2 ? 2.2 : (_murk >= 1 ? 1.6 : 1.0);
    _swim = {
      for (final t in FishType.values)
        t: (AnimationController(
          vsync: this,
          // [변경/11-14] 감정별 속도: 불안은 빠르고 급하게, 피로는 느리게
          duration: Duration(milliseconds: (_spots[t]!.seconds * 1000 * slow * t.swimPace).round()),
        )..repeat()),
    };
    _heart = {
      for (final t in FishType.values)
        t: AnimationController(vsync: this, duration: const Duration(milliseconds: 900)),
    };
  }

  @override
  void dispose() {
    for (final c in _swim.values) {
      c.dispose();
    }
    for (final c in _heart.values) {
      c.dispose();
    }
    super.dispose();
  }

  void _pick(FishType type) {
    setState(() {
      _selected = type;
      _pulse = type;
    });
    _heart[type]!.forward(from: 0);
    Timer(const Duration(milliseconds: 220), () {
      if (mounted && _pulse == type) setState(() => _pulse = null);
    });
  }

  /// 어항에 보여 줄 물고기
  List<FishType> get _visibleFish {
    final today = _store.todayType;
    if (showOnlyTodayFish && today != null) return [today];
    return FishType.values;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Expanded(
            child: AnimatedBuilder(
              animation: _store,
              builder: (context, _) {
                final today = _store.todayType;
                final selected = _store.fish[_selected]!;
                return SingleChildScrollView(
                  padding: EdgeInsets.fromLTRB(24, topPad(context, 56), 24, 16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      const TankHeader(),
                      const SizedBox(height: 24),
                      if (_welcome) ...[
                        const InfoBanner(text: '다시 와 줘서 고마워요! 어항 물이 다시 맑아졌어요.'),
                        const SizedBox(height: 14),
                      ],
                      // [추가/11-14] 오늘의 물고기를 한눈에
                      if (today != null) ...[
                        _todayLine(today),
                        const SizedBox(height: 10),
                      ],
                      _tank(),
                      const SizedBox(height: 12),
                      Text(
                        _murk > 0
                            ? '마지막 기록 후 ${_store.daysSinceLastRecord}일이 지나 물이 탁해지고 물고기들이 잠들었어요. 오늘 마음을 기록하면 다시 깨어나요'
                            : today == null
                                ? '오늘 마음을 기록하면 오늘의 물고기가 정해져요'
                                : '말풍선을 누르면 문장 노트에서 오늘의 문장을 따라 쓸 수 있어요',
                        style: ts(11, color: AppColors.textSub, height: 1.5),
                      ),
                      const SizedBox(height: 14),
                      const BgmBar(),
                      const SizedBox(height: 22),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text('나의 물고기', style: ts(14, weight: bold)),
                          Text('물고기를 탭해보세요', style: ts(12, color: AppColors.textMuted)),
                        ],
                      ),
                      const SizedBox(height: 12),
                      _ownedFish(today),
                      const SizedBox(height: 22),
                      FishLevelCard(
                        type: _selected,
                        level: selected.level,
                        exp: selected.exp,
                        maxExp: selected.maxExp,
                        babies: selected.babies,
                        shine: selected.shine,
                        babyExpPerFish: babyExpPerFish,
                        maxBabies: maxBabies,
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
          const AppBottomNav(current: NavTab.fishTank),
        ],
      ),
    );
  }

  // ───────── 어항 ─────────

  Widget _tank() {
    final today = _store.todayType;
    final phrase = _store.todayPhrase;
    final spotlight = _store.bgmPlaying && today != null; // 그날의 음원 재생 중이면 오늘의 물고기를 강조
    final presence = _presence();

    return ClipRRect(
      borderRadius: BorderRadius.circular(24),
      child: SizedBox(
        height: _tankHeight,
        child: LayoutBuilder(builder: (context, c) {
          final w = c.maxWidth;
          final h = c.maxHeight;
          return Stack(
            children: [
              const Positioned.fill(child: TankBackground(sandRatio: 0.35, plants: [])),
              Positioned.fill(child: TankDecor(key: ValueKey(_murk), sandRatio: 0.35, murk: _murk)),
              // [추가/11-12] 원근감: 멀리 있는(존재감 낮은) 물고기부터 그려서 가까운 물고기가 앞에 오게
              // [변경/11-14] 원근감을 훨씬 크게: 크기 0.6~1.15배, 투명도 0.35~1.0, 먼 물고기는 흐릿하게
              for (final t in _depthOrder(presence))
                Positioned(
                  left: w * _spotOf(t).left,
                  top: h * _fishTop(t, presence[t]!),
                  child: AnimatedOpacity(
                    duration: const Duration(milliseconds: 400),
                    opacity: (spotlight && t != today ? 0.85 : 1) * FishDepth.opacity(presence[t]!),
                    child: _SwimmingFish(
                      type: t,
                      depthScale: FishDepth.scale(presence[t]!),
                      blur: FishDepth.blur(presence[t]!),
                      todayTag: t == today && _visibleFish.length > 1,
                      babies: _store.fish[t]!.babies,
                      sleeping: _store.fishSleeping,
                      resting: _murk >= 3,
                      swim: _swim[t]!,
                      heart: _heart[t]!,
                      distance: w * _spotOf(t).distance,
                      startFlip: _spotOf(t).startFlip,
                      wanderAmp: h * _spotOf(t).wanderY,
                      wanderFreq: _spotOf(t).wanderFreq,
                      wanderPhase: _spotOf(t).phase,
                      size: _fishSize,
                      pulsing: _pulse == t,
                      highlight: t == today ? t.dark : null,
                      spotlight: spotlight && t == today,
                      onTap: () => _pick(t),
                      child: FishSprite(type: t, level: _store.fish[t]!.level, size: _fishSize),
                    ),
                  ),
                ),
              // 오늘의 물고기 말풍선 (물고기를 따라다니지만 글자는 뒤집히지 않게 따로 그려요)
              if (today != null && phrase != null && _visibleFish.contains(today))
                _bubbleFor(today, phrase, w, h),
            ],
          );
        }),
      ),
    );
  }

  /// [추가/11-12] 물고기별 존재감 0~1 (망각 곡선 가중치)
  /// [변경/11-14] 오늘의 물고기는 항상 맨 앞(1.0), 나머지는 최대 0.8까지만 → 오늘의 물고기가 확실히 가장 크고 선명해요
  Map<FishType, double> _presence() {
    final p = Map<FishType, double>.from(_store.fishPresence);
    final today = _store.todayType;
    if (today != null) {
      for (final t in FishType.values) {
        p[t] = t == today ? 1.0 : math.min(p[t]!, 0.8);
      }
    }
    return p;
  }

  /// [추가/11-14] 어항 위 '오늘의 마음' 한 줄
  Widget _todayLine(FishType today) {
    return Row(
      children: [
        Text('오늘의 마음', style: ts(13, weight: bold)),
        const SizedBox(width: 8),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
          decoration: BoxDecoration(
            color: today.light,
            borderRadius: BorderRadius.circular(999),
            border: Border.all(color: today.dark),
          ),
          child: Text('${today.label} 물고기', style: ts(12, weight: bold, color: AppColors.textDark)),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: Text('가장 크고 선명하게 보여요',
              maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(11, color: AppColors.textSub)),
        ),
      ],
    );
  }

  /// 멀리 있는 물고기 → 가까운 물고기 순서 (나중에 그린 물고기가 앞에 보여요)
  List<FishType> _depthOrder(Map<FishType, double> presence) {
    final list = [..._visibleFish];
    list.sort((a, b) => presence[a]!.compareTo(presence[b]!));
    return list;
  }

  /// 물고기 세로 위치
  /// - [추가/11-12] 멀리 있는 물고기는 조금 위쪽(수평선 쪽)으로
  /// - 20일 이상 기록이 없으면 바닥 근처에서 쉬어요
  /// - [추가/11-14] 피로 물고기는 조금 아래쪽에서 힘없이 헤엄쳐요
  double _fishTop(FishType t, [double presence = 1]) {
    var top = _spotOf(t).top - FishDepth.lift(presence);
    if (t == FishType.fatigue) top += 0.06;
    if (_murk >= 3) top += 0.2;
    return top.clamp(0.02, 0.62);
  }

  Widget _bubbleFor(FishType type, String phrase, double w, double h) {
    const bubbleWidth = 168.0;
    final spot = _spotOf(type);
    return AnimatedBuilder(
      animation: _swim[type]!,
      builder: (context, _) {
        final (x, _) = _SwimmingFish.swimAt(_swim[type]!.value, w * spot.distance, spot.startFlip);
        final wy = _murk >= 3
            ? 0.0
            : _SwimmingFish.wanderAt(_swim[type]!.value, h * spot.wanderY, spot.wanderFreq, spot.phase);
        final fishCenter = w * spot.left + x + _fishSize / 2;
        final maxLeft = w - bubbleWidth - 8 < 8 ? 8.0 : w - bubbleWidth - 8;
        final left = (fishCenter - bubbleWidth / 2).clamp(8.0, maxLeft);
        final tailX = (fishCenter - left).clamp(18.0, bubbleWidth - 18);
        final fishTop = h * _fishTop(type, _presence()[type]!) + _fishSize * 0.32; // 그림 캔버스 안에서 물고기 몸통 위쪽
        return Positioned(
          left: left,
          bottom: h - fishTop - wy,
          child: Tap(
            onTap: () => Nav.resetTo(context, AppRoutes.transcripts),
            child: _SpeechBubble(width: bubbleWidth, tailX: tailX, color: type.light, border: type.dark, text: phrase),
          ),
        );
      },
    );
  }

  // ───────── 나의 물고기 (4마리) ─────────

  Widget _ownedFish(FishType? today) {
    Widget slot(FishType t) {
      final f = _store.fish[t]!;
      final selected = t == _selected;
      return Tap(
        onTap: () => _pick(t),
        child: Column(
          children: [
            Stack(
              clipBehavior: Clip.none,
              children: [
                AnimatedContainer(
                  duration: const Duration(milliseconds: 180),
                  width: 60,
                  height: 60,
                  decoration: BoxDecoration(
                    color: t.light,
                    shape: BoxShape.circle,
                    border: Border.all(color: selected ? t.dark : t.color, width: selected ? 2.5 : 2),
                  ),
                  child: ClipOval(child: FishSprite(type: t, level: f.level, size: 56, zoom: true)),
                ),
                if (t == today)
                  Positioned(
                    top: -6,
                    right: -8,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(color: AppColors.primary, borderRadius: BorderRadius.circular(999)),
                      child: Text('오늘', style: ts(9, weight: bold, color: AppColors.white)),
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 6),
            Text(t.label, style: ts(11, weight: bold)),
            const SizedBox(height: 4),
            Text(f.isMax ? 'Lv.${f.level} 완성' : 'Lv.${f.level}', style: ts(10, color: AppColors.textMuted)),
          ],
        ),
      );
    }

    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [for (final t in FishType.values) slot(t)],
    );
  }
}

/// 말풍선 (아래쪽 꼬리가 물고기를 가리켜요)
class _SpeechBubble extends StatelessWidget {
  const _SpeechBubble({
    required this.width,
    required this.tailX,
    required this.color,
    required this.border,
    required this.text,
  });

  final double width;
  final double tailX;
  final Color color;
  final Color border;
  final String text;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: width,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: width,
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              color: color,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: border, width: 1.5),
              boxShadow: [
                BoxShadow(color: AppColors.alpha(Colors.black, 0.08), blurRadius: 8, offset: const Offset(0, 3)),
              ],
            ),
            child: Text(text, maxLines: 2, overflow: TextOverflow.ellipsis, style: ts(11, weight: bold, height: 1.4)),
          ),
          Padding(
            padding: EdgeInsets.only(left: tailX - 7),
            child: CustomPaint(size: const Size(14, 8), painter: _TailPainter(color: color, border: border)),
          ),
        ],
      ),
    );
  }
}

class _TailPainter extends CustomPainter {
  _TailPainter({required this.color, required this.border});

  final Color color;
  final Color border;

  @override
  void paint(Canvas canvas, Size size) {
    final path = Path()
      ..moveTo(0, -1)
      ..lineTo(size.width / 2, size.height)
      ..lineTo(size.width, -1);
    canvas.drawPath(path, Paint()..color = color);
    canvas.drawPath(
      path,
      Paint()
        ..color = border
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.5,
    );
  }

  @override
  bool shouldRepaint(covariant _TailPainter old) => old.color != color || old.border != border;
}

/// [추가/11-14] 식은땀 방울 (위가 뾰족한 물방울)
class _SweatPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size s) {
    final path = Path()
      ..moveTo(s.width / 2, 0)
      ..quadraticBezierTo(s.width, s.height * 0.6, s.width / 2, s.height)
      ..quadraticBezierTo(0, s.height * 0.6, s.width / 2, 0)
      ..close();
    canvas.drawPath(path, Paint()..color = const Color(0xFF9FD3FF));
    canvas.drawPath(
      path,
      Paint()
        ..color = const Color(0xFF5FA8E0)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1,
    );
  }

  @override
  bool shouldRepaint(covariant _SweatPainter old) => false;
}

/// 좌우로 헤엄치는 물고기 (목업 keyframes swimJoy / swimCalm 재현)
class _SwimmingFish extends StatelessWidget {
  const _SwimmingFish({
    required this.swim,
    required this.heart,
    required this.distance,
    required this.startFlip,
    required this.size,
    required this.pulsing,
    required this.child,
    required this.onTap,
    this.highlight,
    this.spotlight = false,
    this.depthScale = 1,
    this.babies = 0,
    this.sleeping = false,
    this.resting = false,
    this.wanderAmp = 0,
    this.wanderFreq = 1,
    this.wanderPhase = 0,
    this.type,
    this.blur = 0,
    this.todayTag = false,
  });

  /// [추가/11-14] 감정 유형 → 감정별 움직임 · 효과
  /// - 활력: 통통 튀듯 위아래로 / 안정: 부드럽게 둥실
  /// - 불안: 빠르고 자잘하게 떨림 + 식은땀 방울 / 피로: 느리게, 고개를 떨군 채 아래쪽에서, 색이 바램
  final FishType? type;

  /// [추가/11-14] 멀리 있는 물고기 흐림 정도 (0이면 선명)
  final double blur;

  /// [추가/11-14] 물고기 아래 '오늘의 물고기' 표시
  final bool todayTag;

  /// [추가/11-12] 원근감 크기 (멀수록 작게)
  final double depthScale;

  /// [변경/11-14] Lv5 이후 치어 수 0~3 (빛 → 치어)
  final int babies;

  /// [추가/11-12] 오래 기록하지 않아 잠든 상태 (Zz 표시)
  final bool sleeping;

  /// [추가/11-14] 수질이 가장 나쁠 때(20일 이상 미기록): 헤엄을 멈추고 바닥 근처에서 숨만 쉬어요
  final bool resting;

  /// [추가/11-14] 위아래로 오르내리는 폭(px) · 횟수 · 시작 타이밍
  final double wanderAmp;
  final int wanderFreq;
  final double wanderPhase;

  /// t(0~1) 시점의 위아래 이동량. 말풍선 위치 계산에도 써요.
  static double wanderAt(double t, double amp, int freq, double phase) =>
      math.sin(t * 2 * math.pi * freq + phase) * amp;

  final Animation<double> swim;
  final AnimationController heart;
  final double distance;
  final double startFlip;
  final double size; // 물고기 그림(정사각형) 크기
  final bool pulsing;
  final Widget child;
  final VoidCallback onTap;

  /// 오늘의 물고기 표시용 색 ([변경/11-14] 빛 원은 없애고 살짝 크게만 보여 줘요)
  final Color? highlight;

  /// 그날의 음원 재생 중이면 빛을 더 강하게 + 조금 더 크게 + 물결 원
  final bool spotlight;

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: Listenable.merge([swim, heart]),
      builder: (context, _) {
        final (x, flip) = resting ? (0.0, startFlip) : swimAt(swim.value, distance, startFlip);
        // [추가/11-14] 숨 쉬듯 아주 천천히 살짝 커졌다 작아져요 (한 바퀴 동안 10번)
        final breath = resting ? 1 + 0.03 * math.sin(swim.value * 2 * math.pi * 10) : 1.0;
        final (dx, dy0, tilt) = _moodMotion(swim.value);
        final dy = dy0 + (resting ? 0 : wanderAt(swim.value, wanderAmp, wanderFreq, wanderPhase));
        return Transform(
          alignment: Alignment.center,
          transform: Matrix4.translationValues(x + dx, dy, 0)..multiply(Matrix4.diagonal3Values(flip, 1, 1)),
          child: Tap(
            onTap: onTap,
            child: SizedBox(
              width: size,
              height: size,
              child: Transform.scale(
                scale: depthScale * breath,
                child: Stack(
                clipBehavior: Clip.none,
                children: [
                  // [변경/11-14] Lv5 이후 빛 대신 치어(아기 물고기)가 엄마 물고기 뒤를 따라다녀요
                  if (type != null)
                    for (var i = 0; i < babies.clamp(0, 3); i++) _baby(i, resting ? 0 : swim.value), // 수질 최악이면 치어도 멈춰요
                  // [변경/11-14] 오늘의 물고기 주변 반투명 빛 원 삭제 (어색해 보여서). 가운데 · 크기 · '오늘' 표시로 충분히 구분돼요
                  // 재생 중: 물고기 주변으로 물결 원이 퍼져요
                  if (spotlight)
                    Positioned.fill(
                      child: IgnorePointer(
                        child: Center(
                          child: RippleRings(
                            ringSize: size * 0.5,
                            color: AppColors.white,
                            duration: const Duration(milliseconds: 2800),
                            scaleFrom: 0.8,
                            scaleTo: 2.0,
                            opacityFrom: 0.7,
                          ),
                        ),
                      ),
                    ),
                  AnimatedScale(
                    scale: pulsing ? 1.35 : (spotlight ? 1.18 : (highlight != null ? 1.08 : 1)),
                    duration: const Duration(milliseconds: 200),
                    curve: Curves.ease,
                    child: _moodSprite(tilt),
                  ),
                  // [추가/11-14] 불안: 식은땀 방울
                  if (type == FishType.anxiety && !resting) _sweat(swim.value),
                  // [추가/11-14] 오늘의 물고기 표시
                  if (todayTag)
                    Positioned(
                      left: 0,
                      right: 0,
                      top: size * 0.72,
                      child: IgnorePointer(
                        child: Center(
                          child: Transform(
                            alignment: Alignment.center,
                            transform: Matrix4.diagonal3Values(flip, 1, 1),
                            child: Container(
                              padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                              decoration: BoxDecoration(
                                color: AppColors.alpha(AppColors.white, 0.9),
                                borderRadius: BorderRadius.circular(999),
                                border: Border.all(color: type?.dark ?? AppColors.textSub),
                              ),
                              child: Text('오늘', style: ts(10, weight: bold, color: AppColors.textDark)),
                            ),
                          ),
                        ),
                      ),
                    ),
                  if (heart.isAnimating) _heart(heart.value),
                  // [추가/11-12] 잠든 물고기
                  if (sleeping)
                    Positioned(
                      top: size * 0.12,
                      right: size * 0.08,
                      child: IgnorePointer(
                        child: Transform(
                          alignment: Alignment.center,
                          // 물고기가 뒤집혀도 글자는 바로 보이게
                          transform: Matrix4.diagonal3Values(flip, 1, 1),
                          child: Text('z z', style: ts(13, weight: bold, color: AppColors.alpha(AppColors.textSub, 0.8))),
                        ),
                      ),
                    ),
                ],
              ),
              ),
            ),
          ),
        );
      },
    );
  }

  /// [추가/11-14] 치어: 엄마 물고기 꼬리 쪽에서 작게 따라 헤엄쳐요 (그림은 임시로 Lv1 사용)
  /// 불안 · 피로 치어는 엄마처럼 떨거나 색이 바래지 않아요 → '돌본 마음에서 편안함이 자란다'
  /// [변경/11-14] 몰려다니지 않게 치어마다 다른 자리 · 다른 속도로 넓게 맴돌아요
  Widget _baby(int i, double t) {
    // (중심 x, 중심 y, 가로 반경, 세로 반경, 속도) — 물고기 그림 크기 대비 (머리는 왼쪽)
    const paths = [
      (1.20, 0.55, 0.30, 0.18, 3),
      (0.55, 0.05, 0.45, 0.12, 2),
      (0.70, 1.05, 0.40, 0.15, 4), // 속도는 정수여야 한 바퀴 끝날 때 끊기지 않아요
    ];
    final box = size * 0.6;
    final (cx, cy, rx, ry, speed) = paths[i];
    final a = t * 2 * math.pi * speed + i * 2.1;
    final x = cx + math.sin(a) * rx;
    final y = cy + math.sin(a * 2) * ry; // 8자 모양으로 맴돌기
    return Positioned(
      left: size * x - box / 2,
      top: size * y - box / 2,
      child: IgnorePointer(child: FishSprite(type: type!, level: 1, size: box)),
    );
  }

  /// [추가/11-14] 감정별 움직임 (x 흔들림, y 흔들림, 기울기). t = 헤엄 진행도 0~1
  (double, double, double) _moodMotion(double t) {
    final a = t * 2 * math.pi;
    if (resting) return (0, 0, type == FishType.fatigue ? -0.16 : 0); // 멈춰서 숨만 쉬어요
    if (sleeping) return (0, math.sin(a * 3) * 2, 0); // 잠든 물고기는 거의 움직이지 않아요
    switch (type) {
      case FishType.vitality: // 통통 튀듯
        return (0, -(math.sin(a * 8)).abs() * 7, math.sin(a * 8) * 0.05);
      case FishType.calm: // 부드럽게 둥실
        return (0, math.sin(a * 4) * 4, 0);
      case FishType.anxiety: // [변경/11-14] 평소엔 조금 불안정하게 출렁이다가, 가끔 짧게 움찔 떨어요 (계속 떨면 너무 정신없어서)
      {
        final k = (t * 3) % 1.0; //               한 번 헤엄치는 동안 3번
        final shake = k < 0.1 ? math.sin(k / 0.1 * math.pi) : 0.0; // 움찔하는 짧은 순간만 0 → 1 → 0
        return (
          math.sin(a * 30) * 2.0 * shake,
          math.sin(a * 4) * 3 + math.sin(a * 9) * 1.5,
          math.sin(a * 30) * 0.05 * shake,
        );
      }
      case FishType.fatigue: // 느리게 축 처져서 (머리가 아래로)
        return (0, math.sin(a * 3) * 5, -0.16 + math.sin(a * 3) * 0.04);
      case null:
        return (0, 0, 0);
    }
  }

  /// [추가/11-14] 피로 물고기는 색을 조금 바래게, 먼 물고기는 흐리게, 기울기 반영
  Widget _moodSprite(double tilt) {
    Widget w = child;
    if (type == FishType.fatigue) {
      w = ColorFiltered(colorFilter: const ColorFilter.matrix(_fadeMatrix), child: w);
    }
    if (blur > 0.05) {
      w = ImageFiltered(imageFilter: ImageFilter.blur(sigmaX: blur, sigmaY: blur), child: w);
    }
    if (tilt != 0) w = Transform.rotate(angle: tilt, child: w);
    return w;
  }

  /// 채도 55% + 살짝 어둡게 (피로)
  static const List<double> _fadeMatrix = [
    0.62, 0.30, 0.04, 0, 0, //
    0.14, 0.79, 0.04, 0, 0, //
    0.14, 0.30, 0.52, 0, 0, //
    0, 0, 0, 1, 0,
  ];

  /// [추가/11-14] 불안 물고기 머리 위로 식은땀 방울이 맺혔다 흘러내려요
  Widget _sweat(double t) {
    final k = (t * 3) % 1.0; // 한 번 헤엄치는 동안 3번 (움찔할 때 맺혀서 흘러내려요)
    final dy = k * size * 0.08;
    final opacity = k < 0.7 ? 1.0 : (1 - (k - 0.7) / 0.3);
    return Positioned(
      left: size * 0.30,
      top: size * 0.30 + dy,
      child: IgnorePointer(
        child: Opacity(
          opacity: opacity.clamp(0.0, 1.0),
          child: CustomPaint(size: Size(size * 0.07, size * 0.1), painter: _SweatPainter()),
        ),
      ),
    );
  }

  Widget _heart(double t) {
    // keyframes heartFloat: 0% / 50% / 80% / 100%
    double lerp3(double a, double b, double c, double d) {
      if (t < 0.5) return a + (b - a) * (t / 0.5);
      if (t < 0.8) return b + (c - b) * ((t - 0.5) / 0.3);
      return c + (d - c) * ((t - 0.8) / 0.2);
    }

    final opacity = lerp3(0.9, 1, 0.9, 0);
    final dy = lerp3(0, -16, -24, -28);
    final scale = lerp3(0.4, 1, 1.05, 1.6);
    return Positioned(
      top: size * 0.3 - 18,
      left: size * 0.45 - 9,
      child: Opacity(
        opacity: opacity.clamp(0.0, 1.0),
        child: Transform.translate(
          offset: Offset(0, dy),
          child: Transform.scale(scale: scale, child: Svg(AppIcons.heart(), size: 18)),
        ),
      ),
    );
  }

  /// t(0~1) 시점의 x 이동량과 좌우 방향(scaleX). 말풍선 위치 계산에도 써요.
  static (double, double) swimAt(double t, double distance, double startFlip) {
    final ease = Curves.easeInOut;
    if (t < 0.45) return (distance * ease.transform(t / 0.45), startFlip);
    if (t < 0.50) {
      final k = ease.transform((t - 0.45) / 0.05);
      return (distance, startFlip + (-2 * startFlip) * k);
    }
    if (t < 0.95) return (distance * (1 - ease.transform((t - 0.5) / 0.45)), -startFlip);
    final k = ease.transform((t - 0.95) / 0.05);
    return (0, -startFlip + (2 * startFlip) * k);
  }
}
