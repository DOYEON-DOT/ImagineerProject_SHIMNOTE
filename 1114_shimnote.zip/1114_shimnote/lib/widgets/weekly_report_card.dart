// [추가/11-06] 기록 탭 > 이번 주 영역별 리포트 카드
// - 이번 주(월~일) 기록이 weeklyReportMinDays(3일) 이상이면 열려요.
// - 요약 3칸(기록한 날 / 평균 점수 / 지난주보다) + 영역별 막대 + 한 줄 코멘트

import 'package:flutter/material.dart';

import '../services/growth_store.dart';
import '../theme/app_colors.dart';
import '../theme/app_text.dart';
import 'common.dart';

class WeeklyReportCard extends StatelessWidget {
  const WeeklyReportCard({super.key});

  static const List<Color> _barColors = [AppColors.primary, Color(0xFF5DCAA5), AppColors.mint200];

  @override
  Widget build(BuildContext context) {
    final r = GrowthStore.instance.weeklyReport();
    return AppCard(
      radius: 16,
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('이번 주 영역별 리포트', style: ts(14, weight: bold)),
              Text(
                r.unlocked ? '${_md(r.weekStart)} – ${_md(r.weekEnd)}' : '잠김',
                style: ts(11, color: AppColors.textSub),
              ),
            ],
          ),
          if (r.unlocked) ..._open(r) else ..._locked(r),
        ],
      ),
    );
  }

  // ── 잠긴 상태: 진행 바 ──
  List<Widget> _locked(WeeklyReport r) {
    final done = r.days.clamp(0, weeklyReportMinDays);
    return [
      const SizedBox(height: 10),
      Text('이번 주 $weeklyReportMinDays일 기록하면 리포트가 열려요', style: ts(12, color: AppColors.textSub)),
      const SizedBox(height: 10),
      Row(
        children: [
          for (var i = 0; i < weeklyReportMinDays; i++) ...[
            if (i > 0) const SizedBox(width: 6),
            Expanded(
              child: Container(
                height: 8,
                decoration: BoxDecoration(
                  color: i < done ? AppColors.primary : AppColors.track,
                  borderRadius: BorderRadius.circular(99),
                ),
              ),
            ),
          ],
        ],
      ),
      const SizedBox(height: 8),
      Text('$done / $weeklyReportMinDays일', style: ts(11, color: AppColors.textSub)),
    ];
  }

  // ── 열린 상태 ──
  List<Widget> _open(WeeklyReport r) {
    final diff = r.diffFromLastWeek;
    final diffText = diff == null ? '–' : '${diff >= 0 ? '+' : ''}${diff.round()}';
    final maxCount = r.areas.isEmpty ? 1 : r.areas.first.count;

    return [
      const SizedBox(height: 14),
      Row(
        children: [
          _stat('기록한 날', '${r.days}일'),
          const SizedBox(width: 8),
          _stat('평균 점수', r.avgScore == null ? '–' : '${r.avgScore!.round()}'),
          const SizedBox(width: 8),
          _stat('지난주보다', diffText, color: diff != null && diff > 0 ? AppColors.primary : null),
        ],
      ),
      const SizedBox(height: 16),
      Text('많이 이야기한 영역', style: ts(12, color: AppColors.textSub)),
      const SizedBox(height: 8),
      for (var i = 0; i < r.areas.length; i++)
        Padding(
          padding: const EdgeInsets.only(bottom: 8),
          child: Row(
            children: [
              SizedBox(width: 64, child: Text(r.areas[i].area, style: ts(12))),
              const SizedBox(width: 8),
              Expanded(
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(99),
                  child: LinearProgressIndicator(
                    value: r.areas[i].count / maxCount,
                    minHeight: 10,
                    backgroundColor: AppColors.track,
                    valueColor: AlwaysStoppedAnimation(_barColors[i < _barColors.length ? i : _barColors.length - 1]),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              SizedBox(
                width: 52,
                child: Text(
                  '${r.areas[i].count}회 · ${r.areas[i].avgScore.round()}',
                  textAlign: TextAlign.right,
                  style: ts(11, color: AppColors.textSub),
                ),
              ),
            ],
          ),
        ),
      if (r.comment.isNotEmpty) ...[
        const SizedBox(height: 6),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          decoration: BoxDecoration(color: const Color(0xFFFFF2D6), borderRadius: BorderRadius.circular(10)),
          child: Text(r.comment, style: ts(12, color: const Color(0xFF8A5B0F), height: 1.5)),
        ),
      ],
    ];
  }

  Widget _stat(String label, String value, {Color? color}) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 8),
        decoration: BoxDecoration(color: AppColors.background, borderRadius: BorderRadius.circular(10)),
        child: Column(
          children: [
            Text(label, style: ts(11, color: AppColors.textSub)),
            const SizedBox(height: 2),
            Text(value, style: ts(18, weight: bold, color: color ?? AppColors.textDark)),
          ],
        ),
      ),
    );
  }

  String _md(DateTime d) => '${d.month}/${d.day}';
}
