// [추가/11-06] 비동기 추천곡 복원
import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';

// [추가/10-25] 파이어베이스 연결
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'firebase_options.dart';

import 'navigation/app_routes.dart';
import 'services/analysis_service.dart';

// [추가/11-06] 추천곡 복원
import 'services/growth_store.dart';
import 'navigation/nav.dart';
import 'theme/app_colors.dart';
import 'theme/app_text.dart';

// [변경/10-25] 파이어베이스 시작을 기다리기 위해 async로 변경
Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // [추가/10-25] 파이어베이스 시작 (flutterfire configure로 만든 firebase_options.dart 사용)
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  // [추가/10-25] 익명 로그인 (회원가입 없이 사용자 구분용 uid 발급)
  // 이미 로그인되어 있으면 다시 하지 않음. 실패해도 앱 화면은 그대로 실행됨.
  try {
    if (FirebaseAuth.instance.currentUser == null) {
      await FirebaseAuth.instance.signInAnonymously();
    }
    debugPrint('익명 로그인 uid: ${FirebaseAuth.instance.currentUser?.uid}');
  } catch (e) {
    debugPrint('익명 로그인 실패: $e');
  }

  // [추가/11-06] 앱 재실행 시 마지막 추천곡 3개 복원
  if (FirebaseAuth.instance.currentUser != null) {
    unawaited(
      GrowthStore.instance.restoreLastRecommendedSounds().catchError(
            (Object error) {
          debugPrint('최근 추천곡 복원 실패: $error');
        },
      ),
    );
  }

  // [추가/10-26] 오프라인 때 저장한 녹음이 있으면 앱 시작 시 자동 분석
  AnalysisSession.instance.onQueuedResult = _showQueuedResult;
  AnalysisSession.instance.init();

  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.dark,
    ),
  );
  runApp(const MyApp());
}

// [추가/10-26] 저장된 녹음 분석이 끝나면 어느 화면에서든 위쪽 알림 + 결과 보기
final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();
OverlayEntry? _topNotice;

void _showQueuedResult() {
  final overlay = navigatorKey.currentState?.overlay;
  if (overlay == null) return;
  _topNotice?.remove();
  late final OverlayEntry entry;
  entry = OverlayEntry(
    builder: (_) => _TopNotice(
      message: '저장된 녹음 분석이 끝났어요',
      actionLabel: '결과 보기',
      onAction: () => navigatorKey.currentState?.pushNamed(AppRoutes.wellness),
      onClosed: () {
        if (_topNotice == entry) _topNotice = null;
        entry.remove();
      },
    ),
  );
  _topNotice = entry;
  overlay.insert(entry);
}

class _TopNotice extends StatefulWidget {
  const _TopNotice({
    required this.message,
    required this.actionLabel,
    required this.onAction,
    required this.onClosed,
  });

  final String message;
  final String actionLabel;
  final VoidCallback onAction;
  final VoidCallback onClosed;

  @override
  State<_TopNotice> createState() => _TopNoticeState();
}

class _TopNoticeState extends State<_TopNotice> with SingleTickerProviderStateMixin {
  late final AnimationController _c =
  AnimationController(vsync: this, duration: const Duration(milliseconds: 250))..forward();
  bool _closing = false;

  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(seconds: 6), _close);
  }

  Future<void> _close() async {
    if (_closing || !mounted) return;
    _closing = true;
    await _c.reverse();
    widget.onClosed();
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Positioned(
      top: MediaQuery.paddingOf(context).top + 12,
      left: 16,
      right: 16,
      child: SlideTransition(
        position: Tween(begin: const Offset(0, -1.5), end: Offset.zero)
            .animate(CurvedAnimation(parent: _c, curve: Curves.easeOut)),
        child: Material(
          color: AppColors.textDark,
          borderRadius: BorderRadius.circular(14),
          elevation: 6,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 6, 6, 6),
            child: Row(
              children: [
                Expanded(child: Text(widget.message, style: ts(14, color: AppColors.white))),
                TextButton(
                  onPressed: () {
                    widget.onAction();
                    _close();
                  },
                  child: Text(widget.actionLabel, style: ts(14, weight: bold, color: AppColors.white)),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    final base = ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(
        seedColor: AppColors.primary,
        primary: AppColors.primary,
        surface: AppColors.background,
      ),
      scaffoldBackgroundColor: AppColors.background,
      splashFactory: NoSplash.splashFactory,
      highlightColor: Colors.transparent,
    );

    return MaterialApp(
      title: '쉼노트',
      navigatorKey: navigatorKey,
      debugShowCheckedModeBanner: false,
      theme: base.copyWith(
        textTheme: GoogleFonts.notoSansKrTextTheme(base.textTheme).apply(
          bodyColor: AppColors.textDark,
          displayColor: AppColors.textDark,
        ),
      ),
      initialRoute: AppRoutes.splash,
      onGenerateRoute: AppRoutes.onGenerateRoute,
      navigatorObservers: [routeObserver],
    );
  }
}