import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import 'app_colors.dart';

/// [추가/11-14] 글씨 · 아이콘 크기 배율 (폰에서 작아 보인다는 피드백 → 전체 15% 키움)
/// 더 키우거나 줄이고 싶으면 이 숫자만 바꾸면 돼요. (1.0 = 11-12 버전 크기)
const double uiScale = 1.15;

/// [추가/11-14] 가장 작은 글씨 크기 (이보다 작게 쓰인 글씨도 이 크기로)
const double minFontSize = 12;

/// 목업 텍스트 스타일 헬퍼
/// 기본 폰트는 Noto Sans KR (앱 테마에서 지정), 로고 글씨만 Gowun Dodum 입니다.
TextStyle ts(
  double size, {
  FontWeight weight = FontWeight.w400,
  Color color = AppColors.textDark,
  double? height,
  double? letterSpacing,
  TextDecoration? decoration,
}) {
  return TextStyle(
    fontSize: math.max(size * uiScale, minFontSize), // [변경/11-14] 전체 글씨 키움
    fontWeight: weight,
    color: color,
    height: height,
    letterSpacing: letterSpacing,
    decoration: decoration,
    decorationColor: color,
  );
}

const FontWeight bold = FontWeight.w700;

/// 로고 글씨 스타일 (Gowun Dodum)
/// Gowun Dodum에 없는 글자(예: '쉼')가 깨지지 않도록 Noto Sans KR로 대신 그립니다.
TextStyle logoStyle(double size, Color color) {
  final fallback = GoogleFonts.notoSansKr().fontFamily;
  return GoogleFonts.gowunDodum(fontSize: size, color: color).copyWith(
    fontFamilyFallback: [if (fallback != null) fallback],
  );
}
