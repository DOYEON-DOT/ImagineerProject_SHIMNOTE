// [변경/11-01] 1031 회의 반영
// - 처음부터 4마리(활력·안정·불안·피로) 모두 치어(Lv.1)로 시작, 잠긴 물고기 없음
// - ② 웰니스 스코어에서 가장 높은 유형 = 오늘의 물고기 → 어항에 표시하고 강조
// - 오늘의 물고기가 오늘의 필사 문구를 말풍선으로 보여 주고, 말풍선을 누르면 필사 탭으로 이동
// - 3) 어항 배경음: 그날의 음원을 어항에서 다시 듣기
// - [변경/11-01] 다른 물고기도 선명하게 두고, 오늘의 물고기만 빛·크기로 더 집중되게
//   재생 중에는 오늘의 물고기 주변에 물결 원이 퍼져요
// - 어항 꾸미기: 흔들리는 수초, 조약돌, 불가사리, 올라오는 거품 (TankDecor)
// - [추가/11-06] 수질 변화: 마지막 기록 후 5·10·20일이 지나면 물이 탁해지고 물고기가 느려져요.
//   레벨과 경험치는 줄지 않고, 다시 기록하면 바로 맑아지며 인사해요.
// - 레벨·경험치는 GrowthStore(필사 완료 시 증가)에서 가져와요

import 'dart:async';

import 'package:flutter/material.dart';

import '../navigation/app_routes.dart';
import '../navigation/nav.dart';
import '../services/growth_store.dart';
import '../theme/app_colors.dart';
import '../theme/app_text.dart';
import '../widgets/animations.dart';
import '../widgets/app_icons.dart';
import '../widgets/bgm_bar.dart';
import '../widgets/bottom_nav.dart';
import '../widgets/common.dart';
import '../widgets/fish_widgets.dart';

/// 10. 어항
/// - 물고기를 탭하면 커졌다 작아지고 하트가 떠오르며, 아래 레벨 카드가 그 물고기로 바뀌어요
/// - 설정 아이콘 → 11. 마이페이지
class FishTankScreen extends StatefulWidget {
  const FishTankScreen({super.key});

  @override
  State<FishTankScreen> createState() => _FishTankScreenState();
}

/// 어항 안 물고기 위치와 헤엄 모양
class _FishSpot {
  const _FishSpot(this.left, this.top, this.distance, this.startFlip, this.seconds);
  final double left; //      어항 너비 대비 위치
  final double top; //       어항 높이 대비 위치
  final double distance; //  좌우로 헤엄치는 거리
  final double startFlip; // 처음 바라보는 방향
  final int seconds; //      한 번 왕복하는 시간
}

class _FishTankScreenState extends State<FishTankScreen> with TickerProviderStateMixin {
  static const double _tankHeight = 300;
  static const double _fishSize = 100;

  static const Map<FishType, _FishSpot> _spots = {
    FishType.vitality: _FishSpot(0.02, 0.10, 70, -1, 9),
    FishType.calm: _FishSpot(0.52, 0.14, -60, 1, 7),
    FishType.anxiety: _FishSpot(0.06, 0.52, 80, -1, 8),
    FishType.fatigue: _FishSpot(0.54, 0.54, -70, 1, 10),
  };

  late FishType _selected;
  FishType? _pulse;

  late final Map<FishType, AnimationController> _swim;
  late final Map<FishType, AnimationController> _heart;

  GrowthStore get _store => GrowthStore.instance;

  /// 이 화면을 연 순간의 수질 단계와 '다시 와 줘서 고마워요' 인사 여부
  late final int _murk;
  late final bool _welcome;

  @override
  void initState() {
    super.initState();
    _murk = _store.waterStage; // 기록을 최신으로 맞추면서 수질을 계산해요
    _welcome = _store.welcomeBack;
    _store.welcomeBack = false; // 인사는 한 번만
    _selected = _store.todayType ?? FishType.vitality;
    final slow = _murk >= 2 ? 1.7 : 1.0; // 10일 이상: 천천히 헤엄
    _swim = {
      for (final t in FishType.values)
        t: (AnimationController(
          vsync: this,
          duration: Duration(milliseconds: (_spots[t]!.seconds * 1000 * slow).round()),
        )..repeat()),
    };
    _heart = {
      for (final t in FishType.values)
        t: AnimationController(vsync: this, duration: const Duration(milliseconds: 900)),
    };
  }

  @override
  void dispose() {
    for (final c in _swim.values) {
      c.dispose();
    }
    for (final c in _heart.values) {
      c.dispose();
    }
    super.dispose();
  }

  void _pick(FishType type) {
    setState(() {
      _selected = type;
      _pulse = type;
    });
    _heart[type]!.forward(from: 0);
    Timer(const Duration(milliseconds: 220), () {
      if (mounted && _pulse == type) setState(() => _pulse = null);
    });
  }

  /// 어항에 보여 줄 물고기
  List<FishType> get _visibleFish {
    final today = _store.todayType;
    if (showOnlyTodayFish && today != null) return [today];
    return FishType.values;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Expanded(
            child: AnimatedBuilder(
              animation: _store,
              builder: (context, _) {
                final today = _store.todayType;
                final selected = _store.fish[_selected]!;
                return SingleChildScrollView(
                  padding: EdgeInsets.fromLTRB(24, topPad(context, 56), 24, 16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      const TankHeader(),
                      const SizedBox(height: 24),
                      if (_welcome) ...[
                        const InfoBanner(text: '다시 와 줘서 고마워요! 어항 물이 다시 맑아졌어요.'),
                        const SizedBox(height: 14),
                      ],
                      _tank(),
                      const SizedBox(height: 12),
                      Text(
                        _murk > 0
                            ? '마지막 기록 후 ${_store.daysSinceLastRecord}일이 지나 물이 조금 탁해졌어요. 오늘 마음을 기록하면 다시 맑아져요'
                            : today == null
                                ? '오늘 마음을 기록하면 오늘의 물고기가 정해져요'
                                : '말풍선을 누르면 문장 노트에서 오늘의 문장을 따라 쓸 수 있어요',
                        style: ts(11, color: AppColors.textSub, height: 1.5),
                      ),
                      const SizedBox(height: 14),
                      const BgmBar(),
                      const SizedBox(height: 22),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text('나의 물고기', style: ts(14, weight: bold)),
                          Text('물고기를 탭해보세요', style: ts(12, color: AppColors.textMuted)),
                        ],
                      ),
                      const SizedBox(height: 12),
                      _ownedFish(today),
                      const SizedBox(height: 22),
                      FishLevelCard(type: _selected, level: selected.level, exp: selected.exp, maxExp: selected.maxExp),
                    ],
                  ),
                );
              },
            ),
          ),
          const AppBottomNav(current: NavTab.fishTank),
        ],
      ),
    );
  }

  // ───────── 어항 ─────────

  Widget _tank() {
    final today = _store.todayType;
    final phrase = _store.todayPhrase;
    final spotlight = _store.bgmPlaying && today != null; // 그날의 음원 재생 중이면 오늘의 물고기를 강조

    return ClipRRect(
      borderRadius: BorderRadius.circular(24),
      child: SizedBox(
        height: _tankHeight,
        child: LayoutBuilder(builder: (context, c) {
          final w = c.maxWidth;
          final h = c.maxHeight;
          return Stack(
            children: [
              const Positioned.fill(child: TankBackground(sandRatio: 0.35, plants: [])),
              Positioned.fill(child: TankDecor(sandRatio: 0.35, murk: _murk)),
              for (final t in _visibleFish)
                Positioned(
                  left: w * _spots[t]!.left,
                  top: h * _fishTop(t),
                  child: AnimatedOpacity(
                    duration: const Duration(milliseconds: 400),
                    opacity: spotlight && t != today ? 0.85 : 1,
                    child: _SwimmingFish(
                      swim: _swim[t]!,
                      heart: _heart[t]!,
                      distance: _spots[t]!.distance,
                      startFlip: _spots[t]!.startFlip,
                      size: _fishSize,
                      pulsing: _pulse == t,
                      highlight: t == today ? t.dark : null,
                      spotlight: spotlight && t == today,
                      onTap: () => _pick(t),
                      child: FishSprite(type: t, level: _store.fish[t]!.level, size: _fishSize),
                    ),
                  ),
                ),
              // 오늘의 물고기 말풍선 (물고기를 따라다니지만 글자는 뒤집히지 않게 따로 그려요)
              if (today != null && phrase != null && _visibleFish.contains(today))
                _bubbleFor(today, phrase, w, h),
            ],
          );
        }),
      ),
    );
  }

  /// 물고기 세로 위치 (20일 이상 기록이 없으면 바닥 근처에서 쉬어요)
  double _fishTop(FishType t) {
    final top = _spots[t]!.top;
    return _murk >= 3 ? (top + 0.2).clamp(0.0, 0.62) : top;
  }

  Widget _bubbleFor(FishType type, String phrase, double w, double h) {
    const bubbleWidth = 168.0;
    final spot = _spots[type]!;
    return AnimatedBuilder(
      animation: _swim[type]!,
      builder: (context, _) {
        final (x, _) = _SwimmingFish.swimAt(_swim[type]!.value, spot.distance, spot.startFlip);
        final fishCenter = w * spot.left + x + _fishSize / 2;
        final maxLeft = w - bubbleWidth - 8 < 8 ? 8.0 : w - bubbleWidth - 8;
        final left = (fishCenter - bubbleWidth / 2).clamp(8.0, maxLeft);
        final tailX = (fishCenter - left).clamp(18.0, bubbleWidth - 18);
        final fishTop = h * _fishTop(type) + _fishSize * 0.32; // 그림 캔버스 안에서 물고기 몸통 위쪽
        return Positioned(
          left: left,
          bottom: h - fishTop,
          child: Tap(
            onTap: () => Nav.resetTo(context, AppRoutes.transcripts),
            child: _SpeechBubble(width: bubbleWidth, tailX: tailX, color: type.light, border: type.dark, text: phrase),
          ),
        );
      },
    );
  }

  // ───────── 나의 물고기 (4마리) ─────────

  Widget _ownedFish(FishType? today) {
    Widget slot(FishType t) {
      final f = _store.fish[t]!;
      final selected = t == _selected;
      return Tap(
        onTap: () => _pick(t),
        child: Column(
          children: [
            Stack(
              clipBehavior: Clip.none,
              children: [
                AnimatedContainer(
                  duration: const Duration(milliseconds: 180),
                  width: 60,
                  height: 60,
                  decoration: BoxDecoration(
                    color: t.light,
                    shape: BoxShape.circle,
                    border: Border.all(color: selected ? t.dark : t.color, width: selected ? 2.5 : 2),
                  ),
                  child: ClipOval(child: FishSprite(type: t, level: f.level, size: 56, zoom: true)),
                ),
                if (t == today)
                  Positioned(
                    top: -6,
                    right: -8,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(color: AppColors.primary, borderRadius: BorderRadius.circular(999)),
                      child: Text('오늘', style: ts(9, weight: bold, color: AppColors.white)),
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 6),
            Text(t.label, style: ts(11, weight: bold)),
            const SizedBox(height: 4),
            Text(f.isMax ? 'Lv.${f.level} 완성' : 'Lv.${f.level}', style: ts(10, color: AppColors.textMuted)),
          ],
        ),
      );
    }

    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [for (final t in FishType.values) slot(t)],
    );
  }
}

/// 말풍선 (아래쪽 꼬리가 물고기를 가리켜요)
class _SpeechBubble extends StatelessWidget {
  const _SpeechBubble({
    required this.width,
    required this.tailX,
    required this.color,
    required this.border,
    required this.text,
  });

  final double width;
  final double tailX;
  final Color color;
  final Color border;
  final String text;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: width,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: width,
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              color: color,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: border, width: 1.5),
              boxShadow: [
                BoxShadow(color: AppColors.alpha(Colors.black, 0.08), blurRadius: 8, offset: const Offset(0, 3)),
              ],
            ),
            child: Text(text, maxLines: 2, overflow: TextOverflow.ellipsis, style: ts(11, weight: bold, height: 1.4)),
          ),
          Padding(
            padding: EdgeInsets.only(left: tailX - 7),
            child: CustomPaint(size: const Size(14, 8), painter: _TailPainter(color: color, border: border)),
          ),
        ],
      ),
    );
  }
}

class _TailPainter extends CustomPainter {
  _TailPainter({required this.color, required this.border});

  final Color color;
  final Color border;

  @override
  void paint(Canvas canvas, Size size) {
    final path = Path()
      ..moveTo(0, -1)
      ..lineTo(size.width / 2, size.height)
      ..lineTo(size.width, -1);
    canvas.drawPath(path, Paint()..color = color);
    canvas.drawPath(
      path,
      Paint()
        ..color = border
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.5,
    );
  }

  @override
  bool shouldRepaint(covariant _TailPainter old) => old.color != color || old.border != border;
}

/// 좌우로 헤엄치는 물고기 (목업 keyframes swimJoy / swimCalm 재현)
class _SwimmingFish extends StatelessWidget {
  const _SwimmingFish({
    required this.swim,
    required this.heart,
    required this.distance,
    required this.startFlip,
    required this.size,
    required this.pulsing,
    required this.child,
    required this.onTap,
    this.highlight,
    this.spotlight = false,
  });

  final Animation<double> swim;
  final AnimationController heart;
  final double distance;
  final double startFlip;
  final double size; // 물고기 그림(정사각형) 크기
  final bool pulsing;
  final Widget child;
  final VoidCallback onTap;

  /// 오늘의 물고기면 주변에 은은한 빛을 깔아 줘요
  final Color? highlight;

  /// 그날의 음원 재생 중이면 빛을 더 강하게 + 조금 더 크게 + 물결 원
  final bool spotlight;

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: Listenable.merge([swim, heart]),
      builder: (context, _) {
        final (x, flip) = swimAt(swim.value, distance, startFlip);
        return Transform(
          alignment: Alignment.center,
          transform: Matrix4.translationValues(x, 0, 0)..multiply(Matrix4.diagonal3Values(flip, 1, 1)),
          child: Tap(
            onTap: onTap,
            child: SizedBox(
              width: size,
              height: size,
              child: Stack(
                clipBehavior: Clip.none,
                children: [
                  if (highlight != null)
                    Positioned.fill(
                      child: IgnorePointer(
                        child: DecoratedBox(
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            gradient: RadialGradient(
                              colors: [
                                AppColors.alpha(spotlight ? AppColors.white : highlight!, spotlight ? 0.75 : 0.5),
                                AppColors.alpha(highlight!, spotlight ? 0.45 : 0.25),
                                AppColors.alpha(highlight!, 0),
                              ],
                              stops: const [0.0, 0.45, 0.75],
                            ),
                          ),
                        ),
                      ),
                    ),
                  // 재생 중: 물고기 주변으로 물결 원이 퍼져요
                  if (spotlight)
                    Positioned.fill(
                      child: IgnorePointer(
                        child: Center(
                          child: RippleRings(
                            ringSize: size * 0.5,
                            color: AppColors.white,
                            duration: const Duration(milliseconds: 2800),
                            scaleFrom: 0.8,
                            scaleTo: 2.0,
                            opacityFrom: 0.7,
                          ),
                        ),
                      ),
                    ),
                  AnimatedScale(
                    scale: pulsing ? 1.35 : (spotlight ? 1.18 : (highlight != null ? 1.08 : 1)),
                    duration: const Duration(milliseconds: 200),
                    curve: Curves.ease,
                    child: child,
                  ),
                  if (heart.isAnimating) _heart(heart.value),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _heart(double t) {
    // keyframes heartFloat: 0% / 50% / 80% / 100%
    double lerp3(double a, double b, double c, double d) {
      if (t < 0.5) return a + (b - a) * (t / 0.5);
      if (t < 0.8) return b + (c - b) * ((t - 0.5) / 0.3);
      return c + (d - c) * ((t - 0.8) / 0.2);
    }

    final opacity = lerp3(0.9, 1, 0.9, 0);
    final dy = lerp3(0, -16, -24, -28);
    final scale = lerp3(0.4, 1, 1.05, 1.6);
    return Positioned(
      top: size * 0.3 - 18,
      left: size * 0.45 - 9,
      child: Opacity(
        opacity: opacity.clamp(0.0, 1.0),
        child: Transform.translate(
          offset: Offset(0, dy),
          child: Transform.scale(scale: scale, child: Svg(AppIcons.heart(), size: 18)),
        ),
      ),
    );
  }

  /// t(0~1) 시점의 x 이동량과 좌우 방향(scaleX). 말풍선 위치 계산에도 써요.
  static (double, double) swimAt(double t, double distance, double startFlip) {
    final ease = Curves.easeInOut;
    if (t < 0.45) return (distance * ease.transform(t / 0.45), startFlip);
    if (t < 0.50) {
      final k = ease.transform((t - 0.45) / 0.05);
      return (distance, startFlip + (-2 * startFlip) * k);
    }
    if (t < 0.95) return (distance * (1 - ease.transform((t - 0.5) / 0.45)), -startFlip);
    final k = ease.transform((t - 0.95) / 0.05);
    return (0, -startFlip + (2 * startFlip) * k);
  }
}
