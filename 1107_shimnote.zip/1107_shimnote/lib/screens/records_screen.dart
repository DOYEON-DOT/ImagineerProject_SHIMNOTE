import 'package:flutter/material.dart';

import '../navigation/app_routes.dart';
import '../navigation/nav.dart';
import '../services/growth_store.dart';
import '../theme/app_colors.dart';
import '../theme/app_text.dart';
import '../widgets/app_icons.dart';
import '../widgets/bottom_nav.dart';
import '../widgets/common.dart';
import '../widgets/fish_widgets.dart';
import '../widgets/record_widgets.dart';
import '../widgets/weekly_report_card.dart';
import 'transcripts_screen.dart';

/// 9. 기록
/// - [변경/11-06] 필사를 '문장 노트'로 이름을 바꿔 다시 이 화면 안의 탭으로 넣었어요.
/// - 캘린더 / 문장 노트 탭 전환 (어항의 말풍선 등 문장 노트로 가는 이동은 문장 노트 탭이 선택된 상태로 열려요)
/// - 오늘의 메모 영역 → 9-2. 오늘의 메모
/// - [변경/11-06] 캘린더·연속 기록이 실제 기록으로 동작해요. (기록이 없으면 그 상태가 곧 첫 사용자 화면)
/// - 하단 탭: 홈 / 어항
class RecordsScreen extends StatefulWidget {
  const RecordsScreen({super.key, this.showTranscripts = false});

  /// true면 '문장 노트' 탭이 선택된 상태로 열려요.
  final bool showTranscripts;

  @override
  State<RecordsScreen> createState() => _RecordsScreenState();
}

class _RecordsScreenState extends State<RecordsScreen> {
  late bool _calendar = !widget.showTranscripts;

  /// 보고 있는 달(1일)과 선택한 날짜
  DateTime _month = DateTime(DateTime.now().year, DateTime.now().month);
  DateTime _selected = dayOf(DateTime.now());

  GrowthStore get _store => GrowthStore.instance;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Column(
        children: [
          Expanded(
            child: SingleChildScrollView(
              padding: EdgeInsets.fromLTRB(24, topPad(context, 56), 24, 16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('나의 기록', style: ts(17, weight: bold)),
                    ],
                  ),
                  const SizedBox(height: 16),
                  _segment(),
                  const SizedBox(height: 20),
                  if (_calendar)
                    AnimatedBuilder(animation: _store, builder: (context, _) => _calendarTab())
                  else
                    const TranscriptsPanel(),
                ],
              ),
            ),
          ),
          const AppBottomNav(current: NavTab.records),
        ],
        ),
      ),
    );
  }

  /// 캘린더 / 문장 노트 탭
  Widget _segment() {
    Widget item(String label, bool active, VoidCallback onTap) => Expanded(
          child: Tap(
            onTap: onTap,
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 180),
              padding: const EdgeInsets.symmetric(vertical: 9),
              decoration: BoxDecoration(
                color: active ? AppColors.primary : Colors.transparent,
                borderRadius: BorderRadius.circular(999),
              ),
              child: Text(label,
                  textAlign: TextAlign.center,
                  style: ts(13, weight: bold, color: active ? AppColors.white : AppColors.textSub)),
            ),
          ),
        );

    return Container(
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: AppColors.white,
        borderRadius: BorderRadius.circular(999),
        boxShadow: AppColors.cardShadow(0.06),
      ),
      child: Row(
        children: [
          item('캘린더', _calendar, () => setState(() => _calendar = true)),
          item('문장 노트', !_calendar, () => setState(() => _calendar = false)),
        ],
      ),
    );
  }

  Widget _calendarTab() {
    final today = dayOf(DateTime.now());
    final thisMonth = DateTime(today.year, today.month);
    final oldestMonth = DateTime(today.year, today.month - 5); // 최근 6개월만 보관
    final recorded = {
      for (final r in _store.records)
        if (r.date.year == _month.year && r.date.month == _month.month) r.date.day,
    };
    final isThisMonth = _month == thisMonth;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        _streakBanner(),
        const SizedBox(height: 18),
        // 달 이동
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            _monthArrow(Icons.chevron_left_rounded, _month.isAfter(oldestMonth),
                () => setState(() => _month = DateTime(_month.year, _month.month - 1))),
            const SizedBox(width: 12),
            Text('${_month.year}년 ${_month.month}월', style: ts(15, weight: bold)),
            const SizedBox(width: 12),
            _monthArrow(Icons.chevron_right_rounded, _month.isBefore(thisMonth),
                () => setState(() => _month = DateTime(_month.year, _month.month + 1))),
          ],
        ),
        const SizedBox(height: 12),
        RealMonthCalendar(
          year: _month.year,
          month: _month.month,
          recordedDays: recorded,
          today: isThisMonth ? today.day : (_month.isAfter(thisMonth) ? 0 : null),
          selectedDay: _selected.year == _month.year && _selected.month == _month.month ? _selected.day : null,
          onSelect: (d) => setState(() => _selected = DateTime(_month.year, _month.month, d)),
        ),
        const SizedBox(height: 20),
        _dayDetail(),
        const SizedBox(height: 14),
        InfoBanner(
          text: _store.expiringSoonCount > 0
              ? '기록은 최근 6개월만 보관돼요. $recordExpireNoticeDays일 안에 지워질 기록이 ${_store.expiringSoonCount}개 있어요.'
              : '기록은 최근 6개월만 보관되고, 녹음 파일은 저장하지 않아요.',
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        ),
        const SizedBox(height: 14),
        // [변경/11-06] 실제 기록으로 만든 이번 주 영역별 리포트
        const WeeklyReportCard(),
      ],
    );
  }

  Widget _monthArrow(IconData icon, bool enabled, VoidCallback onTap) {
    return Tap(
      onTap: enabled ? onTap : null,
      child: Icon(icon, size: 26, color: enabled ? AppColors.textDark : AppColors.dayOff),
    );
  }

  /// 연속 기록 배너
  Widget _streakBanner() {
    final streak = _store.streak;
    final String title;
    final String sub;
    if (streak > 0) {
      title = '$streak일째 연속 기록 중';
      sub = _store.recordedToday ? '이대로 쭉 이어가 볼까요?' : '오늘도 기록하면 ${streak + 1}일째예요';
    } else if (_store.records.isEmpty) {
      title = '오늘 첫 기록을 남겨 볼까요?';
      sub = '마음을 기록하면 연속 기록이 시작돼요';
    } else {
      title = '다시 시작해 볼까요?';
      sub = '오늘 기록하면 1일째부터 다시 이어져요';
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
      decoration: BoxDecoration(color: const Color(0xFFFFF2D6), borderRadius: BorderRadius.circular(18)),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            alignment: Alignment.center,
            decoration: BoxDecoration(color: const Color(0xFFFFE3AC), borderRadius: BorderRadius.circular(14)),
            child: Svg(AppIcons.streakFlame(), size: 22),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: ts(15, weight: bold, color: const Color(0xFF8A5B0F))),
                const SizedBox(height: 2),
                Text(sub, style: ts(12, color: const Color(0xFFA97D33))),
              ],
            ),
          ),
        ],
      ),
    );
  }

  /// 선택한 날짜의 기록
  Widget _dayDetail() {
    final rec = _store.recordOn(_selected);
    final isToday = _selected == dayOf(DateTime.now());
    final title = '${_selected.month}월 ${_selected.day}일${isToday ? ' (오늘)' : ''}';

    if (rec == null) {
      return AppCard(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(title, style: ts(13, weight: bold)),
            const SizedBox(height: 12),
            Text(isToday ? '아직 오늘의 기록이 없어요' : '이날은 기록이 없어요', style: ts(13, color: AppColors.textSub)),
            if (isToday) ...[
              const SizedBox(height: 14),
              Align(
                alignment: Alignment.centerLeft,
                child: Tap(
                  onTap: () => Nav.push(context, AppRoutes.recording),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                    decoration: BoxDecoration(color: AppColors.primary, borderRadius: BorderRadius.circular(999)),
                    child: Text('감정 담으러 가기', style: ts(13, weight: bold, color: AppColors.white)),
                  ),
                ),
              ),
            ],
          ],
        ),
      );
    }

    return AppCard(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(title, style: ts(13, weight: bold)),
          const SizedBox(height: 14),
          _kv('웰니스 스코어', Text('${rec.wellness.round()}점', style: ts(14, weight: bold, color: AppColors.primary))),
          const SizedBox(height: 14),
          _kv('가장 높았던 감정', Text(rec.type.label, style: ts(13))),
          const SizedBox(height: 14),
          _kv('들었던 사운드', Text(rec.soundTitle ?? '아직 듣지 않았어요', style: ts(13, color: rec.soundTitle == null ? AppColors.textMuted : AppColors.textDark))),
          const SizedBox(height: 14),
          Tap(
            onTap: () {
              _store.memoTargetDate = rec.date;
              Nav.push(context, AppRoutes.recordMemo);
            },
            child: Container(
              padding: const EdgeInsets.only(top: 12),
              decoration: const BoxDecoration(border: Border(top: BorderSide(color: AppColors.track))),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('오늘의 메모', style: ts(12, color: AppColors.textSub)),
                      Svg(AppIcons.pencil(AppColors.textMuted), size: 14),
                    ],
                  ),
                  const SizedBox(height: 6),
                  Text(rec.memo ?? '눌러서 이날의 메모를 남겨 보세요',
                      style: ts(13, height: 1.5, color: rec.memo == null ? AppColors.textMuted : AppColors.textDark)),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _kv(String key, Widget value) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [Text(key, style: ts(12, color: AppColors.textSub)), value],
    );
  }
}