import 'package:flutter/material.dart';

import '../navigation/app_routes.dart';
import '../navigation/nav.dart';
import '../services/analysis_service.dart';
import '../services/growth_store.dart';
import '../theme/app_colors.dart';
import '../theme/app_text.dart';
import '../widgets/animations.dart';
import '../widgets/app_icons.dart';
import '../widgets/bottom_nav.dart';
import '../widgets/common.dart';
import '../widgets/fish_widgets.dart';

/// 3. 메인(홈)
/// [변경/11-06] 기록을 더 잘 유도하도록 홈을 다시 구성했어요.
/// - 시간대별 인사
/// - 오늘의 기록 카드: 녹음 전 = 오늘의 질문 + 녹음 버튼 / 녹음 후 = 오늘의 요약 (점수·물고기·음원)
/// - 이번 주 기록: 월~일 7칸 + 연속 기록
/// - 미니 어항: 오늘의 물고기와 수질 상태, 누르면 10. 어항
/// - 하단 탭: 기록 → 9. 기록, 어항 → 10. 어항
class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  /// 시간대별 인사 (작은 영어 문구, 큰 한국어 문구)
  (String, String) _greeting() {
    final hour = DateTime.now().hour;
    if (hour >= 5 && hour < 11) return ('GOOD MORNING', '좋은 아침이에요\n오늘 마음은 어떤가요?');
    if (hour >= 11 && hour < 17) return ('GOOD AFTERNOON', '오후도 잘 보내고 있나요?\n잠깐 쉬어 가요');
    if (hour >= 17 && hour < 22) return ('GOOD EVENING', '오늘 하루도\n참 수고 많으셨어요');
    return ('GOOD NIGHT', '늦은 시간까지 고생했어요\n편안한 밤 보내요');
  }

  @override
  Widget build(BuildContext context) {
    final store = GrowthStore.instance;
    final (label, title) = _greeting();

    return Scaffold(
      body: Column(
        children: [
          Expanded(
            child: Stack(
              fit: StackFit.expand,
              children: [
                const Positioned(top: -70, right: -70, child: BubbleDeco(size: 200)),
                const Positioned(top: 130, left: -60, child: BubbleDeco(size: 120, opacity: 0.7)),
                AnimatedBuilder(
                  animation: store,
                  builder: (context, _) => SingleChildScrollView(
                    padding: EdgeInsets.fromLTRB(24, topPad(context, 56), 24, 20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Text(label, style: ts(12, weight: bold, color: AppColors.accent, letterSpacing: 1)),
                        const SizedBox(height: 10),
                        Text(title, style: ts(20, weight: bold, height: 1.4)),
                        const SizedBox(height: 22),
                        // 기록이 바뀌면 다시 그려지도록 const 를 쓰지 않아요
                        _TodayCard(),
                        const SizedBox(height: 16),
                        _WeekCard(),
                        const SizedBox(height: 16),
                        _MiniTank(),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          const AppBottomNav(current: NavTab.home),
        ],
      ),
    );
  }
}

// ───────────────────────── 오늘의 기록 카드 ─────────────────────────

/// 매일 바뀌는 오늘의 질문 (무슨 말을 할지 막막하지 않게)
const _dailyQuestions = [
  '오늘 가장 기억에 남는 순간은 뭐였어요?',
  '지금 몸은 어떤 느낌이에요?',
  '오늘 나를 웃게 한 건 뭐였나요?',
  '요즘 마음을 가장 많이 차지하는 건 뭐예요?',
  '오늘 나에게 해 주고 싶은 말이 있나요?',
  '오늘 조금 힘들었던 일이 있었나요?',
  '지금 가장 하고 싶은 건 뭐예요?',
  '오늘 누군가에게 고마웠던 일이 있었나요?',
  '오늘의 나를 날씨로 표현하면 어때요?',
  '내일의 나에게 기대하는 건 뭐예요?',
];

String _questionOfToday() {
  final now = DateTime.now();
  final dayOfYear = now.difference(DateTime(now.year)).inDays;
  return _dailyQuestions[dayOfYear % _dailyQuestions.length];
}

class _TodayCard extends StatelessWidget {
  const _TodayCard();

  @override
  Widget build(BuildContext context) {
    final record = GrowthStore.instance.recordOn(DateTime.now());
    return record == null ? _before(context) : _after(context, record);
  }

  /// 녹음 전: 오늘의 질문 + 녹음 버튼
  Widget _before(BuildContext context) {
    return Tap(
      onTap: () => Nav.push(context, AppRoutes.recording),
      child: AppCard(
        radius: 24,
        padding: const EdgeInsets.fromLTRB(20, 24, 20, 22),
        shadow: AppColors.cardShadow(0.10, 20, 6),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(color: AppColors.track, borderRadius: BorderRadius.circular(999)),
              child: Text('오늘의 질문', style: ts(11, weight: bold, color: AppColors.primary)),
            ),
            const SizedBox(height: 10),
            Text(_questionOfToday(), textAlign: TextAlign.center, style: ts(16, weight: bold, height: 1.5)),
            const SizedBox(height: 20),
            // [추가/11-06] 숨 쉬는 녹음 버튼 (녹음 전에만)
            const _BreathingMic(),
            const SizedBox(height: 16),
            Text('탭해서 목소리로 답해 보세요', style: ts(14, weight: bold)),
            const SizedBox(height: 4),
            Text('30초면 충분해요 · 녹음 파일은 저장되지 않아요', style: ts(11, color: AppColors.textSub)),
          ],
        ),
      ),
    );
  }

  /// 녹음 후: 오늘의 요약
  Widget _after(BuildContext context, DayRecord record) {
    final fish = GrowthStore.instance.fish[record.type]!;
    final hasResult = AnalysisSession.instance.result != null;

    return AppCard(
      radius: 24,
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 18),
      shadow: AppColors.cardShadow(0.10, 20, 6),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              const Icon(Icons.check_circle_rounded, size: 18, color: AppColors.primary),
              const SizedBox(width: 6),
              Text('오늘의 기록 완료', style: ts(13, weight: bold, color: AppColors.primary)),
            ],
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              Container(
                width: 64,
                height: 64,
                decoration: BoxDecoration(
                  color: record.type.light,
                  shape: BoxShape.circle,
                  border: Border.all(color: record.type.dark, width: 2),
                ),
                child: ClipOval(child: FishSprite(type: record.type, level: fish.level, size: 60, zoom: true)),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('오늘의 물고기 · ${record.type.label}', style: ts(12, color: AppColors.textSub)),
                    const SizedBox(height: 2),
                    Text('웰니스 ${record.wellness.round()}점', style: ts(20, weight: bold)),
                    const SizedBox(height: 2),
                    Text(
                      record.soundTitle == null ? '아직 오늘의 사운드를 듣지 않았어요' : '♪ ${record.soundTitle}',
                      style: ts(12, color: record.soundTitle == null ? AppColors.textMuted : AppColors.textBody),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: _SmallButton(
                  label: '한 번 더 기록하기',
                  filled: false,
                  onTap: () => Nav.push(context, AppRoutes.recording),
                ),
              ),
              if (hasResult) ...[
                const SizedBox(width: 10),
                Expanded(
                  child: _SmallButton(
                    label: record.soundTitle == null ? '추천 사운드 듣기' : '결과 다시 보기',
                    filled: true,
                    onTap: () => Nav.push(
                      context,
                      record.soundTitle == null ? AppRoutes.soundRecommend : AppRoutes.wellness,
                    ),
                  ),
                ),
              ],
            ],
          ),
        ],
      ),
    );
  }
}

class _SmallButton extends StatelessWidget {
  const _SmallButton({required this.label, required this.filled, required this.onTap});

  final String label;
  final bool filled;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Tap(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 11),
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: filled ? AppColors.primary : AppColors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: AppColors.primary, width: 1.2),
        ),
        child: Text(label, style: ts(13, weight: bold, color: filled ? AppColors.white : AppColors.primary)),
      ),
    );
  }
}

// ───────────────────────── 이번 주 기록 ─────────────────────────

class _WeekCard extends StatelessWidget {
  const _WeekCard();

  static const _labels = ['월', '화', '수', '목', '금', '토', '일'];

  @override
  Widget build(BuildContext context) {
    final store = GrowthStore.instance;
    final today = dayOf(DateTime.now());
    final monday = today.subtract(Duration(days: today.weekday - 1));
    final days = [for (var i = 0; i < 7; i++) monday.add(Duration(days: i))];
    final recorded = [for (final d in days) store.recordOn(d) != null];
    final count = recorded.where((e) => e).length;
    final streak = store.streak;

    return AppCard(
      radius: 20,
      padding: const EdgeInsets.fromLTRB(18, 16, 18, 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  count == 0 ? '이번 주 첫 기록을 남겨 볼까요?' : '이번 주 $count일 기록했어요',
                  style: ts(14, weight: bold),
                ),
              ),
              if (streak > 0)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(color: const Color(0xFFFFF2D6), borderRadius: BorderRadius.circular(999)),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Svg(AppIcons.streakFlame(), size: 13),
                      const SizedBox(width: 3),
                      Text('$streak일 연속', style: ts(11, weight: bold, color: const Color(0xFF8A5B0F))),
                    ],
                  ),
                ),
            ],
          ),
          const SizedBox(height: 14),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              for (var i = 0; i < 7; i++) _dayDot(_labels[i], recorded[i], days[i] == today, days[i].isAfter(today)),
            ],
          ),
        ],
      ),
    );
  }

  Widget _dayDot(String label, bool done, bool isToday, bool isFuture) {
    return Column(
      children: [
        Text(label,
            style: ts(11, weight: isToday ? bold : FontWeight.w400, color: isToday ? AppColors.primary : AppColors.textSub)),
        const SizedBox(height: 6),
        Container(
          width: 30,
          height: 30,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: done ? AppColors.primary : (isFuture ? AppColors.alpha(AppColors.track, 0.5) : AppColors.track),
            border: isToday && !done ? Border.all(color: AppColors.primary, width: 1.5) : null,
          ),
          child: done ? const Icon(Icons.check_rounded, size: 16, color: AppColors.white) : null,
        ),
      ],
    );
  }
}

// ───────────────────────── 미니 어항 ─────────────────────────

class _MiniTank extends StatelessWidget {
  const _MiniTank();

  @override
  Widget build(BuildContext context) {
    final store = GrowthStore.instance;
    final murk = store.waterStage;
    final record = store.recordOn(DateTime.now());
    final today = record?.type ?? store.todayType;

    final String status;
    if (murk > 0) {
      status = '물이 조금 탁해졌어요. 오늘 기록하면 다시 맑아져요';
    } else if (today != null) {
      status = '오늘의 물고기 · ${today.label} Lv.${store.fish[today]!.level}';
    } else {
      status = '오늘 기록하면 오늘의 물고기가 정해져요';
    }

    // 오늘의 물고기를 가운데 크게, 나머지는 작게
    final others = FishType.values.where((t) => t != today).toList();

    return Tap(
      onTap: () => Nav.resetTo(context, AppRoutes.fishTank),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: SizedBox(
          height: 150,
          child: LayoutBuilder(builder: (context, c) {
            final w = c.maxWidth;
            return Stack(
              children: [
                const Positioned.fill(child: TankBackground(sandRatio: 0.28, plants: [])),
                Positioned.fill(child: TankDecor(sandRatio: 0.28, murk: murk)),
                // 작은 물고기들
                for (var i = 0; i < others.length && i < 3; i++)
                  Positioned(
                    left: w * (0.08 + 0.3 * i),
                    top: 62.0 + (i.isEven ? 0 : 14),
                    child: Bounce(
                      distance: 4,
                      duration: Duration(milliseconds: 2200 + i * 300),
                      child: FishSprite(type: others[i], level: store.fish[others[i]]!.level, size: 54),
                    ),
                  ),
                // 오늘의 물고기
                if (today != null)
                  Positioned(
                    left: w * 0.5 - 40,
                    top: 34,
                    child: Bounce(
                      distance: 6,
                      child: FishSprite(type: today, level: store.fish[today]!.level, size: 80),
                    ),
                  ),
                // 위쪽 안내
                Positioned(
                  left: 14,
                  right: 14,
                  top: 12,
                  child: Row(
                    children: [
                      Text('나의 어항', style: ts(13, weight: bold)),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(status,
                            maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(11, color: AppColors.textBody)),
                      ),
                      Svg(AppIcons.chevronRight(AppColors.textDark), size: 16),
                    ],
                  ),
                ),
              ],
            );
          }),
        ),
      ),
    );
  }
}

/// [추가/11-06] 숨 쉬는 듯한 녹음 버튼
/// - 바깥 민트 원이 3.6초 주기로 1.0 → 1.08 → 1.0 천천히 커졌다 작아져요.
/// - 연한 링이 한 번씩 바깥으로 퍼지며 사라져요.
/// - 안쪽 마이크 원은 움직이지 않아요(누를 곳이 흔들리지 않게).
class _BreathingMic extends StatefulWidget {
  const _BreathingMic();

  @override
  State<_BreathingMic> createState() => _BreathingMicState();
}

class _BreathingMicState extends State<_BreathingMic> with SingleTickerProviderStateMixin {
  late final AnimationController _c;

  @override
  void initState() {
    super.initState();
    _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 3600))..repeat();
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 112,
      height: 112,
      child: AnimatedBuilder(
        animation: _c,
        builder: (context, child) {
          final t = _c.value;
          // 들숨·날숨: 0→1→0 을 부드럽게
          final breath = Curves.easeInOut.transform(t < 0.5 ? t * 2 : (1 - t) * 2);
          final ringT = Curves.easeOut.transform(t);
          return Stack(
            clipBehavior: Clip.none,
            alignment: Alignment.center,
            children: [
              // 퍼지는 링
              Transform.scale(
                scale: 1.0 + 0.45 * ringT,
                child: Container(
                  width: 112,
                  height: 112,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: AppColors.mint200.withAlpha((140 * (1 - ringT)).round()),
                      width: 2,
                    ),
                  ),
                ),
              ),
              // 숨 쉬는 바깥 원
              Transform.scale(
                scale: 1.0 + 0.08 * breath,
                child: Container(
                  width: 112,
                  height: 112,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: const RadialGradient(
                      colors: [AppColors.white, AppColors.mint100, AppColors.mint200],
                      stops: [0.0, 0.7, 1.0],
                    ),
                    boxShadow: AppColors.cardShadow(0.22, 30, 10),
                  ),
                ),
              ),
              child!,
            ],
          );
        },
        // 고정된 마이크 원
        child: Container(
          width: 70,
          height: 70,
          alignment: Alignment.center,
          decoration: const BoxDecoration(color: AppColors.primary, shape: BoxShape.circle),
          child: Svg(AppIcons.mic(AppColors.white), size: 28),
        ),
      ),
    );
  }
}
