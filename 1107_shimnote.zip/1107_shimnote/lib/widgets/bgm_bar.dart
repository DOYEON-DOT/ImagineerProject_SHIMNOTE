// [추가/11-01] 어항 배경음 미니 플레이어 — 그날의 음원을 다시 들어요
// 어항 탭과 필사 탭에서 함께 써요.

import 'package:flutter/material.dart';
import '../services/growth_store.dart';
import '../services/sound_image_cache.dart';
import '../theme/app_colors.dart';
import '../theme/app_text.dart';
import 'app_icons.dart';
import 'common.dart';

/// 그날의 음원 미니 플레이어
/// - 오늘 녹음 전: 안내 문구
/// - 녹음 후: 그날의 음원 이름 + '곡 선택'(오늘 추천 3곡 중 고르기) + 재생/일시정지
class BgmBar extends StatelessWidget {
  const BgmBar({super.key, this.compact = false});

  /// 필사 탭처럼 좁게 보여 줄 때
  final bool compact;

  @override
  Widget build(BuildContext context) {
    final store = GrowthStore.instance;
    return AnimatedBuilder(
      animation: store,
      builder: (context, _) {
        final sound = store.todaySound;

        if (sound == null) {
          return AppCard(
            radius: 16,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            child: Row(
              children: [
                _icon(AppColors.textMuted),
                const SizedBox(width: 12),
                Expanded(
                  child: Text('오늘 마음을 기록하면 그날의 음원을 여기서 다시 들을 수 있어요',
                      style: ts(12, color: AppColors.textSub, height: 1.4)),
                ),
              ],
            ),
          );
        }

        return AppCard(
          radius: 16,
          padding: EdgeInsets.symmetric(horizontal: 16, vertical: compact ? 10 : 14),
          child: Row(
            children: [
              _BgmArtwork(
                key: ValueKey(sound.id),
                sound: sound,
                fallback: _icon(AppColors.primary),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(store.bgmPlaying ? '오늘의 사운드 재생 중' : '오늘의 사운드', style: ts(11, color: AppColors.textSub)),
                    const SizedBox(height: 2),
                    Text(sound.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(14, weight: bold)),
                  ],
                ),
              ),
              const SizedBox(width: 10),
              Tap(
                onTap: () => showTodaySoundPicker(context),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                  decoration: BoxDecoration(
                    color: AppColors.track,
                    borderRadius: BorderRadius.circular(999),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text('곡 선택', style: ts(11, weight: bold, color: AppColors.primary)),
                      const SizedBox(width: 2),
                      const Icon(Icons.keyboard_arrow_down_rounded, size: 16, color: AppColors.primary),
                    ],
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Tap(
                onTap: store.toggleBgm,
                child: Container(
                  width: 38,
                  height: 38,
                  alignment: Alignment.center,
                  decoration: const BoxDecoration(color: AppColors.primary, shape: BoxShape.circle),
                  child: Svg(
                    store.bgmPlaying ? AppIcons.pause(AppColors.white) : AppIcons.play(AppColors.white),
                    size: 15,
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _icon(Color color) => Container(
        width: 38,
        height: 38,
        alignment: Alignment.center,
        decoration: BoxDecoration(color: AppColors.track, borderRadius: BorderRadius.circular(12)),
        child: Svg(AppIcons.music(color), size: 18),
      );
}

/// 오늘 추천된 곡 중에서 고르기 (선택된 곡에 체크 표시)
void showTodaySoundPicker(BuildContext context) {
  final store = GrowthStore.instance;
  showModalBottomSheet<void>(
    context: context,
    backgroundColor: AppColors.white,
    shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
    builder: (sheetContext) {
      final sounds = store.todaySounds;
      final selectedId = store.todaySound?.id;
      return SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 20, 20, 12),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text('오늘의 사운드 고르기', style: ts(16, weight: bold)),
              const SizedBox(height: 4),
              Text('오늘 추천된 곡 중 하나를 어항에서 다시 들을 수 있어요', style: ts(12, color: AppColors.textSub)),
              const SizedBox(height: 8),
              for (final s in sounds)
                Tap(
                  onTap: () {
                    store.selectTodaySound(s.id);
                    Navigator.of(sheetContext).pop();
                  },
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    child: Row(
                      children: [
                        Icon(
                          s.id == selectedId ? Icons.check_circle_rounded : Icons.radio_button_unchecked_rounded,
                          size: 22,
                          color: s.id == selectedId ? AppColors.primary : AppColors.textMuted,
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(s.title, style: ts(14, weight: bold)),
                              const SizedBox(height: 2),
                              Text(s.desc, style: ts(12, color: AppColors.textSub)),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
            ],
          ),
        ),
      );
    },
  );
}

// [추가/11-06] 오늘의 사운드 Firebase 이미지 표시
class _BgmArtwork extends StatefulWidget {
  const _BgmArtwork({
    super.key,
    required this.sound,
    required this.fallback,
  });

  final SoundItem sound;
  final Widget fallback;

  @override
  State<_BgmArtwork> createState() => _BgmArtworkState();
}

class _BgmArtworkState extends State<_BgmArtwork> {
  Future<String>? _imageUrlFuture;

  @override
  void initState() {
    super.initState();
    _loadImage();
  }

  void _loadImage() {
    final path = widget.sound.imagePath;

    if (path == null || path.isEmpty) {
      _imageUrlFuture = null;
      return;
    }

    _imageUrlFuture = SoundImageCache.getUrl(path);
  }

  @override
  void didUpdateWidget(covariant _BgmArtwork oldWidget) {
    super.didUpdateWidget(oldWidget);

    if (oldWidget.sound.imagePath != widget.sound.imagePath) {
      _loadImage();
    }
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 38,
      height: 38,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(12),
        child: FutureBuilder<String>(
          future: _imageUrlFuture,
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.done &&
                snapshot.hasData) {
              return Image.network(
                snapshot.data!,
                width: 38,
                height: 38,
                fit: BoxFit.cover,
                webHtmlElementStrategy: WebHtmlElementStrategy.fallback,
                loadingBuilder: (context, child, progress) {
                  if (progress == null) return child;
                  return widget.fallback;
                },
                errorBuilder: (context, error, stackTrace) {
                  debugPrint('오늘의 사운드 이미지 표시 실패: $error');
                  return widget.fallback;
                },
              );
            }

            if (snapshot.hasError) {
              debugPrint(
                '오늘의 사운드 이미지 불러오기 실패: ${snapshot.error}',
              );
            }

            return widget.fallback;
          },
        ),
      ),
    );
  }
}
