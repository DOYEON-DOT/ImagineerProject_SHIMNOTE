import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart' show SvgPicture;

import '../navigation/app_routes.dart';
import '../navigation/nav.dart';
import '../theme/app_colors.dart';
import '../theme/app_text.dart';
import 'app_icons.dart';
import 'common.dart';
import 'record_widgets.dart';

/// 물고기 4종 (감정 유형별 색)
/// 그림 파일: assets/fish/fish_<유형>_lv<1~5>.svg
enum FishType {
  vitality('활력', Color(0xFFFFE08A), Color(0xFFF5C451), Color(0xFFFFF7DA)),
  calm('안정', Color(0xFFA8E0B8), Color(0xFF7CC896), Color(0xFFEAF8EE)),
  anxiety('불안', Color(0xFFFFABAB), Color(0xFFF28B8B), Color(0xFFFFEAEA)),
  fatigue('피로', Color(0xFFA7CBF5), Color(0xFF7DAAE6), Color(0xFFEAF3FD));

  const FishType(this.label, this.color, this.dark, this.light);

  final String label; // 한글 이름
  final Color color; //  몸통 색
  final Color dark; //   지느러미·테두리 색
  final Color light; //  배경용 연한 색

  static const int maxLevel = 5;

  String asset(int level) => 'assets/fish/fish_${name}_lv${level.clamp(1, maxLevel)}.svg';
}

/// 레벨별 이름
const fishLevelNames = {1: '치어', 2: '꼬마', 3: '성장', 4: '성숙', 5: '완성'};

/// 물고기 그림
/// - 그림은 200×200 캔버스 안에서 레벨이 오를수록 커지도록 그려져 있어,
///   같은 [size]로 그리면 레벨 차이가 그대로 보여요.
/// - [zoom]을 켜면 레벨과 상관없이 물고기가 꽉 차 보이게 확대합니다. (보유 물고기 동그라미용)
class FishSprite extends StatelessWidget {
  const FishSprite({super.key, required this.type, required this.level, required this.size, this.zoom = false});

  final FishType type;
  final int level;
  final double size;
  final bool zoom;

  static const _zoomByLevel = [2.3, 1.9, 1.6, 1.35, 1.15];

  @override
  Widget build(BuildContext context) {
    final picture = SvgPicture.asset(type.asset(level), width: size, height: size);
    if (!zoom) return picture;
    return SizedBox(
      width: size,
      height: size,
      child: ClipRect(
        child: OverflowBox(
          maxWidth: double.infinity,
          maxHeight: double.infinity,
          child: Transform.scale(scale: _zoomByLevel[level.clamp(1, FishType.maxLevel) - 1], child: picture),
        ),
      ),
    );
  }
}

/// 어항 화면 공통 헤더: 구름 뒤 '나의 어항' + 전환 링크 + 설정(마이페이지)
class TankHeader extends StatelessWidget {
  const TankHeader({super.key, this.linkLabel, this.onLink});

  /// [변경/11-01] 링크가 없으면 설정 아이콘만 보여 줘요.
  final String? linkLabel;
  final VoidCallback? onLink;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Stack(
          clipBehavior: Clip.none,
          children: [
            Positioned(left: -14, top: -12, child: Svg(AppIcons.cloud(), size: 168, height: 56)),
            Text('나의 어항', style: ts(17, weight: bold)),
          ],
        ),
        Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (linkLabel != null && onLink != null) ...[
              UnderlineLink(label: linkLabel!, onTap: onLink!),
              const SizedBox(width: 14),
            ],
            Tap(
              onTap: () => Nav.push(context, AppRoutes.myPage),
              child: Svg(AppIcons.settings(AppColors.textDark), size: 22),
            ),
          ],
        ),
      ],
    );
  }
}

/// 어항 배경 (물 그라데이션 + 모래 + 수초)
class TankBackground extends StatelessWidget {
  const TankBackground({super.key, required this.sandRatio, required this.plants});

  final double sandRatio; // 모래가 차지하는 높이 비율
  final List<PlantSpec> plants;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, c) {
      return Stack(
        children: [
          Positioned.fill(
            child: Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Color(0xFFCDEEF0), Color(0xFF7FC9D6)],
                ),
              ),
            ),
          ),
          Positioned(
            left: 0,
            right: 0,
            bottom: 0,
            height: c.maxHeight * sandRatio,
            child: const DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Color(0x99F0E6BE), Color(0xFFE7DCB0)],
                ),
              ),
            ),
          ),
          // 안쪽 그림자 느낌 (inset 0 0 40px rgba(0,60,70,0.12))
          Positioned.fill(
            child: IgnorePointer(
              child: DecoratedBox(
                decoration: BoxDecoration(
                  gradient: RadialGradient(
                    radius: 1.1,
                    colors: [Colors.transparent, AppColors.alpha(const Color(0xFF003C46), 0.12)],
                    stops: const [0.75, 1.0],
                  ),
                ),
              ),
            ),
          ),
          for (final p in plants)
            Positioned(
              left: p.left,
              right: p.right,
              bottom: p.bottom,
              child: Container(
                width: p.width,
                height: p.height,
                decoration: BoxDecoration(
                  color: p.color,
                  borderRadius: BorderRadius.vertical(
                    top: Radius.elliptical(p.width * 0.4, p.height * 0.4),
                  ),
                ),
              ),
            ),
        ],
      );
    });
  }
}

class PlantSpec {
  const PlantSpec({this.left, this.right, required this.bottom, required this.width, required this.height, required this.color});

  final double? left;
  final double? right;
  final double bottom;
  final double width;
  final double height;
  final Color color;
}

const plantLight = Color(0xFF7BAB6F);
const plantDark = Color(0xFF6A9C60);

/// 물고기 레벨 카드
class FishLevelCard extends StatelessWidget {
  const FishLevelCard({super.key, required this.type, required this.level, required this.exp, required this.maxExp});

  final FishType type;
  final int level;
  final int exp;
  final int maxExp;

  @override
  Widget build(BuildContext context) {
    return AppCard(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(color: type.light, shape: BoxShape.circle),
                child: ClipOval(child: FishSprite(type: type, level: level, size: 44, zoom: true)),
              ),
              const SizedBox(width: 12),
              Expanded(child: Text('${type.label} 물고기', style: ts(14, weight: bold))),
              Text('Lv. $level · ${fishLevelNames[level]}', style: ts(12, color: AppColors.textSub)),
            ],
          ),
          const SizedBox(height: 12),
          ProgressBar(value: exp / maxExp, color: type.dark, height: 8),
          const SizedBox(height: 10),
          Text('$exp / $maxExp EXP', textAlign: TextAlign.right, style: ts(11, color: AppColors.textMuted)),
        ],
      ),
    );
  }
}

/// 점선 원 테두리 (잠긴 물고기 슬롯)
class DashedCircle extends StatelessWidget {
  const DashedCircle({super.key, required this.size, required this.color, required this.fill, required this.child});

  final double size;
  final Color color;
  final Color fill;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      painter: _DashedCirclePainter(color: color, fill: fill),
      child: SizedBox(width: size, height: size, child: Center(child: child)),
    );
  }
}

class _DashedCirclePainter extends CustomPainter {
  _DashedCirclePainter({required this.color, required this.fill});

  final Color color;
  final Color fill;

  @override
  void paint(Canvas canvas, Size size) {
    final center = size.center(Offset.zero);
    final r = size.width / 2 - 1;
    canvas.drawCircle(center, r + 1, Paint()..color = fill);
    final paint = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2;
    const dash = 5.0;
    const gap = 4.0;
    final circumference = 2 * math.pi * r;
    final count = (circumference / (dash + gap)).floor();
    final step = 2 * math.pi / count;
    final sweep = step * dash / (dash + gap);
    for (var i = 0; i < count; i++) {
      canvas.drawArc(Rect.fromCircle(center: center, radius: r), i * step, sweep, false, paint);
    }
  }

  @override
  bool shouldRepaint(covariant _DashedCirclePainter old) => old.color != color || old.fill != fill;
}

// ───────────────────────── [추가/11-01] 어항 꾸미기 ─────────────────────────

/// 어항 꾸미기: 흔들리는 수초, 조약돌, 불가사리, 올라오는 거품
/// [TankBackground] 위, 물고기 아래에 깔아요.
class TankDecor extends StatefulWidget {
  const TankDecor({super.key, required this.sandRatio, this.murk = 0});

  /// [TankBackground]와 같은 모래 비율
  final double sandRatio;

  /// [추가/11-06] 수질 단계 0(맑음) ~ 3. 높을수록 물이 탁하고, 거품이 줄고, 수초가 처져요.
  final int murk;

  @override
  State<TankDecor> createState() => _TankDecorState();
}

class _TankDecorState extends State<TankDecor> with SingleTickerProviderStateMixin {
  late final AnimationController _c;

  @override
  void initState() {
    super.initState();
    _c = AnimationController(vsync: this, duration: const Duration(seconds: 6))..repeat();
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: RepaintBoundary(
        child: CustomPaint(
          painter: _TankDecorPainter(_c, widget.sandRatio, widget.murk),
          child: const SizedBox.expand(),
        ),
      ),
    );
  }
}

class _TankDecorPainter extends CustomPainter {
  _TankDecorPainter(this.anim, this.sandRatio, this.murk) : super(repaint: anim);

  final Animation<double> anim;
  final double sandRatio;
  final int murk;

  // 수초: (x 비율, 높이, 굵기, 흔들림 폭, 시작 위상, 색)
  static const _weeds = [
    (0.05, 92.0, 7.0, 9.0, 0.0, plantLight),
    (0.10, 70.0, 6.0, 7.0, 1.3, plantDark),
    (0.15, 52.0, 5.0, 6.0, 2.4, plantLight),
    (0.84, 84.0, 7.0, 8.0, 0.7, plantDark),
    (0.90, 104.0, 7.0, 10.0, 2.0, plantLight),
    (0.95, 62.0, 5.0, 6.0, 3.1, plantDark),
  ];

  // 조약돌: (x 비율, 모래 안 y 비율, 가로 반지름, 세로 반지름, 색)
  static const _pebbles = [
    (0.22, 0.30, 11.0, 7.0, Color(0xFFC9BFA3)),
    (0.28, 0.42, 8.0, 5.5, Color(0xFFB4AA8E)),
    (0.40, 0.70, 13.0, 8.0, Color(0xFFD6CDB2)),
    (0.47, 0.62, 7.0, 5.0, Color(0xFFA9A08A)),
    (0.62, 0.36, 9.0, 6.0, Color(0xFFBFB59A)),
    (0.78, 0.72, 12.0, 7.5, Color(0xFFCFC6AB)),
    (0.70, 0.80, 6.0, 4.0, Color(0xFFB0A68C)),
  ];

  // 거품: (x 비율, 반지름, 시작 위상, 좌우 흔들림)
  static const _bubbles = [
    (0.12, 3.5, 0.0, 4.0),
    (0.14, 2.2, 0.45, 3.0),
    (0.88, 4.0, 0.2, 5.0),
    (0.91, 2.5, 0.7, 3.0),
    (0.55, 3.0, 0.55, 4.0),
    (0.33, 2.0, 0.85, 3.0),
  ];

  @override
  void paint(Canvas canvas, Size size) {
    final t = anim.value; // 0~1, 6초에 한 바퀴
    final w = size.width;
    final h = size.height;
    final sandTop = h * (1 - sandRatio);
    final sandH = h * sandRatio;

    // 조약돌
    for (final (px, py, rx, ry, color) in _pebbles) {
      final c = Offset(w * px, sandTop + sandH * py);
      canvas.drawOval(Rect.fromCenter(center: c.translate(0, ry * 0.5), width: rx * 2, height: ry * 1.2),
          Paint()..color = const Color(0x22000000));
      canvas.drawOval(Rect.fromCenter(center: c, width: rx * 2, height: ry * 2), Paint()..color = color);
      canvas.drawOval(
        Rect.fromCenter(center: c.translate(-rx * 0.3, -ry * 0.35), width: rx * 0.7, height: ry * 0.5),
        Paint()..color = const Color(0x55FFFFFF),
      );
    }

    // 불가사리
    _drawStarfish(canvas, Offset(w * 0.68, sandTop + sandH * 0.55), 15, -0.35);

    // 수초 (아래에서 위로 갈수록 더 크게 흔들려요)
    final swayScale = 1 - 0.25 * murk; // 탁할수록 덜 흔들리고
    final droop = 6.0 * murk; //         옆으로 처져요
    for (final (px, rawHeight, thick, rawAmp, phase, color) in _weeds) {
      final height = rawHeight * (1 - 0.12 * murk);
      final amp = rawAmp * swayScale;
      final droopDir = px < 0.5 ? 1.0 : -1.0;
      final baseX = w * px;
      final baseY = sandTop + sandH * 0.35;
      const segments = 6;
      final points = <Offset>[];
      for (var i = 0; i <= segments; i++) {
        final k = i / segments;
        final sway = math.sin(t * 2 * math.pi + phase + k * 1.6) * amp * k;
        points.add(Offset(baseX + sway + droopDir * droop * k * k, baseY - height * k + droop * 0.6 * k * k));
      }
      final path = Path()..moveTo(points[0].dx, points[0].dy);
      for (var i = 1; i < points.length - 1; i++) {
        final mid = Offset((points[i].dx + points[i + 1].dx) / 2, (points[i].dy + points[i + 1].dy) / 2);
        path.quadraticBezierTo(points[i].dx, points[i].dy, mid.dx, mid.dy);
      }
      path.lineTo(points.last.dx, points.last.dy);
      canvas.drawPath(
        path,
        Paint()
          ..color = color
          ..style = PaintingStyle.stroke
          ..strokeWidth = thick
          ..strokeCap = StrokeCap.round
          ..strokeJoin = StrokeJoin.round,
      );
      // 작은 잎
      for (var i = 2; i < segments; i += 2) {
        final p = points[i];
        final dir = (i ~/ 2).isEven ? 1.0 : -1.0;
        final leaf = Path()
          ..moveTo(p.dx, p.dy)
          ..quadraticBezierTo(p.dx + 10 * dir, p.dy - 4, p.dx + 14 * dir, p.dy - 12);
        canvas.drawPath(
          leaf,
          Paint()
            ..color = color
            ..style = PaintingStyle.stroke
            ..strokeWidth = thick * 0.55
            ..strokeCap = StrokeCap.round,
        );
      }
    }

    // 거품 (바닥에서 수면까지 천천히 올라가요)
    // 탁할수록 거품이 줄어요 (6 → 4 → 2 → 1개)
    const bubbleCount = [6, 4, 2, 1];
    for (final (px, r, phase, wobble) in _bubbles.take(bubbleCount[murk.clamp(0, 3)])) {
      final p = (t + phase) % 1.0;
      final y = sandTop - p * (sandTop - 8);
      final x = w * px + math.sin(p * 4 * math.pi) * wobble;
      final opacity = p < 0.1 ? p / 0.1 : (p > 0.9 ? (1 - p) / 0.1 : 1.0);
      canvas.drawCircle(Offset(x, y), r, Paint()..color = AppColors.alpha(AppColors.white, 0.25 * opacity));
      canvas.drawCircle(
        Offset(x, y),
        r,
        Paint()
          ..color = AppColors.alpha(AppColors.white, 0.8 * opacity)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1,
      );
    }

    // 탁한 물 (수초·조약돌 위, 물고기 아래)
    if (murk > 0) {
      canvas.drawRect(
        Offset.zero & size,
        Paint()..color = AppColors.alpha(const Color(0xFF7D8F55), 0.10 * murk.clamp(0, 3)),
      );
    }
  }

  void _drawStarfish(Canvas canvas, Offset center, double radius, double rotation) {
    final path = Path();
    for (var i = 0; i < 10; i++) {
      final r = i.isEven ? radius : radius * 0.45;
      final a = rotation - math.pi / 2 + i * math.pi / 5;
      final p = center + Offset(math.cos(a) * r, math.sin(a) * r);
      if (i == 0) {
        path.moveTo(p.dx, p.dy);
      } else {
        path.lineTo(p.dx, p.dy);
      }
    }
    path.close();
    canvas.drawPath(path.shift(const Offset(0, 2)), Paint()..color = const Color(0x22000000));
    canvas.drawPath(
      path,
      Paint()
        ..color = const Color(0xFFF4A38A)
        ..style = PaintingStyle.fill,
    );
    // 모서리를 둥글게 보이게 같은 색 굵은 테두리
    canvas.drawPath(
      path,
      Paint()
        ..color = const Color(0xFFF4A38A)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 4
        ..strokeJoin = StrokeJoin.round,
    );
    // 점무늬
    for (var i = 0; i < 5; i++) {
      final a = rotation - math.pi / 2 + i * 2 * math.pi / 5;
      final p = center + Offset(math.cos(a) * radius * 0.5, math.sin(a) * radius * 0.5);
      canvas.drawCircle(p, 1.4, Paint()..color = const Color(0xFFFFD9CC));
    }
    canvas.drawCircle(center, 1.8, Paint()..color = const Color(0xFFE07F66));
  }

  @override
  bool shouldRepaint(covariant _TankDecorPainter old) => old.sandRatio != sandRatio || old.murk != murk;
}
